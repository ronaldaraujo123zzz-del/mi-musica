plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val buildNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1

android {
    namespace = "com.near.mimusica"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.near.mimusica"
        minSdk = 26
        targetSdk = 35
        versionCode = buildNumber
        versionName = "1.$buildNumber"
        // solo los procesadores de teléfonos de verdad (el traductor trae partes nativas; así pesa menos)
        ndk {
            abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a"))
        }
    }

    // La llave de firma NO va en el proyecto. GitHub Actions la reconstruye desde
    // los Secrets (NEAR_KEYSTORE_B64 y NEAR_KEYSTORE_PASS) justo antes de compilar.
    // Sin esas variables no se firma nada: el APK sale sin firmar y no se instala.
    val llave = file(System.getenv("NEAR_KEYSTORE_FILE") ?: "near-music.jks")
    val llavePass: String? = System.getenv("NEAR_KEYSTORE_PASS")
    val hayLlave = llave.exists() && !llavePass.isNullOrBlank()

    signingConfigs {
        create("mm") {
            if (hayLlave) {
                storeFile = llave
                storePassword = llavePass
                keyAlias = System.getenv("NEAR_KEY_ALIAS") ?: "nearmusic"
                keyPassword = System.getenv("NEAR_KEY_PASS") ?: llavePass
            }
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            // Sin llave queda sin firmar, para que el fallo se note en vez de
            // publicar un APK firmado con cualquier cosa.
            signingConfig = if (hayLlave) signingConfigs.getByName("mm") else null
        }
        getByName("debug") {
            // Si no hay llave, Android usa su firma de pruebas de siempre.
            if (hayLlave) signingConfig = signingConfigs.getByName("mm")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
    // traducir letras dentro del teléfono (gratis, sin clave, sin internet tras bajar el idioma)
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")
}
