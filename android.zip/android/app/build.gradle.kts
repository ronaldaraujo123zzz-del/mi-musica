plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val buildNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1

android {
    namespace = "com.near.mimusica"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.near.mimusica"
        minSdk = 26
        targetSdk = 35
        versionCode = buildNumber
        versionName = "1.$buildNumber"
        // solo los procesadores de teléfonos de verdad (el traductor trae partes nativas; así pesa menos)
        ndk {
            abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a"))
        }
    }

    // Gradle NO firma la versión de publicación. El APK sale sin firmar y lo
    // firma después el workflow con apksigner, que es la única herramienta que
    // sabe incluir el certificado de rotación (el que deja que los teléfonos
    // acepten la llave nueva como sustituta de la vieja, sin desinstalar).
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = null
        }
        // debug se queda con la firma de pruebas que pone Android.
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
    // traducir letras dentro del teléfono (gratis, sin clave, sin internet tras bajar el idioma)
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")
}
