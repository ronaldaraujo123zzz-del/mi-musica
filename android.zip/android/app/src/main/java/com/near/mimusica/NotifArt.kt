package com.near.mimusica

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import java.io.File

/**
 * Estilos para la carátula que se ve en la notificación.
 *
 * La notificación la dibuja el teléfono: la app no puede cambiarle el fondo ni los botones.
 * Lo que sí se puede es entregarle otra imagen de carátula. Aquí se arma esa imagen: la carátula
 * de la canción dentro de un marco (fuego, electricidad, luz, hielo, o un marco del color de la
 * propia carátula). Se guarda en la memoria temporal de la app para no rehacerla cada vez.
 *
 * Los marcos están en assets/notif/<estilo>.webp (512x512, con el centro transparente).
 */
object NotifArt {
    private const val SIZE = 512
    private const val MARGIN = 72            // la carátula va de 72 a 440 (igual que el hueco de los marcos)
    private const val KEEP = 60              // cuántas imágenes se guardan como mucho
    const val DIR = "nart"
    private val STYLES = setOf("fuego", "electrico", "luz", "hielo", "color")

    private fun clean(s: String?): String = if (s != null && s in STYLES) s else "normal"

    fun style(ctx: Context): String =
        clean(ctx.getSharedPreferences("mm", Context.MODE_PRIVATE).getString("notifArt", "normal"))

    /** Guarda el estilo elegido. Devuelve true si cambió. */
    fun setStyle(ctx: Context, s: String): Boolean {
        val want = clean(s)
        if (want == style(ctx)) return false
        ctx.getSharedPreferences("mm", Context.MODE_PRIVATE).edit().putString("notifArt", want).apply()
        return true
    }

    /** ¿Esta dirección es una carátula con estilo hecha aquí? */
    fun isStyled(uri: String?): Boolean = uri != null && uri.contains("/$DIR/")

    private fun dir(ctx: Context) = File(ctx.cacheDir, DIR)

    private fun fileFor(ctx: Context, id: Long, style: String): File {
        Covers.init(ctx)
        val v = Covers.version(id).ifEmpty { "0" }
        return File(dir(ctx), "${id}_${style}_$v.jpg")
    }

    /** La imagen ya hecha, si existe (rápido: se puede llamar desde el hilo principal). */
    fun cached(ctx: Context, id: Long, style: String): File? {
        if (style !in STYLES) return null
        return try {
            fileFor(ctx, id, style).takeIf { it.isFile && it.length() > 0 }
        } catch (e: Throwable) {
            null
        }
    }

    /** Arma la imagen (tarda un poco: llamar fuera del hilo principal). Devuelve null si algo falla. */
    @Synchronized
    fun make(ctx: Context, id: Long, style: String): File? {
        if (style !in STYLES) return null
        try {
            cached(ctx, id, style)?.let { return it }
            val d = dir(ctx)
            d.mkdirs()
            trim(d)

            val cover = softCopy(ArtLoader.bitmap(ctx, id, SIZE))
            val tint = if (cover != null) mainColor(cover) else Color.rgb(120, 90, 255)
            val out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

            // fondo
            c.drawColor(if (style == "color") withValue(tint, 0.22f) else Color.rgb(10, 8, 20))
            // carátula: recorte cuadrado del centro
            val dst = Rect(MARGIN, MARGIN, SIZE - MARGIN, SIZE - MARGIN)
            if (cover != null) {
                val side = minOf(cover.width, cover.height)
                val sx = (cover.width - side) / 2
                val sy = (cover.height - side) / 2
                c.drawBitmap(cover, Rect(sx, sy, sx + side, sy + side), dst, p)
            } else {
                p.color = withValue(tint, 0.45f)
                c.drawRect(dst, p)
                p.color = Color.WHITE
            }
            // marco encima
            val name = if (style == "color") "marco" else style
            val frame = ctx.assets.open("notif/$name.webp").use { BitmapFactory.decodeStream(it) }
            if (frame != null) {
                if (style == "color") p.colorFilter = PorterDuffColorFilter(vivid(tint), PorterDuff.Mode.SRC_IN)
                c.drawBitmap(frame, null, Rect(0, 0, SIZE, SIZE), p)
                p.colorFilter = null
            }

            val f = fileFor(ctx, id, style)
            val tmp = File(d, f.name + ".tmp")
            tmp.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            if (!tmp.renameTo(f)) {
                tmp.delete()
                return null
            }
            return f
        } catch (e: Throwable) {
            // sin memoria, sin espacio o imagen rara: la notificación se queda con la carátula normal
            return null
        }
    }

    /** Las carátulas que da el teléfono a veces no se pueden dibujar directamente: se copian. */
    private fun softCopy(b: Bitmap?): Bitmap? {
        if (b == null) return null
        return if (b.config == Bitmap.Config.HARDWARE || b.config == null) b.copy(Bitmap.Config.ARGB_8888, false) else b
    }

    /** Color medio de la carátula. */
    private fun mainColor(b: Bitmap): Int {
        val s = Bitmap.createScaledBitmap(b, 12, 12, true)
        var r = 0L
        var g = 0L
        var bl = 0L
        val px = IntArray(144)
        s.getPixels(px, 0, 12, 0, 0, 12, 12)
        for (c in px) {
            r += Color.red(c)
            g += Color.green(c)
            bl += Color.blue(c)
        }
        return Color.rgb((r / 144).toInt(), (g / 144).toInt(), (bl / 144).toInt())
    }

    /** El mismo color, más o menos oscuro. */
    private fun withValue(color: Int, v: Float): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[2] = v
        return Color.HSVToColor(hsv)
    }

    /** El mismo color bien vivo (las carátulas grises se quedan en blanco). */
    private fun vivid(color: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        if (hsv[1] >= 0.12f) hsv[1] = maxOf(hsv[1], 0.55f)
        hsv[2] = 1f
        return Color.HSVToColor(hsv)
    }

    /** Borra las más viejas para que no se acumulen. */
    private fun trim(d: File) {
        val all = d.listFiles() ?: return
        if (all.size <= KEEP) return
        all.sortedBy { it.lastModified() }.take(all.size - KEEP + 10).forEach { it.delete() }
    }
}
