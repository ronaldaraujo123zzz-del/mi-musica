package com.near.mimusica

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream
import java.io.File

/** Fondo de pantalla elegido por ti: se guarda una copia en la app y la interfaz lo pide en /bg/fondo.jpg */
object Bg {
    private const val MAX = 1800

    fun file(ctx: Context) = File(ctx.filesDir, "fondo.jpg")

    fun save(ctx: Context, uri: Uri): Boolean = try {
        val bmp = decode(ctx, uri) ?: throw IllegalStateException("sin imagen")
        file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        true
    } catch (e: Throwable) {
        false
    }

    fun clear(ctx: Context) {
        try {
            file(ctx).delete()
        } catch (e: Exception) {
        }
    }

    private fun decode(ctx: Context, uri: Uri): Bitmap? {
        if (Build.VERSION.SDK_INT >= 28) {
            // ImageDecoder ya gira la foto si el teléfono la guardó de lado
            val src = ImageDecoder.createSource(ctx.contentResolver, uri)
            return ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                val w = info.size.width
                val h = info.size.height
                val big = maxOf(w, h)
                if (big > MAX) {
                    val k = MAX.toFloat() / big
                    decoder.setTargetSize(maxOf(1, (w * k).toInt()), maxOf(1, (h * k).toInt()))
                }
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    class Handler(private val ctx: Context) : WebViewAssetLoader.PathHandler {
        override fun handle(path: String): WebResourceResponse? {
            val f = file(ctx)
            val bytes = try {
                if (f.isFile) f.readBytes() else null
            } catch (e: Exception) {
                null
            }
            if (bytes == null) {
                return WebResourceResponse("image/jpeg", null, 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            }
            val r = WebResourceResponse("image/jpeg", null, ByteArrayInputStream(bytes))
            r.responseHeaders = mapOf("Cache-Control" to "no-cache")
            return r
        }
    }
}
