package com.near.mimusica

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * Ícono de la app que se ve en el teléfono. Cada ícono es un "alias" de la misma pantalla
 * (ver AndroidManifest.xml) y solo uno está encendido a la vez.
 * "normal" es el de siempre (el alias se llama .MainActivity para no romper los accesos directos).
 */
object AppIcons {
    val KEYS = listOf("normal", "atardecer", "vinilo", "neon", "amoled", "pixel", "ondas", "cristal", "cortada", "gigante", "velocidad", "reflejo", "tresd", "contorno", "sticker", "calada", "glitch", "barras", "audifonos", "play", "letrapixel", "urbana", "cursiva", "oro", "futurista", "palabra", "monograma", "tinta", "holografico", "caricatura", "mitad", "rebanadas")

    private fun alias(ctx: Context, key: String): ComponentName =
        ComponentName(ctx.packageName, ctx.packageName + if (key == "normal") ".MainActivity" else ".Icono_$key")

    /** El ícono encendido ahora (si hay varios por un cambio a medias, el primero). */
    fun current(ctx: Context): String {
        val pm = ctx.packageManager
        for (k in KEYS) {
            val st = pm.getComponentEnabledSetting(alias(ctx, k))
            val on = when (st) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
                PackageManager.COMPONENT_ENABLED_STATE_DEFAULT -> k == "normal"   // así viene en el manifiesto
                else -> false
            }
            if (on) return k
        }
        return "normal"
    }

    /** Enciende un ícono y apaga los demás. Primero se enciende el nuevo para que nunca quede la app sin ícono. */
    fun set(ctx: Context, key: String): Boolean {
        if (key !in KEYS) return false
        val pm = ctx.packageManager
        return try {
            pm.setComponentEnabledSetting(alias(ctx, key), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            for (k in KEYS) if (k != key) {
                pm.setComponentEnabledSetting(alias(ctx, k), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            }
            true
        } catch (e: Throwable) {
            false
        }
    }
}
