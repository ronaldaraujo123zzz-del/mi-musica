package com.near.mimusica

import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * "Caja negra" del sonido: guarda los últimos problemas que detecta el reproductor
 * (cortes de audio, errores del decodificador) y las veces que tocas «¡Sonó raro!».
 * Con eso se arma un reporte que puedes copiar y mandar para encontrar el fallo.
 */
object SoundLog {
    private val events = ArrayDeque<String>()
    private val clock = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US)

    /** Cuántas veces se quedó sin audio por un instante (sonido que se "pega" o chasquea). */
    @Volatile
    var underruns = 0
        private set

    @Volatile
    var format = ""

    @Volatile
    var decoder = ""

    @Volatile
    var track = ""

    fun add(msg: String) {
        val line = clock.format(Date()) + "  " + msg
        synchronized(events) {
            events.addLast(line)
            while (events.size > 40) events.removeFirst()
        }
    }

    fun underrun(msg: String) {
        underruns++
        add(msg)
    }

    fun clear() {
        synchronized(events) { events.clear() }
        underruns = 0
    }

    fun report(now: String): String {
        val sb = StringBuilder()
        sb.append("REPORTE DE SONIDO · NEAR Music\n")
        sb.append("Teléfono: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
            .append(" · Android ").append(Build.VERSION.RELEASE).append('\n')
        sb.append(now).append('\n')
        if (format.isNotEmpty()) sb.append("Archivo: ").append(format).append('\n')
        if (decoder.isNotEmpty()) sb.append("Decodificador: ").append(decoder).append('\n')
        if (track.isNotEmpty()) sb.append("Salida: ").append(track).append('\n')
        sb.append("Cortes de audio detectados: ").append(underruns).append('\n')
        val list = synchronized(events) { events.toList() }
        sb.append("\nÚLTIMOS EVENTOS (").append(list.size).append(")\n")
        if (list.isEmpty()) sb.append("(ninguno: el reproductor no ha notado problemas)\n")
        list.asReversed().forEach { sb.append("• ").append(it).append('\n') }
        return sb.toString()
    }
}
