package com.near.mimusica

import java.net.HttpURLConnection
import java.net.URL

/**
 * Conexión con el servidor de acceso (Firebase): códigos de invitación y modo admin,
 * y con Gemini para la traducción con IA. Cualquier otra dirección se rechaza.
 */
object Acceso {
    private fun allowed(url: String): Boolean {
        if (!url.startsWith("https://")) return false
        val host = url.removePrefix("https://").substringBefore('/').substringBefore('?').lowercase()
        return host == "identitytoolkit.googleapis.com" ||
            host == "securetoken.googleapis.com" ||
            host.endsWith(".firebaseio.com") ||
            host.endsWith(".firebasedatabase.app") ||
            host == "generativelanguage.googleapis.com"
    }

    /** Devuelve (código HTTP, respuesta). Código 0 = sin conexión o dirección no permitida. */
    fun http(method: String, url: String, body: String, contentType: String): Pair<Int, String> {
        if (!allowed(url)) return 0 to "BLOQUEADA"
        val m = method.uppercase()
        val c = URL(url).openConnection() as HttpURLConnection
        val ai = url.contains("generativelanguage.googleapis.com")
        c.connectTimeout = if (ai) 15000 else 8000
        // traducir una canción completa con IA puede tardar
        c.readTimeout = if (ai) 75000 else 12000
        c.setRequestProperty("Accept", "application/json")
        if (m == "PATCH") {
            // HttpURLConnection no conoce PATCH: Firebase acepta POST con esta cabecera
            c.requestMethod = "POST"
            c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
        } else {
            c.requestMethod = m
        }
        return try {
            if (m != "GET" && m != "DELETE") {
                c.doOutput = true
                c.setRequestProperty("Content-Type", contentType.ifEmpty { "application/json" })
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            code to text
        } finally {
            c.disconnect()
        }
    }
}
