package com.near.mimusica

import android.content.Context
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Busca carátulas oficiales en el catálogo de Apple Music (iTunes Search, sin clave)
 * y guarda la elegida en buena calidad como carátula propia de la canción.
 */
object CoverSearch {
    private fun get(url: String, max: Int): ByteArray? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "NEAR-Music/1.0 (Android)")
        try {
            if (c.responseCode != 200) return null
            c.inputStream.use { inp ->
                val out = ByteArrayOutputStream()
                val buf = ByteArray(16384)
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > max) return null
                }
                return out.toByteArray()
            }
        } finally {
            c.disconnect()
        }
    }

    /** Resultados: [{p: vista previa, h: alta calidad, t, a, al}] (sin repetir la misma imagen). */
    fun search(term: String): String {
        val q = URLEncoder.encode(term.trim(), "UTF-8")
        val body = get("https://itunes.apple.com/search?term=$q&media=music&entity=song&limit=25", 2_000_000)
            ?: return "[]"
        val res = JSONObject(String(body, Charsets.UTF_8)).optJSONArray("results") ?: JSONArray()
        val out = JSONArray()
        val seen = HashSet<String>()
        for (i in 0 until res.length()) {
            val o = res.optJSONObject(i) ?: continue
            val art = o.optString("artworkUrl100", "")
            if (art.isEmpty() || !art.contains("100x100")) continue
            val base = art.substringBeforeLast('/')
            if (!seen.add(base)) continue
            out.put(
                JSONObject()
                    .put("p", art.replace("100x100", "600x600"))
                    .put("h", art.replace("100x100", "1400x1400"))
                    .put("t", o.optString("trackName", ""))
                    .put("a", o.optString("artistName", ""))
                    .put("al", o.optString("collectionName", ""))
            )
            if (out.length() >= 12) break
        }
        return out.toString()
    }

    /** Baja la imagen (si la grande no existe prueba más pequeñas) y la guarda como carátula de la canción. */
    fun download(ctx: Context, id: Long, url: String): Boolean {
        if (!url.startsWith("https://")) return false
        val tries = listOf(url, url.replace("1400x1400", "1000x1000"), url.replace("1400x1400", "600x600")).distinct()
        for (u in tries) {
            val b = try { get(u, 8_000_000) } catch (e: Exception) { null } ?: continue
            val bmp = BitmapFactory.decodeByteArray(b, 0, b.size) ?: continue
            if (Covers.saveBitmap(ctx, id, bmp)) return true
        }
        return false
    }

    /** De estas canciones, las que no tienen carátula (ni propia ni dentro del archivo). */
    fun missing(ctx: Context, ids: JSONArray): String {
        val out = JSONArray()
        for (i in 0 until ids.length()) {
            val id = ids.optString(i).toLongOrNull() ?: continue
            val has = try { ArtLoader.bitmap(ctx, id, 48) != null } catch (e: Throwable) { true }
            if (!has) out.put(id.toString())
        }
        return out.toString()
    }
}
