package com.near.mimusica

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Avisa cuando hay una versión nueva de NEAR Music en GitHub, con una notificación
 * que parece de banco ("te llegó un pago") pero lo que llegó es la actualización.
 */
object UpdateCheck {
    private const val API = "https://api.github.com/repos/ronaldaraujo123zzz-del/mi-musica/releases/latest"
    private const val CHANNEL = "actualizaciones"
    private const val JOB_ID = 4190

    /** Programa la revisión cada ~6 horas (con internet). Se puede llamar las veces que sea. */
    fun schedule(ctx: Context) {
        try {
            val js = ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            if (js.allPendingJobs.any { it.id == JOB_ID }) return
            val job = JobInfo.Builder(JOB_ID, ComponentName(ctx, UpdateJob::class.java))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(6 * 60 * 60 * 1000L)
                .setPersisted(true)
                .build()
            js.schedule(job)
        } catch (e: Exception) {
        }
    }

    private fun myVersion(ctx: Context): Long = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else @Suppress("DEPRECATION") pi.versionCode.toLong()
    } catch (e: Exception) {
        0L
    }

    /** Revisa GitHub y avisa si hay una versión más nueva que no se haya avisado ya. Va en un hilo aparte. */
    fun check(ctx: Context) {
        val sp = ctx.getSharedPreferences("mm", Context.MODE_PRIVATE)
        var con: HttpURLConnection? = null
        try {
            con = (URL(API).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000; readTimeout = 15_000
                setRequestProperty("Accept", "application/vnd.github+json")
                setRequestProperty("User-Agent", "NEAR-Music")
            }
            if (con.responseCode != 200) return
            val o = JSONObject(con.inputStream.bufferedReader().readText())
            val tag = o.optString("tag_name").trimStart('v', 'V')
            val num = tag.toLongOrNull() ?: return
            val mine = myVersion(ctx)
            if (mine <= 0 || num <= mine) return
            if (sp.getLong("updAvisada", 0L) >= num) return
            var url = o.optString("html_url")
            val assets = o.optJSONArray("assets")
            if (assets != null) for (i in 0 until assets.length()) {
                val a = assets.optJSONObject(i) ?: continue
                if (a.optString("name").endsWith(".apk")) { url = a.optString("browser_download_url"); break }
            }
            if (notify(ctx, num, url)) sp.edit().putLong("updAvisada", num).apply()
        } catch (e: Exception) {
        } finally {
            try { con?.disconnect() } catch (e: Exception) {}
        }
    }

    private fun notify(ctx: Context, num: Long, url: String): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Versiones nuevas", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Avisa cuando sale una versión nueva de NEAR Music"
            })
        }
        val open = PendingIntent.getActivity(
            ctx, 41, Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val pic = try { BitmapFactory.decodeResource(ctx.resources, R.drawable.notif_meme) } catch (e: Exception) { null }
        val text = "Te llegó la versión 1.$num de NEAR Music. Concepto: actualización 💛 Toca para descargarla."
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_upd)
            .setLargeIcon(pic)
            .setContentTitle("💸 Recibiste una actualización")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setSubText("NEAR Music")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        return try {
            NotificationManagerCompat.from(ctx).notify(4190, n)
            true
        } catch (e: SecurityException) {
            false
        }
    }
}

/** Trabajo de fondo que revisa si hay versión nueva. */
class UpdateJob : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        Thread {
            UpdateCheck.check(applicationContext)
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true
}
