package com.near.mimusica

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.Size

/** Lee la portada de una canción (para la app y para el widget). */
object ArtLoader {
    fun bitmap(ctx: Context, id: Long, max: Int): Bitmap? {
        val uri = Library.uri(id)
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                return ctx.contentResolver.loadThumbnail(uri, Size(max, max), null)
            } catch (e: Exception) {
                // sin portada en la miniatura: probamos leyendo el archivo
            }
        }
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val pic = r.embeddedPicture ?: return null
            val bmp = BitmapFactory.decodeByteArray(pic, 0, pic.size) ?: return null
            val scale = minOf(1f, max.toFloat() / maxOf(bmp.width, bmp.height))
            return if (scale < 1f) {
                Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
            } else bmp
        } catch (e: Exception) {
            return null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
    }
}
