package com.near.mimusica

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import org.json.JSONObject
import java.io.File

/**
 * Carátulas que tú le pones a una canción (para las que no traen o traen una fea).
 * Se guarda una copia cuadrada en la app: covers/<id>_<hora>.jpg. El archivo de música no se toca.
 */
object Covers {
    private const val SIZE = 800

    @Volatile
    private var dir: File? = null

    @Volatile
    private var map: Map<Long, File> = emptyMap()

    @Synchronized
    fun init(ctx: Context) {
        if (dir != null) return
        val d = File(ctx.applicationContext.filesDir, "covers")
        d.mkdirs()
        dir = d
        val m = HashMap<Long, File>()
        d.listFiles()?.forEach { f ->
            val id = f.name.substringBefore('_').toLongOrNull() ?: return@forEach
            val old = m[id]
            if (old == null || f.name > old.name) {
                old?.delete()
                m.put(id, f)
            } else {
                f.delete()
            }
        }
        map = m
    }

    fun file(id: Long): File? = map[id]?.takeIf { it.isFile }

    /** Versión de cada carátula puesta (la interfaz la usa para no mostrar una vieja). */
    fun versionsJson(): String {
        val o = JSONObject()
        for ((id, f) in map) o.put(id.toString(), f.name.substringAfter('_').substringBefore('.'))
        return o.toString()
    }

    fun version(id: Long): String = file(id)?.name?.substringAfter('_')?.substringBefore('.') ?: ""

    @Synchronized
    fun save(ctx: Context, id: Long, uri: Uri): Boolean = try {
        init(ctx)
        val src = Bg.decode(ctx, uri, 1600) ?: throw IllegalStateException("sin imagen")
        // recorte cuadrado del centro
        val side = minOf(src.width, src.height)
        val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        val out = if (side > SIZE) Bitmap.createScaledBitmap(sq, SIZE, SIZE, true) else sq
        val f = File(dir, "${id}_${System.currentTimeMillis()}.jpg")
        f.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        map[id]?.delete()
        map = HashMap(map).apply { put(id, f) }
        true
    } catch (e: Throwable) {
        false
    }

    @Synchronized
    fun clear(ctx: Context, id: Long) {
        init(ctx)
        map[id]?.delete()
        map = HashMap(map).apply { remove(id) }
    }
}
