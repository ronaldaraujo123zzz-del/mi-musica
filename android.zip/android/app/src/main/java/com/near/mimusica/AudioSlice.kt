package com.near.mimusica

import java.io.OutputStream

/**
 * Corta un pedazo de una canción sin volver a comprimirla (no pierde calidad):
 *  - MP3: copia los cuadros de audio que caen entre A y B.
 *  - WAV: copia las muestras entre A y B con una cabecera nueva.
 * (M4A/AAC se hace en Clip.kt con las herramientas de Android.)
 */
object AudioSlice {
    private val BR_V1 = intArrayOf(0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0)
    private val BR_V2 = intArrayOf(0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0)
    private val SR_V1 = intArrayOf(44100, 48000, 32000, 0)
    private val SR_V2 = intArrayOf(22050, 24000, 16000, 0)
    private val SR_V25 = intArrayOf(11025, 12000, 8000, 0)

    private class Frame(val len: Int, val ms: Double)

    private fun frameAt(d: ByteArray, p: Int): Frame? {
        if (p + 4 > d.size) return null
        val b1 = d[p].toInt() and 0xFF
        val b2 = d[p + 1].toInt() and 0xFF
        val b3 = d[p + 2].toInt() and 0xFF
        if (b1 != 0xFF || (b2 and 0xE0) != 0xE0) return null
        val ver = (b2 shr 3) and 3      // 0 = 2.5, 2 = 2, 3 = 1
        val layer = (b2 shr 1) and 3    // 1 = Layer III
        if (ver == 1 || layer != 1) return null
        val brIdx = (b3 shr 4) and 15
        val srIdx = (b3 shr 2) and 3
        val pad = (b3 shr 1) and 1
        if (brIdx == 0 || brIdx == 15 || srIdx == 3) return null
        val v1 = ver == 3
        val br = (if (v1) BR_V1 else BR_V2)[brIdx] * 1000
        val sr = when (ver) { 3 -> SR_V1; 2 -> SR_V2; else -> SR_V25 }[srIdx]
        val samples = if (v1) 1152 else 576
        val len = (if (v1) 144 else 72) * br / sr + pad
        if (len < 24) return null
        return Frame(len, samples * 1000.0 / sr)
    }

    private fun isInfoFrame(d: ByteArray, p: Int, len: Int): Boolean {
        val end = minOf(d.size - 4, p + minOf(len, 60))
        for (i in p + 4..end) {
            val s = String(d, i, 4, Charsets.ISO_8859_1)
            if (s == "Xing" || s == "Info" || s == "VBRI") return true
        }
        return false
    }

    /** Devuelve cuántos milisegundos se escribieron. */
    fun mp3(d: ByteArray, aMs: Long, bMs: Long, out: OutputStream): Long {
        var p = 0
        if (d.size > 10 && d[0] == 'I'.code.toByte() && d[1] == 'D'.code.toByte() && d[2] == '3'.code.toByte()) {
            val size = ((d[6].toInt() and 0x7F) shl 21) or ((d[7].toInt() and 0x7F) shl 14) or
                ((d[8].toInt() and 0x7F) shl 7) or (d[9].toInt() and 0x7F)
            p = 10 + size + (if ((d[5].toInt() and 0x10) != 0) 10 else 0)
        }
        var t = 0.0
        var first = true
        var written = 0.0
        while (p < d.size - 4) {
            val f = frameAt(d, p)
            // un cuadro válido debe ir seguido de otro (o del final): así no nos confundimos con basura
            if (f == null || (p + f.len < d.size - 4 && frameAt(d, p + f.len) == null && p + f.len + 128 < d.size)) {
                p++
                continue
            }
            if (first) {
                first = false
                if (isInfoFrame(d, p, f.len)) { p += f.len; continue }
            }
            if (t + f.ms / 2 >= aMs && t < bMs) {
                out.write(d, p, minOf(f.len, d.size - p))
                written += f.ms
            }
            t += f.ms
            p += f.len
            if (t >= bMs) break
        }
        if (written <= 0.0) throw IllegalStateException("No se encontró audio en ese tramo")
        return written.toLong()
    }

    private fun le32(d: ByteArray, p: Int): Long =
        ((d[p].toLong() and 0xFF) or ((d[p + 1].toLong() and 0xFF) shl 8) or
            ((d[p + 2].toLong() and 0xFF) shl 16) or ((d[p + 3].toLong() and 0xFF) shl 24))

    private fun le16(d: ByteArray, p: Int): Int = (d[p].toInt() and 0xFF) or ((d[p + 1].toInt() and 0xFF) shl 8)

    private fun w32(out: OutputStream, v: Long) {
        out.write((v and 0xFF).toInt()); out.write(((v shr 8) and 0xFF).toInt())
        out.write(((v shr 16) and 0xFF).toInt()); out.write(((v shr 24) and 0xFF).toInt())
    }

    fun isWav(d: ByteArray) = d.size > 12 && String(d, 0, 4, Charsets.ISO_8859_1) == "RIFF" &&
        String(d, 8, 4, Charsets.ISO_8859_1) == "WAVE"

    fun wav(d: ByteArray, aMs: Long, bMs: Long, out: OutputStream): Long {
        if (!isWav(d)) throw IllegalStateException("No es un WAV")
        var p = 12
        var fmtAt = -1
        var fmtLen = 0
        var dataAt = -1
        var dataLen = 0L
        while (p + 8 <= d.size) {
            val id = String(d, p, 4, Charsets.ISO_8859_1)
            val len = le32(d, p + 4)
            if (id == "fmt ") { fmtAt = p + 8; fmtLen = len.toInt() }
            if (id == "data") { dataAt = p + 8; dataLen = minOf(len, (d.size - dataAt).toLong()); break }
            p += 8 + len.toInt() + (len.toInt() and 1)
        }
        if (fmtAt < 0 || dataAt < 0 || fmtLen < 16) throw IllegalStateException("WAV dañado")
        val rate = le32(d, fmtAt + 4)
        val align = le16(d, fmtAt + 12).coerceAtLeast(1)
        val frames = dataLen / align
        val fa = (aMs * rate / 1000).coerceIn(0, frames)
        val fb = (bMs * rate / 1000).coerceIn(fa, frames)
        val bytes = (fb - fa) * align
        if (bytes <= 0) throw IllegalStateException("Tramo vacío")
        out.write("RIFF".toByteArray(Charsets.ISO_8859_1))
        w32(out, 4 + 8 + fmtLen + 8 + bytes)
        out.write("WAVE".toByteArray(Charsets.ISO_8859_1))
        out.write("fmt ".toByteArray(Charsets.ISO_8859_1))
        w32(out, fmtLen.toLong())
        out.write(d, fmtAt, fmtLen)
        out.write("data".toByteArray(Charsets.ISO_8859_1))
        w32(out, bytes)
        out.write(d, (dataAt + fa * align).toInt(), bytes.toInt())
        return (fb - fa) * 1000 / rate
    }
}
