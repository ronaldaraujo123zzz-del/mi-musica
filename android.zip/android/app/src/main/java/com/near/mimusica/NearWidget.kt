package com.near.mimusica

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.RemoteViews

/** Lo que muestra el widget. */
data class WidgetNow(val id: String, val title: String, val artist: String, val playing: Boolean, val lyric: String = "")

/** Widget de la pantalla de inicio: portada, nombre y botones anterior / pausa / siguiente. */
class NearWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val svc = PlaybackService.instance
        if (svc != null) svc.refreshWidget() else update(context, null)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        if (action != A_TOGGLE && action != A_NEXT && action != A_PREV) return
        val svc = PlaybackService.instance
        if (svc != null) svc.widgetAction(action) else update(context, null)
    }

    companion object {
        const val A_TOGGLE = "com.near.mimusica.W_TOGGLE"
        const val A_NEXT = "com.near.mimusica.W_NEXT"
        const val A_PREV = "com.near.mimusica.W_PREV"

        @Volatile
        private var artId = ""

        @Volatile
        private var art: Bitmap? = null

        private fun broadcast(ctx: Context, action: String, code: Int): PendingIntent =
            PendingIntent.getBroadcast(
                ctx, code, Intent(ctx, NearWidget::class.java).setAction(action),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        fun update(context: Context, now: WidgetNow?) {
            val app = context.applicationContext
            val mgr = AppWidgetManager.getInstance(app) ?: return
            val cn = ComponentName(app, NearWidget::class.java)
            val ids = try {
                mgr.getAppWidgetIds(cn)
            } catch (e: Exception) {
                return
            }
            if (ids == null || ids.isEmpty()) return
            Thread {
                try {
                    var bmp: Bitmap? = null
                    if (now != null) {
                        if (now.id == artId) {
                            bmp = art
                        } else {
                            bmp = now.id.toLongOrNull()?.let { ArtLoader.bitmap(app, it, 200) }
                            artId = now.id
                            art = bmp
                        }
                    }
                    val v = RemoteViews(app.packageName, R.layout.widget)
                    val open = PendingIntent.getActivity(
                        app, 10, Intent(app, MainActivity::class.java),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    v.setOnClickPendingIntent(R.id.w_root, open)
                    v.setOnClickPendingIntent(R.id.w_cover, open)
                    if (now == null) {
                        v.setTextViewText(R.id.w_title, "NEAR Music")
                        v.setTextViewText(R.id.w_artist, "Toca para abrir")
                        v.setViewVisibility(R.id.w_lyric, android.view.View.GONE)
                        v.setImageViewResource(R.id.w_cover, R.drawable.widget_logo)
                        v.setImageViewResource(R.id.w_play, R.drawable.ic_w_play)
                        v.setOnClickPendingIntent(R.id.w_play, open)
                        v.setOnClickPendingIntent(R.id.w_next, open)
                        v.setOnClickPendingIntent(R.id.w_prev, open)
                    } else {
                        v.setTextViewText(R.id.w_title, now.title)
                        v.setTextViewText(R.id.w_artist, now.artist)
                        v.setTextViewText(R.id.w_lyric, "♪ " + now.lyric)
                        v.setViewVisibility(R.id.w_lyric, if (now.lyric.isNotEmpty()) android.view.View.VISIBLE else android.view.View.GONE)
                        if (bmp != null) v.setImageViewBitmap(R.id.w_cover, bmp)
                        else v.setImageViewResource(R.id.w_cover, R.drawable.widget_logo)
                        v.setImageViewResource(R.id.w_play, if (now.playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
                        v.setOnClickPendingIntent(R.id.w_play, broadcast(app, A_TOGGLE, 11))
                        v.setOnClickPendingIntent(R.id.w_next, broadcast(app, A_NEXT, 12))
                        v.setOnClickPendingIntent(R.id.w_prev, broadcast(app, A_PREV, 13))
                    }
                    mgr.updateAppWidget(cn, v)
                } catch (e: Exception) {
                    // si algo falla, el widget se queda como estaba
                }
            }.start()
        }
    }
}
