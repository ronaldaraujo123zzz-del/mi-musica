package com.near.mimusica

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import org.json.JSONArray
import org.json.JSONObject

/** Lee todas las canciones del teléfono desde la biblioteca de Android (MediaStore). */
object Library {
    data class Song(
        val id: Long,
        val title: String,
        val artist: String,
        val album: String,
        val albumId: Long,
        val duration: Long,
        val added: Long,
        val path: String
    )

    @Volatile
    var songs: Map<Long, Song> = emptyMap()

    /** Nombres que cambiaste en la app: id -> [título, artista, álbum] ("" = sin cambio). */
    @Volatile
    var over: Map<String, Array<String>> = emptyMap()

    fun setOverrides(json: String) {
        val m = HashMap<String, Array<String>>()
        try {
            val o = JSONObject(json)
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = o.optJSONObject(k) ?: continue
                m[k] = arrayOf(v.optString("t"), v.optString("a"), v.optString("al"))
            }
        } catch (e: Exception) {
        }
        over = m
    }

    private val SKIP = Regex(
        "(?i)(/notifications/|/ringtones/|/alarms/|voice notes|/recordings/|call ?rec|/android/data/)"
    )

    fun scan(ctx: Context): List<Song> {
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        @Suppress("DEPRECATION")
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DISPLAY_NAME
        )
        val selection = "${MediaStore.Audio.Media.DURATION} >= 30000"
        val list = ArrayList<Song>()
        ctx.contentResolver.query(uri, projection, selection, null, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(projection[0])
            val iTitle = c.getColumnIndexOrThrow(projection[1])
            val iArtist = c.getColumnIndexOrThrow(projection[2])
            val iAlbum = c.getColumnIndexOrThrow(projection[3])
            val iAlbumId = c.getColumnIndexOrThrow(projection[4])
            val iDur = c.getColumnIndexOrThrow(projection[5])
            val iAdded = c.getColumnIndexOrThrow(projection[6])
            val iData = c.getColumnIndexOrThrow(projection[7])
            val iName = c.getColumnIndexOrThrow(projection[8])
            while (c.moveToNext()) {
                val path = c.getString(iData) ?: ""
                if (SKIP.containsMatchIn(path)) continue
                val name = c.getString(iName) ?: ""
                var title = (c.getString(iTitle) ?: "").trim()
                if (title.isEmpty()) title = name.substringBeforeLast('.')
                var artist = (c.getString(iArtist) ?: "").trim()
                if (artist.isEmpty() || artist == "<unknown>") artist = "Artista desconocido"
                var album = (c.getString(iAlbum) ?: "").trim()
                if (album == "<unknown>") album = ""
                list.add(
                    Song(
                        c.getLong(iId), title, artist, album, c.getLong(iAlbumId),
                        c.getLong(iDur), c.getLong(iAdded), path
                    )
                )
            }
        }
        songs = list.associateBy { it.id }
        return list
    }

    fun toJson(list: List<Song>): String {
        val arr = JSONArray()
        for (s in list) {
            arr.put(
                JSONObject()
                    .put("id", s.id.toString())
                    .put("t", s.title)
                    .put("a", s.artist)
                    .put("al", s.album)
                    .put("d", s.duration)
                    .put("ad", s.added)
            )
        }
        return arr.toString()
    }

    fun uri(id: Long): Uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

    fun mediaItem(s: Song): MediaItem {
        val art = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), s.albumId)
        val o = over[s.id.toString()]
        val title = o?.get(0)?.ifEmpty { null } ?: s.title
        val artist = o?.get(1)?.ifEmpty { null } ?: s.artist
        val album = o?.get(2)?.ifEmpty { null } ?: s.album
        val extras = android.os.Bundle()
        extras.putString("a", artist) // el artista de verdad (la notificación puede mostrar la letra en su lugar)
        val meta = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(art)
            .setExtras(extras)
            .build()
        return MediaItem.Builder()
            .setMediaId(s.id.toString())
            .setUri(uri(s.id))
            .setMediaMetadata(meta)
            .build()
    }
}
