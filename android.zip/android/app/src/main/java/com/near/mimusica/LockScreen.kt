package com.near.mimusica

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.abs

/** Lo que suena ahora, para la pantalla de bloqueo. */
class LockNow(
    val id: String,
    val title: String,
    val artist: String,
    val playing: Boolean,
    val pos: Long,
    val dur: Long,
    val lines: List<Pair<Long, String>>
)

/**
 * Letra en la pantalla de bloqueo: al apagar la pantalla mientras suena una canción,
 * la app pone su propia pantalla encima del bloqueo con la letra en grande.
 */
object LockLyrics {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("mm", Context.MODE_PRIVATE)

    fun enabled(ctx: Context): Boolean = sp(ctx).getBoolean("lockLyrics", false)

    fun setEnabled(ctx: Context, on: Boolean) {
        sp(ctx).edit().putBoolean("lockLyrics", on).apply()
    }

    /**
     * Desde Android 10 una app no puede abrir una pantalla estando en segundo plano,
     * salvo que tenga el permiso "Mostrar sobre otras apps".
     */
    fun needsPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT >= 29 && !Settings.canDrawOverlays(ctx)

    fun permissionIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))

    /** Se llama al apagarse la pantalla. */
    fun onScreenOff(ctx: Context, playing: Boolean) {
        if (!enabled(ctx) || !playing || needsPermission(ctx)) return
        // en una llamada la pantalla se apaga con el sensor de la oreja: ahí no estorbar
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (am != null && (am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION)) return
        show(ctx)
    }

    fun show(ctx: Context) {
        try {
            ctx.startActivity(
                Intent(ctx, LockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        } catch (e: Exception) {
            // el teléfono no dejó abrirla: no pasa nada, queda el bloqueo normal
        }
    }
}

class LockActivity : ComponentActivity() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var bg: ImageView
    private lateinit var cover: ImageView
    private lateinit var tTitle: TextView
    private lateinit var tArtist: TextView
    private lateinit var lPrev: TextView
    private lateinit var lCur: TextView
    private lateinit var lNext: TextView
    private lateinit var bar: Bar
    private lateinit var playBtn: ImageView
    private lateinit var content: LinearLayout
    private var shownId = ""
    private var shownIdx = -99
    private var artJob = 0

    private val unlocked = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            // desbloqueaste con la huella o la cara: esta pantalla ya no hace falta
            if (i.action == Intent.ACTION_USER_PRESENT) finish()
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            main.postDelayed(this, 120)
        }
    }

    private fun dp(v: Float): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF0C0826.toInt())
        bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        root.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x66000000, 0x33000000, 0xB3000000.toInt())
            )
        }, FrameLayout.LayoutParams(-1, -1))

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(26f), dp(60f), dp(26f), dp(28f))
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        // hora y fecha
        content.addView(TextClock(this).apply {
            format12Hour = "h:mm"
            format24Hour = "H:mm"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 76f)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER_HORIZONTAL
        }, LinearLayout.LayoutParams(-1, -2))
        content.addView(TextClock(this).apply {
            format12Hour = "EEEE, d 'de' MMMM"
            format24Hour = "EEEE, d 'de' MMMM"
            setTextColor(0xDDFFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            gravity = Gravity.CENTER_HORIZONTAL
        }, LinearLayout.LayoutParams(-1, -2))

        // la letra: anterior, actual (grande) y siguiente
        val lyr = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun line(size: Float, bold: Boolean, alpha: Int) = TextView(this).apply {
            setTextColor(Color.argb(alpha, 255, 255, 255))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
            setShadowLayer(dp(8f).toFloat(), 0f, dp(2f).toFloat(), 0x99000000.toInt())
            setLineSpacing(0f, 1.08f)
            maxLines = if (bold) 4 else 2
            ellipsize = TextUtils.TruncateAt.END
        }
        lPrev = line(19f, false, 120)
        lCur = line(33f, true, 255)
        lNext = line(19f, false, 150)
        lyr.addView(lPrev, LinearLayout.LayoutParams(-1, -2))
        lyr.addView(lCur, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14f); bottomMargin = dp(14f) })
        lyr.addView(lNext, LinearLayout.LayoutParams(-1, -2))
        content.addView(lyr, LinearLayout.LayoutParams(-1, 0, 1f))

        // canción
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        cover = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            background = GradientDrawable().apply { cornerRadius = dp(12f).toFloat(); setColor(0x33FFFFFF) }
        }
        row.addView(cover, LinearLayout.LayoutParams(dp(58f), dp(58f)))
        val meta = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14f), 0, 0, 0) }
        tTitle = TextView(this).apply {
            setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        tArtist = TextView(this).apply {
            setTextColor(0xBBFFFFFF.toInt()); setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        meta.addView(tTitle); meta.addView(tArtist)
        row.addView(meta, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(row, LinearLayout.LayoutParams(-1, -2))

        bar = Bar(this)
        content.addView(bar, LinearLayout.LayoutParams(-1, dp(18f)).apply { topMargin = dp(12f) })

        // botones
        val ctr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun btn(icon: Int, size: Float, action: String) = ImageView(this).apply {
            setImageResource(icon)
            setColorFilter(Color.WHITE)
            val pad = dp(10f)
            setPadding(pad, pad, pad, pad)
            setOnClickListener { PlaybackService.instance?.widgetAction(action); main.post { refresh() } }
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { leftMargin = dp(18f); rightMargin = dp(18f) }
        }
        ctr.addView(btn(R.drawable.ic_w_prev, 56f, NearWidget.A_PREV))
        playBtn = btn(R.drawable.ic_w_pause, 72f, NearWidget.A_TOGGLE)
        playBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x33FFFFFF) }
        ctr.addView(playBtn)
        ctr.addView(btn(R.drawable.ic_w_next, 56f, NearWidget.A_NEXT))
        content.addView(ctr, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10f) })

        content.addView(TextView(this).apply {
            text = "︿\nDesliza hacia arriba para desbloquear"
            setTextColor(0x99FFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER_HORIZONTAL
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16f) })

        setContentView(root)
        WindowInsetsControllerCompat(window, root).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
            hide(WindowInsetsCompat.Type.navigationBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        // deslizar hacia arriba: desbloquear (si no hay bloqueo, solo se cierra)
        var downY = 0f
        var moved = false
        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downY = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dy = (downY - e.rawY).coerceAtLeast(0f)
                    content.translationY = -dy * 0.5f
                    content.alpha = (1f - dy / (root.height * 0.6f)).coerceIn(0.2f, 1f)
                    if (dy > dp(12f)) moved = true
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val dy = downY - e.rawY
                    if (moved && dy > root.height * 0.18f) unlock()
                    else content.animate().translationY(0f).alpha(1f).setDuration(180).start()
                    true
                }
                else -> false
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = unlock()
        })

        ContextCompat.registerReceiver(this, unlocked, IntentFilter(Intent.ACTION_USER_PRESENT), ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    private fun unlock() {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (km.isKeyguardLocked) {
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() { finish() }
                override fun onDismissError() { finish() }
                override fun onDismissCancelled() {
                    content.animate().translationY(0f).alpha(1f).setDuration(180).start()
                }
            })
        } else finish()
    }

    override fun onResume() {
        super.onResume()
        main.removeCallbacks(tick)
        main.post(tick)
    }

    override fun onPause() {
        super.onPause()
        main.removeCallbacks(tick)
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(unlocked) } catch (e: Exception) {}
        super.onDestroy()
    }

    private fun refresh() {
        val svc = PlaybackService.instance
        val now = svc?.lockSnapshot()
        if (now == null) {
            finish()
            return
        }
        if (now.id != shownId) {
            shownId = now.id
            shownIdx = -99
            tTitle.text = now.title
            tArtist.text = now.artist
            loadArt(now.id)
        }
        playBtn.setImageResource(if (now.playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        bar.set(now.pos, now.dur)

        val lines = now.lines
        if (lines.isEmpty()) {
            if (shownIdx != -50) {
                shownIdx = -50
                lPrev.text = ""
                lCur.text = "♪"
                lNext.text = "Esta canción no tiene letra sincronizada"
            }
            return
        }
        var i = -1
        for (k in lines.indices) {
            if (lines[k].first <= now.pos + 150) i = k else break
        }
        if (i == shownIdx) return
        val first = shownIdx == -99
        shownIdx = i
        fun txt(k: Int): String {
            val t = lines.getOrNull(k)?.second?.trim() ?: return ""
            return t.ifEmpty { "♪" }
        }
        val cur = if (i < 0) "♪" else txt(i)
        val prev = if (i <= 0) "" else txt(i - 1)
        val next = txt(i + 1)
        if (first) {
            lPrev.text = prev; lCur.text = cur; lNext.text = next
            return
        }
        // la línea nueva sube suavecito
        lCur.animate().cancel()
        lCur.alpha = 0f
        lCur.translationY = dp(18f).toFloat()
        lPrev.text = prev; lCur.text = cur; lNext.text = next
        lCur.animate().alpha(1f).translationY(0f).setDuration(260).start()
    }

    private fun loadArt(mediaId: String) {
        val id = mediaId.toLongOrNull()
        val job = ++artJob
        if (id == null) {
            cover.setImageDrawable(null); bg.setImageDrawable(null)
            return
        }
        val app = applicationContext
        Thread {
            val bmp = try { ArtLoader.bitmap(app, id, 512) } catch (e: Throwable) { null }
            val blurred = if (bmp != null && Build.VERSION.SDK_INT < 31) softBlur(bmp) else null
            main.post {
                if (job != artJob || isFinishing) return@post
                cover.setImageBitmap(bmp)
                if (bmp == null) {
                    bg.setImageDrawable(null)
                    if (Build.VERSION.SDK_INT >= 31) bg.setRenderEffect(null)
                } else if (Build.VERSION.SDK_INT >= 31) {
                    bg.setImageBitmap(bmp)
                    bg.setRenderEffect(RenderEffect.createBlurEffect(dp(40f).toFloat(), dp(40f).toFloat(), Shader.TileMode.CLAMP))
                } else {
                    bg.setImageBitmap(blurred)
                }
            }
        }.start()
    }

    /** Desenfoque barato para teléfonos viejos: achicar mucho y volver a agrandar. */
    private fun softBlur(src: Bitmap): Bitmap {
        val small = Bitmap.createScaledBitmap(src, 12, (12f * src.height / src.width).toInt().coerceAtLeast(12), true)
        val mid = Bitmap.createScaledBitmap(small, 48, (48f * small.height / small.width).toInt().coerceAtLeast(48), true)
        return Bitmap.createScaledBitmap(mid, 192, (192f * mid.height / mid.width).toInt().coerceAtLeast(192), true)
    }

    /** Barra de avance con los tiempos. */
    private class Bar(ctx: Context) : View(ctx) {
        private var pos = 0L
        private var dur = 0L
        private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xAAFFFFFF.toInt()
            textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 11f, ctx.resources.displayMetrics)
        }

        fun set(p: Long, d: Long) {
            if (abs(p - pos) < 250 && d == dur) return
            pos = p; dur = d; invalidate()
        }

        private fun fmt(ms: Long): String {
            val t = (ms.coerceAtLeast(0L) / 1000).toInt()
            return "${t / 60}:${(t % 60).toString().padStart(2, '0')}"
        }

        override fun onDraw(c: Canvas) {
            val h = height.toFloat()
            val w = width.toFloat()
            val ty = h * 0.25f
            val bh = h * 0.16f
            c.drawRoundRect(0f, ty, w, ty + bh, bh, bh, track)
            val p = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
            c.drawRoundRect(0f, ty, w * p, ty + bh, bh, bh, fill)
            txt.textAlign = Paint.Align.LEFT
            c.drawText(fmt(pos), 0f, h, txt)
            txt.textAlign = Paint.Align.RIGHT
            c.drawText(if (dur > 0) fmt(dur) else "", w, h, txt)
        }
    }
}
