package com.near.mimusica

import android.content.Context
import org.json.JSONObject

/** Cuenta cuántas veces escuchas cada canción (cuenta aunque la pantalla esté apagada). */
object Stats {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("mm_stats", Context.MODE_PRIVATE)

    @Synchronized
    fun add(ctx: Context, id: String) {
        if (id.isEmpty()) return
        val o = read(ctx)
        o.put(id, o.optInt(id, 0) + 1)
        prefs(ctx).edit().putString("plays", o.toString()).apply()
    }

    @Synchronized
    fun json(ctx: Context): String = read(ctx).toString()

    private fun read(ctx: Context): JSONObject =
        try {
            JSONObject(prefs(ctx).getString("plays", "{}") ?: "{}")
        } catch (e: Throwable) {
            JSONObject()
        }
}
