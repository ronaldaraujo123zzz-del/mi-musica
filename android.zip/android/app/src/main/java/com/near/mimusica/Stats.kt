package com.near.mimusica

import android.content.Context
import org.json.JSONObject

/**
 * Cuenta cuántas veces escuchas cada canción y cuándo fue la última vez
 * (cuenta aunque la pantalla esté apagada).
 */
object Stats {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("mm_stats", Context.MODE_PRIVATE)

    private fun read(ctx: Context, key: String): JSONObject =
        try {
            JSONObject(prefs(ctx).getString(key, "{}") ?: "{}")
        } catch (e: Throwable) {
            JSONObject()
        }

    @Synchronized
    fun add(ctx: Context, id: String) {
        if (id.isEmpty()) return
        val plays = read(ctx, "plays")
        plays.put(id, plays.optInt(id, 0) + 1)
        val last = read(ctx, "last")
        last.put(id, System.currentTimeMillis())
        prefs(ctx).edit()
            .putString("plays", plays.toString())
            .putString("last", last.toString())
            .apply()
    }

    /** {"id": veces} */
    @Synchronized
    fun json(ctx: Context): String = read(ctx, "plays").toString()

    /** {"id": fecha de la última escucha en milisegundos} */
    @Synchronized
    fun lastJson(ctx: Context): String = read(ctx, "last").toString()

    /** Junta datos de una copia de seguridad: {"plays":{...},"last":{...}} (se queda con el mayor). */
    @Synchronized
    fun merge(ctx: Context, json: String) {
        val inc = try {
            JSONObject(json)
        } catch (e: Throwable) {
            return
        }
        val plays = read(ctx, "plays")
        val last = read(ctx, "last")
        inc.optJSONObject("plays")?.let { p ->
            val keys = p.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                plays.put(k, maxOf(plays.optInt(k, 0), p.optInt(k, 0)))
            }
        }
        inc.optJSONObject("last")?.let { l ->
            val keys = l.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                last.put(k, maxOf(last.optLong(k, 0L), l.optLong(k, 0L)))
            }
        }
        prefs(ctx).edit()
            .putString("plays", plays.toString())
            .putString("last", last.toString())
            .apply()
    }
}
