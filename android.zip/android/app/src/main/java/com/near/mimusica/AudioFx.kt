package com.near.mimusica

import android.content.Context
import android.media.audiofx.Equalizer
import org.json.JSONArray
import org.json.JSONObject

/** Ecualizador del sistema, conectado al audio del reproductor. Guarda los ajustes en el teléfono. */
object AudioFx {
    private var eq: Equalizer? = null
    private var session = 0

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("mm", Context.MODE_PRIVATE)

    @Synchronized
    fun attach(ctx: Context, sessionId: Int) {
        if (sessionId == session && eq != null) return
        release()
        if (sessionId <= 0) return
        session = sessionId
        eq = try {
            Equalizer(0, sessionId)
        } catch (e: Throwable) {
            null
        }
        apply(ctx)
    }

    @Synchronized
    fun release() {
        try {
            eq?.release()
        } catch (e: Throwable) {
        }
        eq = null
        session = 0
    }

    private fun savedLevels(ctx: Context): List<Int> {
        val out = ArrayList<Int>()
        try {
            val arr = JSONArray(prefs(ctx).getString("eqLevels", "[]") ?: "[]")
            for (i in 0 until arr.length()) out.add(arr.optInt(i, 0))
        } catch (e: Throwable) {
        }
        return out
    }

    private fun apply(ctx: Context) {
        val e = eq ?: return
        try {
            val range = e.bandLevelRange
            val levels = savedLevels(ctx)
            val n = e.numberOfBands.toInt()
            for (i in 0 until n) {
                val v = (levels.getOrNull(i) ?: 0).coerceIn(range[0].toInt(), range[1].toInt())
                e.setBandLevel(i.toShort(), v.toShort())
            }
            e.enabled = prefs(ctx).getBoolean("eqOn", false)
        } catch (t: Throwable) {
        }
    }

    /** Información para la interfaz: bandas, rango y si está activado. */
    @Synchronized
    fun info(ctx: Context): String {
        val o = JSONObject().put("on", prefs(ctx).getBoolean("eqOn", false))
        val e = eq ?: return o.put("ok", false).toString()
        try {
            val range = e.bandLevelRange
            o.put("min", range[0].toInt()).put("max", range[1].toInt())
            val bands = JSONArray()
            val n = e.numberOfBands.toInt()
            for (i in 0 until n) {
                bands.put(
                    JSONObject()
                        .put("f", e.getCenterFreq(i.toShort()) / 1000)
                        .put("lv", e.getBandLevel(i.toShort()).toInt())
                )
            }
            o.put("bands", bands).put("ok", true)
        } catch (t: Throwable) {
            o.put("ok", false)
        }
        return o.toString()
    }

    @Synchronized
    fun set(ctx: Context, on: Boolean, levelsJson: String) {
        prefs(ctx).edit()
            .putBoolean("eqOn", on)
            .putString("eqLevels", levelsJson)
            .apply()
        apply(ctx)
    }
}
