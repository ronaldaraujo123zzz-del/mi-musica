package com.near.mimusica

import android.content.Context
import android.media.audiofx.Equalizer
import org.json.JSONArray
import org.json.JSONObject

/**
 * Ecualizador del sistema, conectado al audio del reproductor. Guarda los ajustes en el teléfono.
 *
 * MARGEN (headroom): si subes una banda (ej. +6 dB a los bajos), la canción ya viene casi al
 * máximo y el teléfono la "recorta" (clipping): eso suena rasposo / reventado justo cuando
 * pega el bajo. Para evitarlo, en vez de SUBIR unas bandas se BAJAN todas las demás lo mismo:
 * suena igual de ecualizado pero nunca pasa del máximo (solo queda un poquito más bajito).
 */
object AudioFx {
    private var eq: Equalizer? = null
    private var session = 0

    /** Cuánto se bajó todo para dejar margen (milibeles, 600 = 6 dB). Para el reporte de sonido. */
    @Volatile
    var headroomMb = 0
        private set

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("mm", Context.MODE_PRIVATE)

    @Synchronized
    fun attach(ctx: Context, sessionId: Int) {
        if (sessionId == session && eq != null) return
        release()
        if (sessionId <= 0) return
        session = sessionId
        eq = try {
            Equalizer(0, sessionId)
        } catch (e: Throwable) {
            null
        }
        apply(ctx)
    }

    @Synchronized
    fun release() {
        try {
            eq?.release()
        } catch (e: Throwable) {
        }
        eq = null
        session = 0
    }

    private fun savedLevels(ctx: Context): List<Int> {
        val out = ArrayList<Int>()
        try {
            val arr = JSONArray(prefs(ctx).getString("eqLevels", "[]") ?: "[]")
            for (i in 0 until arr.length()) out.add(arr.optInt(i, 0))
        } catch (e: Throwable) {
        }
        return out
    }

    private fun apply(ctx: Context) {
        val e = eq ?: return
        try {
            val range = e.bandLevelRange
            val lo = range[0].toInt()
            val hi = range[1].toInt()
            val levels = savedLevels(ctx)
            val n = e.numberOfBands.toInt()
            val wanted = (0 until n).map { (levels.getOrNull(it) ?: 0).coerceIn(lo, hi) }
            val on = prefs(ctx).getBoolean("eqOn", false)
            // la banda más alta queda en 0 dB y las demás se bajan lo mismo
            val shift = if (on) maxOf(0, wanted.maxOrNull() ?: 0) else 0
            for (i in 0 until n) {
                e.setBandLevel(i.toShort(), (wanted[i] - shift).coerceIn(lo, hi).toShort())
            }
            headroomMb = shift
            e.enabled = on
        } catch (t: Throwable) {
        }
    }

    /** Información para la interfaz: bandas, rango y si está activado (con TUS valores, sin el margen). */
    @Synchronized
    fun info(ctx: Context): String {
        val o = JSONObject().put("on", prefs(ctx).getBoolean("eqOn", false))
        val e = eq ?: return o.put("ok", false).toString()
        try {
            val range = e.bandLevelRange
            val lo = range[0].toInt()
            val hi = range[1].toInt()
            o.put("min", lo).put("max", hi).put("head", headroomMb)
            val levels = savedLevels(ctx)
            val bands = JSONArray()
            val n = e.numberOfBands.toInt()
            for (i in 0 until n) {
                val lv = levels.getOrNull(i)?.coerceIn(lo, hi)
                    ?: (e.getBandLevel(i.toShort()).toInt() + headroomMb).coerceIn(lo, hi)
                bands.put(
                    JSONObject()
                        .put("f", e.getCenterFreq(i.toShort()) / 1000)
                        .put("lv", lv)
                )
            }
            o.put("bands", bands).put("ok", true)
        } catch (t: Throwable) {
            o.put("ok", false)
        }
        return o.toString()
    }

    /** Texto corto para el reporte de sonido. */
    @Synchronized
    fun describe(ctx: Context): String {
        val on = prefs(ctx).getBoolean("eqOn", false)
        if (eq == null) return "no disponible en este teléfono"
        if (!on) return "apagado"
        val lv = savedLevels(ctx).joinToString(" ") { (if (it > 0) "+" else "") + (it / 100.0).toString() }
        return "encendido [$lv dB] · margen -${headroomMb / 100.0} dB"
    }

    @Synchronized
    fun set(ctx: Context, on: Boolean, levelsJson: String) {
        prefs(ctx).edit()
            .putBoolean("eqOn", on)
            .putString("eqLevels", levelsJson)
            .apply()
        apply(ctx)
    }
}
