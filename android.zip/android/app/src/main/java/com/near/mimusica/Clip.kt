package com.near.mimusica

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.io.OutputStream
import java.nio.ByteBuffer

/** Guarda un tramo (A-B) de una canción como un archivo de audio nuevo, sin perder calidad. */
object Clip {
    /** "mp3", "wav", "m4a" o "" si ese formato no se puede recortar. */
    fun kind(ctx: Context, id: Long): String {
        val s = Library.songs[id] ?: return ""
        val ext = s.path.substringAfterLast('.', "").lowercase()
        when (ext) {
            "mp3" -> return "mp3"
            "wav" -> return "wav"
            "m4a", "mp4", "aac", "3gp", "m4b" -> return "m4a"
        }
        // sin extensión conocida: mirar el comienzo del archivo
        val head = try {
            ctx.contentResolver.openInputStream(Library.uri(id))?.use { inp ->
                val b = ByteArray(16)
                val n = inp.read(b)
                if (n > 0) b.copyOf(n) else ByteArray(0)
            } ?: ByteArray(0)
        } catch (e: Exception) {
            ByteArray(0)
        }
        if (head.size >= 12) {
            val s4 = String(head, 4, 4, Charsets.ISO_8859_1)
            if (AudioSlice.isWav(head)) return "wav"
            if (s4 == "ftyp") return "m4a"
            if (String(head, 0, 3, Charsets.ISO_8859_1) == "ID3") return "mp3"
            if ((head[0].toInt() and 0xFF) == 0xFF && (head[1].toInt() and 0xE6) == 0xE2) return "mp3"
        }
        return ""
    }

    /** Escribe el tramo en out. Devuelve los milisegundos guardados. */
    fun write(ctx: Context, id: Long, aMs: Long, bMs: Long, out: OutputStream): Long {
        when (kind(ctx, id)) {
            "mp3", "wav" -> {
                val s = Library.songs[id]
                val size = s?.let { File(it.path).length() } ?: 0L
                if (size > 300L * 1024 * 1024) throw IllegalStateException("El archivo es demasiado grande")
                val d = ctx.contentResolver.openInputStream(Library.uri(id))?.use { it.readBytes() }
                    ?: throw IllegalStateException("No se pudo abrir la canción")
                return if (AudioSlice.isWav(d)) AudioSlice.wav(d, aMs, bMs, out) else AudioSlice.mp3(d, aMs, bMs, out)
            }
            "m4a" -> {
                val tmp = File(ctx.cacheDir, "tramo.m4a")
                try {
                    val ms = m4a(ctx, id, aMs, bMs, tmp)
                    tmp.inputStream().use { it.copyTo(out) }
                    return ms
                } finally {
                    tmp.delete()
                }
            }
            else -> throw IllegalStateException("Este formato no se puede recortar (solo MP3, M4A y WAV)")
        }
    }

    private fun m4a(ctx: Context, id: Long, aMs: Long, bMs: Long, tmp: File): Long {
        val ex = MediaExtractor()
        var mux: MediaMuxer? = null
        try {
            ex.setDataSource(ctx, Library.uri(id), null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/mp4a")) {
                    track = i
                    fmt = f
                    break
                }
            }
            if (track < 0 || fmt == null) throw IllegalStateException("Este archivo no tiene audio AAC")
            ex.selectTrack(track)
            val m = MediaMuxer(tmp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux = m
            val outTrack = m.addTrack(fmt)
            m.start()
            val cap = if (fmt.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) fmt.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE) else 0
            val buf = ByteBuffer.allocate(maxOf(cap, 256 * 1024))
            val info = MediaCodec.BufferInfo()
            ex.seekTo(aMs * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            var first = -1L
            var last = 0L
            while (true) {
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val t = ex.sampleTime
                if (t >= bMs * 1000) break
                if (t >= aMs * 1000 - 25_000) {
                    if (first < 0) first = t
                    info.offset = 0
                    info.size = size
                    info.presentationTimeUs = t - first
                    info.flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    m.writeSampleData(outTrack, buf, info)
                    last = t - first
                }
                if (!ex.advance()) break
            }
            if (first < 0) throw IllegalStateException("No se encontró audio en ese tramo")
            m.stop()
            return last / 1000
        } finally {
            try { mux?.release() } catch (e: Exception) {}
            ex.release()
        }
    }
}
