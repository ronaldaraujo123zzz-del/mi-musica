package com.near.mimusica

import android.content.Context
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.Charset

/**
 * Letras de las canciones:
 *  - las que vienen dentro del archivo (MP3, FLAC, OGG/Opus, M4A) o en un .lrc al lado,
 *  - las que se descargan de LRCLIB (lrclib.net, gratis),
 *  - y una copia guardada en el teléfono para no volver a descargarlas.
 */
object Lyrics {
    private const val MAX_TAG = 24 * 1024 * 1024
    private const val SCAN = 6 * 1024 * 1024
    private const val UA = "NEAR Music (https://github.com/ronaldaraujo123zzz-del/mi-musica)"

    // ---------------- copia guardada ----------------
    private fun file(ctx: Context, id: String): File {
        val dir = File(ctx.filesDir, "lyrics")
        dir.mkdirs()
        val name = id.filter { it.isLetterOrDigit() }.take(40).ifEmpty { "x" }
        return File(dir, "$name.lrc")
    }

    fun cacheGet(ctx: Context, id: String): String = try {
        val f = file(ctx, id)
        if (f.isFile) f.readText(Charsets.UTF_8) else ""
    } catch (e: Exception) {
        ""
    }

    fun cachePut(ctx: Context, id: String, text: String) {
        try {
            file(ctx, id).writeText(text, Charsets.UTF_8)
        } catch (e: Exception) {
            // sin espacio o sin permiso: no pasa nada
        }
    }

    fun cacheDel(ctx: Context, id: String) {
        try {
            file(ctx, id).delete()
        } catch (e: Exception) {
        }
    }

    /** Todas las letras guardadas: {"id": "texto"} (para buscar canciones por una frase). */
    fun cacheAll(ctx: Context): String {
        val o = org.json.JSONObject()
        try {
            File(ctx.filesDir, "lyrics").listFiles()?.forEach { f ->
                if (f.name.endsWith(".lrc") && f.length() < 300_000) {
                    try {
                        o.put(f.name.removeSuffix(".lrc"), f.readText(Charsets.UTF_8))
                    } catch (e: Exception) {
                    }
                }
            }
        } catch (e: Exception) {
        }
        return o.toString()
    }

    // ---------------- letra lista para el reproductor (notificación y widget) ----------------
    // La interfaz guarda aquí las líneas ya ajustadas: [[ms, "texto"], ...]
    private fun nowFile(ctx: Context, id: String): File {
        val dir = File(ctx.filesDir, "lyrics")
        dir.mkdirs()
        return File(dir, id.filter { it.isLetterOrDigit() }.take(40).ifEmpty { "x" } + ".now")
    }

    fun nowPut(ctx: Context, id: String, json: String) {
        try {
            nowFile(ctx, id).writeText(json, Charsets.UTF_8)
        } catch (e: Exception) {
        }
    }

    /** Líneas (ms, texto) para una canción: primero las que mandó la interfaz, si no, la letra guardada. */
    fun nowLines(ctx: Context, id: String): List<Pair<Long, String>> {
        try {
            val f = nowFile(ctx, id)
            if (f.isFile) {
                val arr = org.json.JSONArray(f.readText(Charsets.UTF_8))
                val out = ArrayList<Pair<Long, String>>(arr.length())
                for (i in 0 until arr.length()) {
                    val x = arr.optJSONArray(i) ?: continue
                    out.add(x.optLong(0) to x.optString(1))
                }
                return out
            }
        } catch (e: Exception) {
        }
        return parseLrc(cacheGet(ctx, id))
    }

    private val TAG = Regex("\\[(\\d{1,3}):(\\d{1,2}(?:[.:]\\d{1,3})?)]")

    fun parseLrc(txt: String): List<Pair<Long, String>> {
        if (txt.isBlank()) return emptyList()
        val out = ArrayList<Pair<Long, String>>()
        for (line in txt.split('\n')) {
            val tags = TAG.findAll(line).toList()
            if (tags.isEmpty()) continue
            val text = line.replace(Regex("\\[[^\\]]*]"), "").replace(Regex("<\\d+:\\d+(?:[.:]\\d+)?>"), "").trim()
            for (m in tags) {
                val min = m.groupValues[1].toLongOrNull() ?: continue
                val sec = m.groupValues[2].replace(':', '.').toDoubleOrNull() ?: continue
                out.add((min * 60_000 + (sec * 1000).toLong()) to text)
            }
        }
        out.sortBy { it.first }
        return if (out.size >= 3) out else emptyList()
    }

    // ---------------- internet (LRCLIB) ----------------
    /** path es lo que va después de https://lrclib.net/api/ (solo "search?..." o "get?..."). */
    fun http(path: String): Pair<Int, String> {
        if (!(path.startsWith("search?") || path.startsWith("get?")) || path.contains("://") || path.contains('#')) {
            return 0 to ""
        }
        val c = URL("https://lrclib.net/api/$path").openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept", "application/json")
        return try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            code to body
        } finally {
            c.disconnect()
        }
    }

    // ---------------- dentro del archivo ----------------
    /** Busca un .lrc con el mismo nombre que la canción, o la letra guardada dentro del archivo. */
    fun local(ctx: Context, id: Long): String? {
        val s = Library.songs[id] ?: return null
        sibling(s.path)?.let { return it }
        return ctx.contentResolver.openInputStream(Library.uri(id))?.use { embedded(it) }
    }

    private fun sibling(path: String): String? {
        if (path.isEmpty() || !path.contains('.')) return null
        val base = path.substringBeforeLast('.')
        for (ext in arrayOf(".lrc", ".LRC", ".Lrc")) {
            try {
                val f = File(base + ext)
                if (f.isFile && f.length() in 1..512_000) {
                    val t = f.readText(Charsets.UTF_8).trim()
                    if (t.isNotEmpty()) return t
                }
            } catch (e: Exception) {
                // Android no deja leer ese archivo: seguimos
            }
        }
        return null
    }

    fun embedded(inp: InputStream): String? {
        val head = readUpTo(inp, 10)
        if (head.size < 10) return null
        if (head[0] == 'I'.code.toByte() && head[1] == 'D'.code.toByte() && head[2] == '3'.code.toByte()) {
            val ver = head[3].toInt() and 0xFF
            val flags = head[5].toInt() and 0xFF
            val size = syncsafe(head, 6)
            val body = readUpTo(inp, minOf(size, MAX_TAG))
            id3(ver, flags, body)?.let { return it }
            // algunos MP3 traen además etiquetas de otro tipo: mirar un poco más
            return pickBest(vorbis(readUpTo(inp, 512 * 1024)))
        }
        val all = head + readUpTo(inp, SCAN)
        val found = ArrayList<String>()
        found.addAll(vorbis(all))
        mp4(all)?.let { found.add(it) }
        return pickBest(found)
    }

    private fun pickBest(list: List<String>): String? {
        val clean = list.map { it.trim() }.filter { it.isNotEmpty() }
        return clean.firstOrNull { hasTimes(it) } ?: clean.firstOrNull()
    }

    private val TIME = Regex("\\[\\d{1,2}:\\d{1,2}([.:]\\d{1,3})?]")
    private fun hasTimes(t: String) = TIME.findAll(t).take(3).count() >= 3

    // ----- ID3 (MP3) -----
    private fun id3(ver: Int, flags: Int, raw: ByteArray): String? {
        if (ver !in 2..4) return null
        var b = raw
        if (ver < 4 && (flags and 0x80) != 0) b = unsync(b)
        var p = 0
        if ((flags and 0x40) != 0 && ver >= 3 && b.size >= 4) {
            p = if (ver == 4) syncsafe(b, 0) else be32(b, 0) + 4
        }
        val found = ArrayList<String>()
        while (p >= 0) {
            val id: String
            var data: ByteArray
            if (ver == 2) {
                if (p + 6 > b.size) break
                id = String(b, p, 3, Charsets.ISO_8859_1)
                val sz = be24(b, p + 3)
                if (b[p].toInt() == 0 || sz <= 0) break
                val start = p + 6
                val end = start + sz
                if (end > b.size || end < start) break
                data = b.copyOfRange(start, end)
                p = end
            } else {
                if (p + 10 > b.size) break
                id = String(b, p, 4, Charsets.ISO_8859_1)
                val sz = if (ver == 4) syncsafe(b, p + 4) else be32(b, p + 4)
                val fl = b[p + 9].toInt() and 0xFF
                if (b[p].toInt() == 0 || sz <= 0) break
                val start = p + 10
                val end = start + sz
                if (end > b.size || end < start) break
                data = b.copyOfRange(start, end)
                p = end
                if (ver == 4) {
                    if ((fl and 0x0C) != 0) continue // comprimido o cifrado
                    var skip = 0
                    if ((fl and 0x40) != 0) skip += 1
                    if ((fl and 0x01) != 0) skip += 4
                    if (skip > 0) data = if (skip < data.size) data.copyOfRange(skip, data.size) else ByteArray(0)
                    if ((fl and 0x02) != 0) data = unsync(data)
                } else {
                    if ((fl and 0xC0) != 0) continue // comprimido o cifrado
                    if ((fl and 0x20) != 0) data = if (data.size > 1) data.copyOfRange(1, data.size) else ByteArray(0)
                }
            }
            try {
                when (id) {
                    "SYLT", "SLT" -> sylt(data)?.let { found.add(0, it) }
                    "USLT", "ULT" -> uslt(data)?.let { found.add(it) }
                }
            } catch (e: Exception) {
                // marco dañado: lo saltamos
            }
        }
        return pickBest(found)
    }

    private fun charset(enc: Int): Charset = when (enc) {
        1 -> Charsets.UTF_16
        2 -> Charsets.UTF_16BE
        3 -> Charsets.UTF_8
        else -> Charsets.ISO_8859_1
    }

    /** Devuelve la posición justo después del final del texto que empieza en p. */
    private fun endOfText(d: ByteArray, p: Int, enc: Int): Pair<Int, Int> {
        if (enc == 1 || enc == 2) {
            var i = p
            while (i + 1 < d.size) {
                if (d[i].toInt() == 0 && d[i + 1].toInt() == 0) return i to i + 2
                i += 2
            }
            return d.size to d.size
        }
        var i = p
        while (i < d.size) {
            if (d[i].toInt() == 0) return i to i + 1
            i++
        }
        return d.size to d.size
    }

    private fun text(d: ByteArray, from: Int, to: Int, enc: Int): String {
        if (to <= from) return ""
        return String(d, from, to - from, charset(enc)).replace("\u0000", "")
    }

    private fun uslt(d: ByteArray): String? {
        if (d.size < 5) return null
        val enc = d[0].toInt()
        val (_, after) = endOfText(d, 4, enc) // descripción
        val t = text(d, after, d.size, enc).replace("\r\n", "\n").replace('\r', '\n').trim()
        return t.ifEmpty { null }
    }

    /** Letra sincronizada dentro del MP3: la convertimos a formato LRC. */
    private fun sylt(d: ByteArray): String? {
        if (d.size < 7) return null
        val enc = d[0].toInt()
        val format = d[4].toInt()
        if (format != 2) return null // solo sabemos usar milisegundos
        var p = endOfText(d, 6, enc).second
        val parts = ArrayList<Pair<Long, String>>()
        while (p < d.size) {
            val (end, next) = endOfText(d, p, enc)
            if (next + 4 > d.size) break
            val t = text(d, p, end, enc)
            val ms = be32(d, next).toLong() and 0xFFFFFFFFL
            parts.add(ms to t)
            p = next + 4
        }
        if (parts.size < 2) return null
        // algunas traen palabra por palabra: un salto de línea al inicio marca una línea nueva
        val byWord = parts.count { it.second.startsWith("\n") || it.second.startsWith("\r") } >= 2
        val lines = ArrayList<Pair<Long, String>>()
        if (byWord) {
            var cur: StringBuilder? = null
            var at = 0L
            for ((ms, t) in parts) {
                if (cur == null || t.startsWith("\n") || t.startsWith("\r")) {
                    cur?.let { lines.add(at to it.toString().trim()) }
                    cur = StringBuilder()
                    at = ms
                }
                cur.append(t.replace("\r", "").replace("\n", ""))
            }
            cur?.let { lines.add(at to it.toString().trim()) }
        } else {
            for ((ms, t) in parts) lines.add(ms to t.replace("\r", " ").replace("\n", " ").trim())
        }
        val sb = StringBuilder()
        for ((ms, t) in lines) {
            val min = ms / 60000
            val sec = (ms % 60000) / 1000
            val cs = (ms % 1000) / 10
            sb.append(String.format(java.util.Locale.US, "[%02d:%02d.%02d]%s\n", min, sec, cs, t))
        }
        return sb.toString().trim().ifEmpty { null }
    }

    // ----- FLAC / OGG / Opus: comentarios "LYRICS=..." -----
    private fun vorbis(b: ByteArray): List<String> {
        val out = ArrayList<String>()
        val key = "LYRICS=".toByteArray(Charsets.US_ASCII)
        var from = 0
        while (true) {
            val i = indexOfIgnoreCase(b, key, from)
            if (i < 0) break
            from = i + key.size
            // la clave real puede ser LYRICS, UNSYNCEDLYRICS o SYNCEDLYRICS
            for (back in intArrayOf(0, 6, 8)) {
                val start = i - back
                if (start < 4) continue
                val len = le32(b, start - 4)
                val keyLen = back + key.size
                if (len <= keyLen || start + len > b.size) continue
                val t = String(b, start + keyLen, len - keyLen, Charsets.UTF_8).trim()
                if (t.isNotEmpty()) out.add(t)
                break
            }
        }
        return out
    }

    // ----- M4A / AAC: átomo ©lyr -----
    private fun mp4(b: ByteArray): String? {
        val key = byteArrayOf(0xA9.toByte(), 'l'.code.toByte(), 'y'.code.toByte(), 'r'.code.toByte())
        var from = 0
        while (true) {
            val i = indexOf(b, key, from)
            if (i < 0) return null
            from = i + 4
            if (i + 20 > b.size) return null
            if (String(b, i + 8, 4, Charsets.ISO_8859_1) != "data") continue
            val dataSize = be32(b, i + 4)
            val len = dataSize - 16
            if (len <= 0 || i + 20 + len > b.size) continue
            val t = String(b, i + 20, len, Charsets.UTF_8).trim()
            if (t.isNotEmpty()) return t
        }
    }

    // ---------------- utilidades ----------------
    private fun readUpTo(inp: InputStream, max: Int): ByteArray {
        if (max <= 0) return ByteArray(0)
        val buf = ByteArray(max)
        var n = 0
        while (n < max) {
            val r = inp.read(buf, n, max - n)
            if (r <= 0) break
            n += r
        }
        return if (n == max) buf else buf.copyOf(n)
    }

    private fun unsync(b: ByteArray): ByteArray {
        val out = java.io.ByteArrayOutputStream(b.size)
        var i = 0
        while (i < b.size) {
            out.write(b[i].toInt())
            if ((b[i].toInt() and 0xFF) == 0xFF && i + 1 < b.size && b[i + 1].toInt() == 0) i++
            i++
        }
        return out.toByteArray()
    }

    private fun syncsafe(b: ByteArray, p: Int): Int =
        ((b[p].toInt() and 0x7F) shl 21) or ((b[p + 1].toInt() and 0x7F) shl 14) or
            ((b[p + 2].toInt() and 0x7F) shl 7) or (b[p + 3].toInt() and 0x7F)

    private fun be32(b: ByteArray, p: Int): Int =
        ((b[p].toInt() and 0xFF) shl 24) or ((b[p + 1].toInt() and 0xFF) shl 16) or
            ((b[p + 2].toInt() and 0xFF) shl 8) or (b[p + 3].toInt() and 0xFF)

    private fun be24(b: ByteArray, p: Int): Int =
        ((b[p].toInt() and 0xFF) shl 16) or ((b[p + 1].toInt() and 0xFF) shl 8) or (b[p + 2].toInt() and 0xFF)

    private fun le32(b: ByteArray, p: Int): Int =
        (b[p].toInt() and 0xFF) or ((b[p + 1].toInt() and 0xFF) shl 8) or
            ((b[p + 2].toInt() and 0xFF) shl 16) or ((b[p + 3].toInt() and 0xFF) shl 24)

    private fun indexOf(b: ByteArray, k: ByteArray, from: Int): Int {
        var i = maxOf(0, from)
        val last = b.size - k.size
        while (i <= last) {
            var ok = true
            for (j in k.indices) if (b[i + j] != k[j]) { ok = false; break }
            if (ok) return i
            i++
        }
        return -1
    }

    private fun indexOfIgnoreCase(b: ByteArray, k: ByteArray, from: Int): Int {
        var i = maxOf(0, from)
        val last = b.size - k.size
        while (i <= last) {
            var ok = true
            for (j in k.indices) {
                var c = b[i + j].toInt() and 0xFF
                if (c in 0x61..0x7A) c -= 0x20
                if (c != (k[j].toInt() and 0xFF)) { ok = false; break }
            }
            if (ok) return i
            i++
        }
        return -1
    }
}
