package com.near.mimusica

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.webkit.WebViewAssetLoader
import com.google.common.util.concurrent.ListenableFuture
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val main = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            pushState()
            if (controller?.isPlaying == true) main.postDelayed(this, 500)
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            pushState()
            main.removeCallbacks(ticker)
            if (player.isPlaying) main.postDelayed(ticker, 500)
        }
    }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { js("window.onPermission && window.onPermission(${hasAudioPerm()})") }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF0D0D11.toInt())
        web = WebView(this)
        web.setBackgroundColor(0xFF0D0D11.toInt())
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
        WindowInsetsControllerCompat(window, root).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/art/", ArtHandler(this))
            .build()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = false
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        web.addJavascriptInterface(Bridge(), "Native")
        web.loadUrl("https://appassets.androidplatform.net/assets/app.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.onBack && window.onBack()) ? '1' : '0'") { r ->
                    if (r == null || !r.contains("1")) moveTaskToBack(true)
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        connect()
    }

    override fun onStop() {
        super.onStop()
        main.removeCallbacks(ticker)
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
    }

    private fun connect() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        controllerFuture = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(playerListener)
                pushState()
                if (c.isPlaying) main.postDelayed(ticker, 500)
            } catch (e: Exception) {
                // el reproductor no está disponible todavía
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun withController(block: (MediaController) -> Unit) {
        main.post {
            val c = controller
            if (c != null) {
                block(c)
            } else {
                controllerFuture?.addListener({ controller?.let(block) }, ContextCompat.getMainExecutor(this))
            }
        }
    }

    private fun pushState() {
        val c = controller ?: return
        val o = JSONObject()
            .put("id", c.currentMediaItem?.mediaId ?: "")
            .put("playing", c.isPlaying)
            .put("pos", c.currentPosition)
            .put("dur", if (c.duration == C.TIME_UNSET) 0L else c.duration)
            .put("shuffle", c.shuffleModeEnabled)
            .put("repeat", c.repeatMode)
            .put("count", c.mediaItemCount)
        js("window.onState && window.onState($o)")
    }

    private fun js(code: String) {
        main.post { if (::web.isInitialized) web.evaluateJavascript(code, null) }
    }

    private fun audioPerm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPerm(): Boolean =
        ContextCompat.checkSelfPermission(this, audioPerm()) == PackageManager.PERMISSION_GRANTED

    private fun itemsFor(idsJson: String): List<MediaItem> {
        val arr = JSONArray(idsJson)
        val out = ArrayList<MediaItem>(arr.length())
        for (i in 0 until arr.length()) {
            val id = arr.optString(i).toLongOrNull() ?: continue
            val s = Library.songs[id] ?: continue
            out.add(Library.mediaItem(s))
        }
        return out
    }

    /** Funciones que la interfaz (app.html) puede llamar como Native.xxx() */
    inner class Bridge {
        @JavascriptInterface
        fun hasPermission(): Boolean = hasAudioPerm()

        @JavascriptInterface
        fun requestPermission() {
            main.post {
                val perms = ArrayList<String>()
                perms.add(audioPerm())
                if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
                permLauncher.launch(perms.toTypedArray())
            }
        }

        @JavascriptInterface
        fun openSettings() {
            main.post {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }

        @JavascriptInterface
        fun scan() {
            Thread {
                val list = try {
                    Library.scan(this@MainActivity)
                } catch (e: Exception) {
                    emptyList()
                }
                js("window.onLibrary && window.onLibrary(${Library.toJson(list)})")
            }.start()
        }

        @JavascriptInterface
        fun play(idsJson: String, startId: String, shuffle: Boolean) {
            val items = try { itemsFor(idsJson) } catch (e: Exception) { emptyList() }
            if (items.isEmpty()) return
            var start = items.indexOfFirst { it.mediaId == startId }
            if (start < 0) start = if (shuffle) Random.nextInt(items.size) else 0
            withController { c ->
                c.shuffleModeEnabled = shuffle
                c.setMediaItems(items, start, 0L)
                c.prepare()
                c.play()
            }
        }

        @JavascriptInterface
        fun toggle() {
            withController { c ->
                if (c.isPlaying) {
                    c.pause()
                } else {
                    if (c.playbackState == Player.STATE_IDLE) c.prepare()
                    if (c.playbackState == Player.STATE_ENDED) c.seekToDefaultPosition()
                    c.play()
                }
            }
        }

        @JavascriptInterface
        fun next() { withController { it.seekToNext() } }

        @JavascriptInterface
        fun prev() { withController { it.seekToPrevious() } }

        @JavascriptInterface
        fun seek(ms: Double) { withController { it.seekTo(ms.toLong()) } }

        @JavascriptInterface
        fun setShuffle(on: Boolean) { withController { it.shuffleModeEnabled = on } }

        @JavascriptInterface
        fun setRepeat(mode: Int) { withController { it.repeatMode = mode } }

        @JavascriptInterface
        fun playNext(id: String) {
            val s = id.toLongOrNull()?.let { Library.songs[it] } ?: return
            val item = Library.mediaItem(s)
            withController { c ->
                if (c.mediaItemCount == 0) {
                    c.setMediaItem(item)
                    c.prepare()
                    c.play()
                } else {
                    c.addMediaItem(c.currentMediaItemIndex + 1, item)
                }
            }
        }

        @JavascriptInterface
        fun state() { main.post { pushState() } }
    }
}
