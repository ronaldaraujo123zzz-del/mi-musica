package com.near.mimusica

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import android.util.Base64
import java.io.File
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import androidx.webkit.WebViewAssetLoader
import com.google.common.util.concurrent.ListenableFuture
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val main = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            pushState()
            if (controller?.isPlaying == true) main.postDelayed(this, 500)
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            pushState()
            main.removeCallbacks(ticker)
            if (player.isPlaying) main.postDelayed(ticker, 500)
        }
    }

    // ---------- copia de seguridad (guardar / abrir un archivo) ----------
    private var pendingBackup: String? = null

    private val saveDoc = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val data = pendingBackup
        pendingBackup = null
        if (uri == null || data == null) {
            js("window.onBackupSaved && window.onBackupSaved(false)")
        } else {
            Thread {
                val ok = try {
                    val os = contentResolver.openOutputStream(uri, "wt") ?: throw Exception("sin archivo")
                    os.use { it.write(data.toByteArray(Charsets.UTF_8)) }
                    true
                } catch (e: Exception) {
                    false
                }
                js("window.onBackupSaved && window.onBackupSaved($ok)")
            }.start()
        }
    }

    private val openDoc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) {
            js("window.onBackupLoaded && window.onBackupLoaded(null)")
        } else {
            Thread {
                val text = try {
                    contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                } catch (e: Exception) {
                    null
                }
                val arg = if (text == null) "null" else JSONObject.quote(text)
                js("window.onBackupLoaded && window.onBackupLoaded($arg)")
            }.start()
        }
    }

    private val openLrc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) {
            js("window.onLrcLoaded && window.onLrcLoaded(null)")
        } else {
            Thread {
                val text = try {
                    contentResolver.openInputStream(uri)?.use { inp ->
                        val b = inp.readBytes()
                        if (b.size > 1_000_000) null else b.toString(Charsets.UTF_8).removePrefix("\uFEFF")
                    }
                } catch (e: Exception) {
                    null
                }
                val arg = if (text == null) "null" else JSONObject.quote(text)
                js("window.onLrcLoaded && window.onLrcLoaded($arg)")
            }.start()
        }
    }

    // ---------- guardar un archivo donde tú elijas (subtítulos, letra, tramo de audio, imagen) ----------
    private sealed class SaveJob {
        class Text(val text: String) : SaveJob()
        class Bytes(val data: ByteArray) : SaveJob()
        class Audio(val id: Long, val a: Long, val b: Long) : SaveJob()
    }

    private var pendingSave: SaveJob? = null
    private var pendingMime = "*/*"

    private val saveAny = registerForActivityResult(object : ActivityResultContracts.CreateDocument("*/*") {
        override fun createIntent(context: Context, input: String): Intent =
            super.createIntent(context, input).setType(pendingMime)
    }) { uri ->
        val job = pendingSave
        pendingSave = null
        if (uri == null || job == null) {
            js("window.onSaved && window.onSaved(false, null)")
        } else {
            Thread {
                var err: String? = null
                try {
                    val os = contentResolver.openOutputStream(uri, "wt") ?: throw Exception("sin archivo")
                    os.use { out ->
                        when (job) {
                            is SaveJob.Text -> out.write(job.text.toByteArray(Charsets.UTF_8))
                            is SaveJob.Bytes -> out.write(job.data)
                            is SaveJob.Audio -> Clip.write(this@MainActivity, job.id, job.a, job.b, out)
                        }
                    }
                } catch (e: Throwable) {
                    err = e.message ?: "error"
                    try {
                        android.provider.DocumentsContract.deleteDocument(contentResolver, uri)
                    } catch (x: Throwable) {
                    }
                }
                val arg = if (err == null) "null" else JSONObject.quote(err)
                js("window.onSaved && window.onSaved(${err == null}, $arg)")
            }.start()
        }
    }

    private fun startSave(job: SaveJob, name: String, mime: String) {
        main.post {
            pendingSave = job
            pendingMime = mime
            try {
                saveAny.launch(name)
            } catch (e: Exception) {
                pendingSave = null
                js("window.onSaved && window.onSaved(false, null)")
            }
        }
    }

    // ---------- fondo de pantalla ----------
    private val pickImg = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri == null) {
            js("window.onBgPicked && window.onBgPicked(false)")
        } else {
            Thread {
                val ok = Bg.save(this@MainActivity, uri)
                js("window.onBgPicked && window.onBgPicked($ok)")
            }.start()
        }
    }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { js("window.onPermission && window.onPermission(${hasAudioPerm()})") }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF140E36.toInt())
        web = WebView(this)
        web.setBackgroundColor(0xFF140E36.toInt())
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
        WindowInsetsControllerCompat(window, root).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/art/", ArtHandler(this))
            .addPathHandler("/bg/", Bg.Handler(this))
            .build()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = false
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        web.addJavascriptInterface(Bridge(), "Native")
        web.loadUrl("https://appassets.androidplatform.net/assets/app.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.onBack && window.onBack()) ? '1' : '0'") { r ->
                    if (r == null || !r.contains("1")) moveTaskToBack(true)
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        started = true
        connect()
    }

    override fun onStop() {
        super.onStop()
        started = false
        main.removeCallbacks(ticker)
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
    }

    private var started = false

    private fun connect() {
        if (controllerFuture != null) return // ya se está conectando
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token)
            .setListener(object : MediaController.Listener {
                // Android cerró el reproductor (por ejemplo, mucho rato en pausa): volver a conectar
                override fun onDisconnected(controller: MediaController) {
                    main.post { dropController(controller) }
                }
            })
            .buildAsync()
        controllerFuture = f
        f.addListener({
            try {
                val c = f.get()
                if (controllerFuture !== f) {
                    c.release()
                    return@addListener
                }
                controller = c
                c.addListener(playerListener)
                pushState()
                if (c.isPlaying) main.postDelayed(ticker, 500)
            } catch (e: Exception) {
                // el reproductor no está disponible todavía
                if (controllerFuture === f) controllerFuture = null
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /** Suelta una conexión que ya no sirve y, si la app está abierta, crea otra. */
    private fun dropController(old: MediaController?) {
        if (old != null && controller !== old) return
        main.removeCallbacks(ticker)
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
        if (started) connect()
    }

    private fun withController(block: (MediaController) -> Unit) {
        main.post {
            val c = controller
            if (c != null && c.isConnected) {
                block(c)
            } else {
                // sin conexión: reconectar y hacer lo que tocaste en cuanto conecte
                if (c != null) dropController(c) else connect()
                controllerFuture?.addListener({
                    controller?.let { if (it.isConnected) block(it) }
                }, ContextCompat.getMainExecutor(this))
            }
        }
    }

    private fun pushState() {
        val c = controller ?: return
        val o = JSONObject()
            .put("id", c.currentMediaItem?.mediaId ?: "")
            .put("playing", c.isPlaying)
            .put("pos", c.currentPosition)
            .put("dur", if (c.duration == C.TIME_UNSET) 0L else c.duration)
            .put("shuffle", c.shuffleModeEnabled)
            .put("repeat", c.repeatMode)
            .put("count", c.mediaItemCount)
            .put("speed", c.playbackParameters.speed.toDouble())
            .put("pitch", c.playbackParameters.pitch.toDouble())
            .put("sleepAt", PlaybackService.sleepAt)
            .put("sleepEnd", PlaybackService.sleepEnd)
            .put("abA", PlaybackService.abA)
            .put("abB", PlaybackService.abB)
        js("window.onState && window.onState($o)")
    }

    /** Envía a la interfaz las canciones que siguen, en el orden en que sonarán. */
    private fun sendQueue() {
        val c = controller
        if (c == null) {
            js("window.onQueue && window.onQueue(null)")
            return
        }
        val tl = c.currentTimeline
        val arr = JSONArray()
        if (!tl.isEmpty() && c.mediaItemCount > 0) {
            var i = c.currentMediaItemIndex
            var n = 0
            while (i != C.INDEX_UNSET && n < 300) {
                arr.put(JSONObject().put("i", i).put("id", c.getMediaItemAt(i).mediaId))
                i = tl.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, c.shuffleModeEnabled)
                n++
            }
        }
        val o = JSONObject().put("items", arr).put("shuffle", c.shuffleModeEnabled)
        js("window.onQueue && window.onQueue($o)")
    }

    private fun js(code: String) {
        main.post { if (::web.isInitialized) web.evaluateJavascript(code, null) }
    }

    private fun audioPerm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPerm(): Boolean =
        ContextCompat.checkSelfPermission(this, audioPerm()) == PackageManager.PERMISSION_GRANTED

    private fun itemsFor(idsJson: String): List<MediaItem> {
        val arr = JSONArray(idsJson)
        val out = ArrayList<MediaItem>(arr.length())
        for (i in 0 until arr.length()) {
            val id = arr.optString(i).toLongOrNull() ?: continue
            val s = Library.songs[id] ?: continue
            out.add(Library.mediaItem(s))
        }
        return out
    }

    /** Funciones que la interfaz (app.html) puede llamar como Native.xxx() */
    inner class Bridge {
        @JavascriptInterface
        fun hasPermission(): Boolean = hasAudioPerm()

        @JavascriptInterface
        fun requestPermission() {
            main.post {
                val perms = ArrayList<String>()
                perms.add(audioPerm())
                if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
                permLauncher.launch(perms.toTypedArray())
            }
        }

        @JavascriptInterface
        fun openSettings() {
            main.post {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }

        @JavascriptInterface
        fun scan() {
            Thread {
                val list = try {
                    Library.scan(this@MainActivity)
                } catch (e: Exception) {
                    emptyList()
                }
                js("window.onLibrary && window.onLibrary(${Library.toJson(list)})")
            }.start()
        }

        @JavascriptInterface
        fun play(idsJson: String, startId: String, shuffle: Boolean) {
            val items = try { itemsFor(idsJson) } catch (e: Exception) { emptyList() }
            if (items.isEmpty()) return
            var start = items.indexOfFirst { it.mediaId == startId }
            if (start < 0) start = if (shuffle) Random.nextInt(items.size) else 0
            withController { c ->
                c.shuffleModeEnabled = shuffle
                c.setMediaItems(items, start, 0L)
                c.prepare()
                c.play()
            }
        }

        @JavascriptInterface
        fun toggle() {
            withController { c ->
                if (c.isPlaying) {
                    c.pause()
                } else {
                    if (c.playbackState == Player.STATE_IDLE) c.prepare()
                    if (c.playbackState == Player.STATE_ENDED) c.seekToDefaultPosition()
                    c.play()
                }
            }
        }

        @JavascriptInterface
        fun next() { withController { it.seekToNext() } }

        @JavascriptInterface
        fun prev() { withController { it.seekToPrevious() } }

        @JavascriptInterface
        fun seek(ms: Double) { withController { it.seekTo(ms.toLong()) } }

        @JavascriptInterface
        fun setShuffle(on: Boolean) { withController { it.shuffleModeEnabled = on } }

        @JavascriptInterface
        fun setRepeat(mode: Int) { withController { it.repeatMode = mode } }

        @JavascriptInterface
        fun playNext(id: String) {
            val s = id.toLongOrNull()?.let { Library.songs[it] } ?: return
            val item = Library.mediaItem(s)
            withController { c ->
                if (c.mediaItemCount == 0) {
                    c.setMediaItem(item)
                    c.prepare()
                    c.play()
                } else {
                    c.addMediaItem(c.currentMediaItemIndex + 1, item)
                }
            }
        }

        @JavascriptInterface
        fun removeFromQueue(id: String) {
            withController { c ->
                for (i in c.mediaItemCount - 1 downTo 0) {
                    if (c.getMediaItemAt(i).mediaId == id) c.removeMediaItem(i)
                }
            }
        }

        @JavascriptInterface
        fun state() { main.post { pushState() } }

        /** Velocidad (1 = normal) y tono (1 = normal; 2 = una octava más agudo). */
        @JavascriptInterface
        fun setSpeedPitch(speed: Double, pitch: Double) {
            val s = speed.toFloat().coerceIn(0.25f, 3f)
            val p = pitch.toFloat().coerceIn(0.25f, 4f)
            this@MainActivity.getSharedPreferences("mm", android.content.Context.MODE_PRIVATE).edit()
                .putFloat("speed", s)
                .putFloat("pitch", p)
                .apply()
            withController { it.setPlaybackParameters(PlaybackParameters(s, p)) }
        }

        @JavascriptInterface
        fun eqInfo(): String = AudioFx.info(this@MainActivity)

        @JavascriptInterface
        fun eqSet(on: Boolean, levelsJson: String) {
            AudioFx.set(this@MainActivity, on, levelsJson)
        }

        /** Temporizador: minutos > 0, -1 = al terminar la canción, 0 = cancelar. */
        @JavascriptInterface
        fun setSleep(minutes: Int) {
            withController { c ->
                val args = Bundle()
                args.putInt("min", minutes)
                val f = c.sendCustomCommand(SessionCommand(PlaybackService.CMD_SLEEP, Bundle.EMPTY), args)
                f.addListener({ pushState() }, ContextCompat.getMainExecutor(this@MainActivity))
            }
        }

        @JavascriptInterface
        fun playCounts(): String = Stats.json(this@MainActivity)

        @JavascriptInterface
        fun lastPlayed(): String = Stats.lastJson(this@MainActivity)

        @JavascriptInterface
        fun mergeStats(json: String) {
            Stats.merge(this@MainActivity, json)
        }

        /** Transición suave entre canciones, en milisegundos (0 = apagada). */
        @JavascriptInterface
        fun setFade(ms: Int) {
            val v = ms.toLong().coerceIn(0L, 12_000L)
            this@MainActivity.getSharedPreferences("mm", android.content.Context.MODE_PRIVATE).edit()
                .putLong("fadeMs", v)
                .apply()
            PlaybackService.fadeMs = v
            main.post { PlaybackService.instance?.setFade(v) }
        }

        // ----- cola -----
        @JavascriptInterface
        fun queue() { main.post { sendQueue() } }

        @JavascriptInterface
        fun queuePlay(index: Int) {
            withController { c ->
                if (index in 0 until c.mediaItemCount) {
                    c.seekTo(index, 0L)
                    c.play()
                }
                sendQueue()
            }
        }

        @JavascriptInterface
        fun queueRemove(index: Int) {
            withController { c ->
                if (index in 0 until c.mediaItemCount && index != c.currentMediaItemIndex) c.removeMediaItem(index)
                sendQueue()
            }
        }

        @JavascriptInterface
        fun queueMove(from: Int, to: Int) {
            withController { c ->
                val n = c.mediaItemCount
                if (from in 0 until n && to in 0 until n && from != to) c.moveMediaItem(from, to)
                sendQueue()
            }
        }

        // ----- copia de seguridad -----
        @JavascriptInterface
        fun exportBackup(json: String, name: String) {
            pendingBackup = json
            main.post {
                try {
                    saveDoc.launch(name)
                } catch (e: Exception) {
                    pendingBackup = null
                    js("window.onBackupSaved && window.onBackupSaved(false)")
                }
            }
        }

        // ----- letras -----
        @JavascriptInterface
        fun lyrCacheGet(id: String): String = Lyrics.cacheGet(this@MainActivity, id)

        @JavascriptInterface
        fun lyrCachePut(id: String, text: String) {
            Lyrics.cachePut(this@MainActivity, id, text)
        }

        @JavascriptInterface
        fun lyrCacheDel(id: String) {
            Lyrics.cacheDel(this@MainActivity, id)
        }

        /** Letra dentro del archivo o en un .lrc al lado. Responde en window.onLyrLocal(req, texto|null). */
        @JavascriptInterface
        fun lyricsLocal(id: String, req: Int) {
            Thread {
                val t = try {
                    id.toLongOrNull()?.let { Lyrics.local(this@MainActivity, it) }
                } catch (e: Throwable) {
                    null
                }
                val arg = if (t == null) "null" else JSONObject.quote(t)
                js("window.onLyrLocal && window.onLyrLocal($req, $arg)")
            }.start()
        }

        /** Consulta a LRCLIB. Responde en window.onLyrHttp(req, código, texto). */
        @JavascriptInterface
        fun lyricsHttp(path: String, req: Int) {
            Thread {
                val r = try {
                    Lyrics.http(path)
                } catch (e: Throwable) {
                    Pair(0, "")
                }
                js("window.onLyrHttp && window.onLyrHttp($req, ${r.first}, ${JSONObject.quote(r.second)})")
            }.start()
        }

        @JavascriptInterface
        fun importLrc() {
            main.post {
                try {
                    openLrc.launch(arrayOf("*/*"))
                } catch (e: Exception) {
                    js("window.onLrcLoaded && window.onLrcLoaded(null)")
                }
            }
        }

        // ----- guardar y compartir -----
        @JavascriptInterface
        fun saveText(text: String, name: String, mime: String) = startSave(SaveJob.Text(text), name, mime)

        @JavascriptInterface
        fun saveBase64(b64: String, name: String, mime: String) {
            val data = try {
                Base64.decode(b64, Base64.DEFAULT)
            } catch (e: Exception) {
                js("window.onSaved && window.onSaved(false, null)")
                return
            }
            startSave(SaveJob.Bytes(data), name, mime)
        }

        @JavascriptInterface
        fun shareBase64(b64: String, name: String, mime: String) {
            Thread {
                try {
                    val dir = File(cacheDir, "share")
                    dir.mkdirs()
                    dir.listFiles()?.forEach { it.delete() }
                    val f = File(dir, name.replace(Regex("[^A-Za-z0-9._ -]"), "_").ifEmpty { "archivo" })
                    f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
                    val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.files", f)
                    val send = Intent(Intent.ACTION_SEND)
                        .setType(mime)
                        .putExtra(Intent.EXTRA_STREAM, uri)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    main.post {
                        try {
                            startActivity(Intent.createChooser(send, "Compartir"))
                        } catch (e: Exception) {
                            js("window.toast && toast('No se pudo compartir')")
                        }
                    }
                } catch (e: Throwable) {
                    js("window.toast && toast('No se pudo compartir')")
                }
            }.start()
        }

        // ----- tramo A-B y recortar audio -----
        @JavascriptInterface
        fun setAB(a: Double, b: Double) {
            withController { c ->
                val args = Bundle()
                args.putLong("a", a.toLong())
                args.putLong("b", b.toLong())
                val f = c.sendCustomCommand(SessionCommand(PlaybackService.CMD_AB, Bundle.EMPTY), args)
                f.addListener({ pushState() }, ContextCompat.getMainExecutor(this@MainActivity))
            }
        }

        /** "mp3", "m4a", "wav" o "" si no se puede recortar. */
        @JavascriptInterface
        fun clipKind(id: String): String = try {
            id.toLongOrNull()?.let { Clip.kind(this@MainActivity, it) } ?: ""
        } catch (e: Exception) {
            ""
        }

        @JavascriptInterface
        fun saveClip(id: String, a: Double, b: Double, name: String, mime: String) {
            val n = id.toLongOrNull() ?: return
            startSave(SaveJob.Audio(n, a.toLong(), b.toLong()), name, mime)
        }

        // ----- fondo de pantalla -----
        @JavascriptInterface
        fun pickBackground() {
            main.post {
                try {
                    pickImg.launch(
                        PickVisualMediaRequest.Builder()
                            .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            .build()
                    )
                } catch (e: Exception) {
                    js("window.onBgPicked && window.onBgPicked(false)")
                }
            }
        }

        @JavascriptInterface
        fun clearBackground() = Bg.clear(this@MainActivity)

        // ----- letras: todas, línea actual para notificación/widget -----
        @JavascriptInterface
        fun lyrCacheAll(): String = Lyrics.cacheAll(this@MainActivity)

        @JavascriptInterface
        fun lyrNow(id: String, json: String) {
            Lyrics.nowPut(this@MainActivity, id, json)
            main.post { PlaybackService.instance?.reloadLyrics(id) }
        }

        @JavascriptInterface
        fun setLyricsNotif(on: Boolean) {
            getSharedPreferences("mm", Context.MODE_PRIVATE).edit().putBoolean("lyrNotif", on).apply()
            main.post { PlaybackService.instance?.setLyricsInNotification(on) }
        }

        // ----- nombres editados y estadísticas por mes -----
        @JavascriptInterface
        fun setMeta(json: String, refresh: Boolean) {
            Library.setOverrides(json)
            if (refresh) main.post { PlaybackService.instance?.refreshNowMeta() }
        }

        @JavascriptInterface
        fun monthStats(): String = Stats.monthsJson(this@MainActivity)

        @JavascriptInterface
        fun importBackup() {
            main.post {
                try {
                    openDoc.launch(arrayOf("*/*"))
                } catch (e: Exception) {
                    js("window.onBackupLoaded && window.onBackupLoaded(null)")
                }
            }
        }

        // ----- acceso por invitación y modo admin -----
        /** Número de versión (el número de compilación de GitHub). */
        @JavascriptInterface
        fun appVersion(): Int = try {
            androidx.core.content.pm.PackageInfoCompat
                .getLongVersionCode(packageManager.getPackageInfo(packageName, 0)).toInt()
        } catch (e: Exception) {
            0
        }

        @JavascriptInterface
        fun deviceModel(): String {
            val model = Build.MODEL ?: ""
            val brand = (Build.MANUFACTURER ?: "").replaceFirstChar { it.uppercase() }
            return if (model.startsWith(brand, ignoreCase = true)) model else "$brand $model".trim()
        }

        /** Consulta al servidor de acceso. Responde en window.onAccHttp(req, código, texto). */
        @JavascriptInterface
        fun accHttp(method: String, url: String, body: String, contentType: String, req: Int) {
            Thread {
                val r = try {
                    Acceso.http(method, url, body, contentType)
                } catch (e: Throwable) {
                    Pair(0, "")
                }
                js("window.onAccHttp && window.onAccHttp($req, ${r.first}, ${JSONObject.quote(r.second)})")
            }.start()
        }

        // ----- reporte de sonido (para encontrar el sonido rasposo) -----
        /** Arma el reporte y lo manda a window.onSoundReport(texto). */
        @JavascriptInterface
        fun soundReport() {
            main.post {
                val now = try {
                    PlaybackService.instance?.soundState() ?: "El reproductor no está abierto ahora."
                } catch (e: Exception) {
                    "No se pudo leer el estado del reproductor."
                }
                val txt = SoundLog.report(now)
                js("window.onSoundReport && window.onSoundReport(${JSONObject.quote(txt)})")
            }
        }

        /** «¡Sonó raro!»: guarda el momento exacto y cómo estaba sonando. */
        @JavascriptInterface
        fun soundMark() {
            main.post {
                val svc = PlaybackService.instance
                if (svc != null) svc.markOdd() else SoundLog.add("⚑ TOCASTE «SONÓ RARO» (no había nada sonando)")
            }
        }

        @JavascriptInterface
        fun soundClear() = SoundLog.clear()

        @JavascriptInterface
        fun copyText(text: String) {
            main.post {
                try {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("NEAR Music", text))
                    js("window.toast && toast('Copiado')")
                } catch (e: Exception) {
                    js("window.toast && toast('No se pudo copiar')")
                }
            }
        }

        // ----- traducir la letra (sin internet después de bajar el idioma) -----
        /** Recibe {lines, to, src, dl}. Responde en window.onTr(req, json). */
        @JavascriptInterface
        fun translate(json: String, req: Int) {
            main.post {
                Traductor.run(json) { out -> js("window.onTr && window.onTr($req, ${JSONObject.quote(out)})") }
            }
        }

        @JavascriptInterface
        fun shareText(text: String) {
            main.post {
                try {
                    val send = Intent(Intent.ACTION_SEND)
                        .setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, text)
                    startActivity(Intent.createChooser(send, "Compartir"))
                } catch (e: Exception) {
                    js("window.toast && toast('No se pudo compartir')")
                }
            }
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            if (!url.startsWith("https://")) return
            main.post {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (e: Exception) {
                    js("window.toast && toast('No se pudo abrir el enlace')")
                }
            }
        }
    }
}
