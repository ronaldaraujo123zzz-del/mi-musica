package com.near.mimusica

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONArray
import org.json.JSONObject

/**
 * Traduce la letra dentro del teléfono (ML Kit de Google: gratis y sin clave).
 * La primera vez de cada idioma se baja un paquete (~30 MB); después funciona sin internet.
 *
 * Entrada: {"lines":[...], "to":"es", "src":"" (vacío = detectar solo), "dl":false (true = puede descargar)}
 * Salida:  {"ok":true, "src":"en", "to":"es", "map":{"línea original":"traducción", ...}}
 *          {"ok":true, "same":true, "src":"es"}                 ← ya está en ese idioma
 *          {"ok":false, "err":"descargar", "src":"en", "missing":["en","es"]}  ← hay que bajar idiomas
 *          {"ok":false, "err":"idioma" | "noSoportado" | "traducir" | "vacia" | "datos" | "detectar"}
 * Llamar desde el hilo principal; responde también en el hilo principal.
 */
object Traductor {
    private fun fail(code: String, extra: JSONObject = JSONObject()): String =
        extra.put("ok", false).put("err", code).toString()

    fun run(json: String, done: (String) -> Unit) {
        var finished = false
        val reply: (String) -> Unit = { out ->
            if (!finished) {
                finished = true
                done(out)
            }
        }
        try {
            val arg = JSONObject(json)
            val arr = arg.optJSONArray("lines") ?: JSONArray()
            val uniq = LinkedHashSet<String>()
            for (i in 0 until arr.length()) {
                val t = arr.optString(i).trim()
                if (t.isNotEmpty()) uniq.add(t)
            }
            val lines = uniq.toList()
            if (lines.isEmpty()) {
                reply(fail("vacia"))
                return
            }
            val to = TranslateLanguage.fromLanguageTag(arg.optString("to", "es")) ?: TranslateLanguage.SPANISH
            val src = arg.optString("src", "")
            val dl = arg.optBoolean("dl", false)
            if (src.isNotEmpty()) {
                withSource(src, to, lines, dl, reply)
                return
            }
            val sample = lines.joinToString("\n").take(2000)
            val ident = LanguageIdentification.getClient(
                LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.35f).build()
            )
            ident.identifyLanguage(sample)
                .addOnSuccessListener { code ->
                    ident.close()
                    withSource(code ?: "und", to, lines, dl, reply)
                }
                .addOnFailureListener {
                    ident.close()
                    reply(fail("detectar"))
                }
        } catch (e: Throwable) {
            reply(fail("datos"))
        }
    }

    private fun withSource(code: String, to: String, lines: List<String>, dl: Boolean, reply: (String) -> Unit) {
        if (code == "und") {
            reply(fail("idioma"))
            return
        }
        // "ja-Latn", "hi-Latn"…: idioma escrito con letras latinas (romaji, etc.): no se puede traducir bien
        val from = if (code.contains("-Latn")) null else TranslateLanguage.fromLanguageTag(code.substringBefore('-'))
        if (from == null) {
            reply(fail("noSoportado", JSONObject().put("src", code)))
            return
        }
        if (from == to) {
            reply(JSONObject().put("ok", true).put("same", true).put("src", from).toString())
            return
        }
        RemoteModelManager.getInstance().getDownloadedModels(TranslateRemoteModel::class.java)
            .addOnSuccessListener { models ->
                val have = models.map { it.language }.toSet()
                val missing = listOf(from, to).filter { it !in have }
                if (missing.isNotEmpty() && !dl) {
                    reply(
                        JSONObject().put("ok", false).put("err", "descargar")
                            .put("src", from).put("missing", JSONArray(missing)).toString()
                    )
                } else {
                    translateAll(from, to, lines, reply)
                }
            }
            .addOnFailureListener {
                if (dl) translateAll(from, to, lines, reply)
                else reply(
                    JSONObject().put("ok", false).put("err", "descargar")
                        .put("src", from).put("missing", JSONArray(listOf(from, to))).toString()
                )
            }
    }

    private fun translateAll(from: String, to: String, lines: List<String>, reply: (String) -> Unit) {
        val tr = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(from).setTargetLanguage(to).build()
        )
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .continueWithTask { t ->
                if (!t.isSuccessful) throw (t.exception ?: Exception("descarga"))
                Tasks.whenAllSuccess<String>(lines.map { tr.translate(it) })
            }
            .addOnSuccessListener { res ->
                val map = JSONObject()
                for (i in lines.indices) map.put(lines[i], res.getOrNull(i) ?: "")
                try {
                    tr.close()
                } catch (e: Throwable) {
                }
                reply(JSONObject().put("ok", true).put("src", from).put("to", to).put("map", map).toString())
            }
            .addOnFailureListener { e ->
                try {
                    tr.close()
                } catch (x: Throwable) {
                }
                reply(fail("traducir", JSONObject().put("msg", e.message ?: "")))
            }
    }
}
