package com.near.mimusica

import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONArray
import org.json.JSONObject

/**
 * Traduce la letra dentro del teléfono (ML Kit de Google: gratis y sin clave).
 * La primera vez de cada idioma se baja un paquete (~30 MB); después funciona sin internet.
 *
 * Detecta el idioma de CADA línea: una canción puede mezclar español, inglés u otros idiomas.
 * Las líneas cortas o dudosas ("oh", "yeah", nombres) toman el idioma principal de la canción.
 * Cada grupo de líneas se traduce con su propio traductor; las que ya están en el idioma
 * de destino se dejan igual.
 *
 * Entrada: {"lines":[...], "to":"es", "src":"" (vacío = detectar solo), "dl":false (true = puede descargar)}
 * Salida:  {"ok":true, "src":"en", "srcs":["en","fr"], "to":"es", "map":{"línea original":"traducción", ...}}
 *          {"ok":true, "same":true, "src":"es"}                 ← todo está ya en ese idioma
 *          {"ok":false, "err":"descargar", "src":"en", "missing":["en","es"]}  ← hay que bajar idiomas
 *          {"ok":false, "err":"idioma" | "noSoportado" | "traducir" | "vacia" | "datos" | "detectar"}
 * Llamar desde el hilo principal; responde también en el hilo principal.
 */
object Traductor {
    /** Seguridad mínima para que una línea cuente con un idioma distinto al principal. */
    private const val LINE_CONFIDENCE = 0.7f

    private fun fail(code: String, extra: JSONObject = JSONObject()): String =
        extra.put("ok", false).put("err", code).toString()

    /** Etiqueta de ML Kit ("en", "pt-BR", "ja-Latn") → idioma traducible, o null. */
    private fun code(tag: String?): String? {
        if (tag.isNullOrEmpty() || tag == "und" || tag.contains("-Latn")) return null
        return TranslateLanguage.fromLanguageTag(tag.substringBefore('-'))
    }

    /** Una línea sirve para detectar su idioma si tiene suficientes letras y al menos dos palabras. */
    private fun reliable(line: String): Boolean {
        val letters = line.count { it.isLetter() }
        val words = line.split(Regex("\\s+")).count { w -> w.any { it.isLetter() } }
        return letters >= 10 && words >= 2
    }

    fun run(json: String, done: (String) -> Unit) {
        var finished = false
        val reply: (String) -> Unit = { out ->
            if (!finished) {
                finished = true
                done(out)
            }
        }
        try {
            val arg = JSONObject(json)
            val arr = arg.optJSONArray("lines") ?: JSONArray()
            val uniq = LinkedHashSet<String>()
            for (i in 0 until arr.length()) {
                val t = arr.optString(i).trim()
                if (t.isNotEmpty()) uniq.add(t)
            }
            val lines = uniq.toList()
            if (lines.isEmpty()) {
                reply(fail("vacia"))
                return
            }
            val to = TranslateLanguage.fromLanguageTag(arg.optString("to", "es")) ?: TranslateLanguage.SPANISH
            val src = arg.optString("src", "")
            val dl = arg.optBoolean("dl", false)

            val whole = LanguageIdentification.getClient(
                LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.35f).build()
            )
            val perLine = LanguageIdentification.getClient(
                LanguageIdentificationOptions.Builder().setConfidenceThreshold(LINE_CONFIDENCE).build()
            )
            // idioma principal: el que eligió la persona, o el de toda la letra junta
            val mainTask: Task<String> =
                if (src.isNotEmpty()) Tasks.forResult(src)
                else whole.identifyLanguage(lines.joinToString("\n").take(2000))
            val lineTasks: List<Task<String>> = lines.map { l ->
                if (reliable(l)) perLine.identifyLanguage(l) else Tasks.forResult("und")
            }
            Tasks.whenAllComplete(listOf<Task<*>>(mainTask) + lineTasks).addOnCompleteListener {
                try {
                    whole.close()
                    perLine.close()
                } catch (e: Throwable) {
                }
                val mainTag = if (mainTask.isSuccessful) mainTask.result else null
                val tags = lineTasks.map { t -> if (t.isSuccessful) t.result else null }
                try {
                    plan(mainTag, tags, to, lines, dl, reply)
                } catch (e: Throwable) {
                    reply(fail("traducir", JSONObject().put("msg", e.message ?: "")))
                }
            }
        } catch (e: Throwable) {
            reply(fail("datos"))
        }
    }

    private fun plan(mainTag: String?, tags: List<String?>, to: String, lines: List<String>, dl: Boolean, reply: (String) -> Unit) {
        val perLine = tags.map { code(it) }
        // idioma principal; si no se pudo, el que más se repite entre las líneas
        val main = code(mainTag)
            ?: perLine.filterNotNull().groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        if (main == null) {
            if (mainTag.isNullOrEmpty() || mainTag == "und") reply(fail("idioma"))
            else reply(fail("noSoportado", JSONObject().put("src", mainTag)))
            return
        }
        val langOf = lines.indices.map { i -> perLine[i] ?: main }
        val groups = LinkedHashMap<String, MutableList<String>>()
        lines.indices.forEach { i -> groups.getOrPut(langOf[i]) { mutableListOf() }.add(lines[i]) }
        // primero el idioma principal, después los demás
        val need = groups.keys.filter { it != to }.sortedBy { if (it == main) 0 else 1 }
        if (need.isEmpty()) {
            reply(JSONObject().put("ok", true).put("same", true).put("src", main).toString())
            return
        }
        RemoteModelManager.getInstance().getDownloadedModels(TranslateRemoteModel::class.java)
            .addOnSuccessListener { models ->
                val have = models.map { it.language }.toSet()
                val missing = (need + to).distinct().filter { it !in have }
                if (missing.isNotEmpty() && !dl) {
                    reply(
                        JSONObject().put("ok", false).put("err", "descargar")
                            .put("src", need.first()).put("missing", JSONArray(missing)).toString()
                    )
                } else {
                    translateGroups(main, need, groups, to, lines, reply)
                }
            }
            .addOnFailureListener {
                if (dl) translateGroups(main, need, groups, to, lines, reply)
                else reply(
                    JSONObject().put("ok", false).put("err", "descargar")
                        .put("src", need.first()).put("missing", JSONArray((need + to).distinct())).toString()
                )
            }
    }

    /** Traduce cada grupo de líneas (uno por idioma), uno detrás de otro. */
    private fun translateGroups(main: String, need: List<String>, groups: Map<String, List<String>>, to: String, lines: List<String>, reply: (String) -> Unit) {
        val map = JSONObject()
        // lo que ya está en el idioma de destino queda igual
        groups[to]?.forEach { map.put(it, it) }
        val done = mutableListOf<String>()
        fun step(i: Int) {
            if (i >= need.size) {
                for (l in lines) if (!map.has(l)) map.put(l, l)
                // mezclada: hay líneas en varios idiomas (incluido el de destino)
                val mixed = groups.keys.size > 1
                reply(
                    JSONObject().put("ok", true).put("src", main).put("srcs", JSONArray(done))
                        .put("mixed", mixed).put("to", to).put("map", map).toString()
                )
                return
            }
            val from = need[i]
            val part = groups[from].orEmpty()
            translateList(from, to, part) { res, err ->
                if (res != null) {
                    for (k in part.indices) map.put(part[k], res.getOrNull(k) ?: part[k])
                    done.add(from)
                    step(i + 1)
                } else if (from == main) {
                    // si falla el idioma principal, no tiene sentido seguir
                    reply(fail("traducir", JSONObject().put("msg", err ?: "")))
                } else {
                    // un idioma secundario que falla: esas líneas quedan sin traducir
                    step(i + 1)
                }
            }
        }
        step(0)
    }

    private fun translateList(from: String, to: String, lines: List<String>, cb: (List<String>?, String?) -> Unit) {
        val tr = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(from).setTargetLanguage(to).build()
        )
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .continueWithTask { t ->
                if (!t.isSuccessful) throw (t.exception ?: Exception("descarga"))
                Tasks.whenAllSuccess<String>(lines.map { tr.translate(it) })
            }
            .addOnSuccessListener { res ->
                try {
                    tr.close()
                } catch (e: Throwable) {
                }
                cb(res, null)
            }
            .addOnFailureListener { e ->
                try {
                    tr.close()
                } catch (x: Throwable) {
                }
                cb(null, e.message ?: "traducir")
            }
    }
}
