package com.near.mimusica

import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.IdentifiedLanguage
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONArray
import org.json.JSONObject

/**
 * Traduce la letra dentro del teléfono (ML Kit de Google: gratis y sin clave).
 * La primera vez de cada idioma se baja un paquete (~30 MB); después funciona sin internet.
 *
 * Cómo decide el idioma de cada línea (una canción puede mezclar español, inglés u otros):
 *  1. Se limpia la línea: fuera "[Coro]", "(x2)", lo que va entre paréntesis y el relleno
 *     ("oh", "yeah", "baby", "uh"…), que no dice nada del idioma.
 *  2. Se averiguan los idiomas de la canción: los que salen al mirar toda la letra junta y los
 *     que ganan claramente en alguna línea larga. Si la persona los eligió a mano, esos y ya.
 *  3. Cada línea recibe puntos por cada idioma posible (con su porcentaje): los suyos propios,
 *     y menos puntos por los de las líneas vecinas de la misma estrofa. Las líneas cortas o
 *     dudosas se deciden así por su estrofa, no por el idioma de toda la canción.
 *
 * Para traducir con contexto, dos líneas seguidas del mismo idioma que forman una frase se
 * traducen juntas y luego se vuelven a separar. Si no se pueden separar bien, se usa la
 * traducción de cada línea sola.
 *
 * Entrada: {"lines":[...], "to":"es", "src":"" (vacío = detectar solo; "en" o "en,es" = elegido a mano),
 *           "dl":false (true = puede descargar)}
 *          Una línea vacía en "lines" marca un cambio de estrofa.
 * Salida:  {"ok":true, "src":"en", "srcs":["en","fr"], "to":"es", "mixed":true, "map":{"línea original":"traducción", ...}}
 *          {"ok":true, "same":true, "src":"es"}                 ← todo está ya en ese idioma
 *          {"ok":false, "err":"descargar", "src":"en", "missing":["en","es"]}  ← hay que bajar idiomas
 *          {"ok":false, "err":"idioma" | "noSoportado" | "traducir" | "vacia" | "datos"}
 * Llamar desde el hilo principal; responde también en el hilo principal.
 */
object Traductor {
    /** Un idioma posible y qué tan seguro está el detector (0 a 1). */
    private class Cand(val lang: String, val conf: Float)

    /** Palabras de relleno que no ayudan a saber el idioma (ya sin letras repetidas). */
    private val FILLER = setOf(
        "oh", "uh", "ah", "eh", "ey", "hey", "ay", "yeah", "yea", "ye", "yah", "yeh",
        "woah", "whoa", "wo", "wow", "uoh", "uo", "baby", "babe", "beibi", "m", "hm", "mh", "huh",
        "prr", "pr", "skr", "skrt", "brr", "br", "ooh", "uhu", "aha", "oho", "wey"
    )
    private val SING = Regex("^(na|la|da|ra|ta)\\1+$")         // "nanana", "lalala"
    private val BRACKETS = Regex("\\[[^\\]]*]")
    private val PARENS = Regex("\\([^)]*\\)")
    private val TIMES = Regex("(?i)(\\(\\s*[x×]\\s*\\d+\\s*\\)|(?<=\\s)[x×]\\d+)\\s*$")   // "(x2)", " x3" al final
    private val SPACES = Regex("\\s+")

    /** Etiqueta de ML Kit ("en", "pt-BR", "ja-Latn") → idioma traducible, o null. */
    private fun code(tag: String?): String? {
        if (tag.isNullOrEmpty() || tag == "und" || tag.contains("-Latn")) return null
        return TranslateLanguage.fromLanguageTag(tag.substringBefore('-'))
    }

    private fun fail(code: String, extra: JSONObject = JSONObject()): String =
        extra.put("ok", false).put("err", code).toString()

    /** Texto que se manda al traductor: sin "[Coro]" ni "(x2)". */
    private fun forTranslation(line: String): String =
        line.replace(BRACKETS, " ").replace(TIMES, " ").replace(SPACES, " ").trim()

    private fun isFiller(word: String): Boolean {
        val w = word.lowercase()
        if (w in FILLER) return true
        val flat = w.replace(Regex("(.)\\1+"), "$1")                // "ohhh"→"oh", "yeahhh"→"yeah"
        return flat in FILLER || SING.matches(w)
    }

    /** Texto que se usa para detectar el idioma: sin paréntesis ni palabras de relleno. */
    private fun forDetection(line: String): String {
        val base = forTranslation(line)
        val noParens = base.replace(PARENS, " ")
        val src = if (noParens.any { it.isLetter() }) noParens else base   // si todo era paréntesis, se usa eso
        return src.split(Regex("[^\\p{L}\\p{M}']+"))
            .filter { w -> w.any { it.isLetter() } && !isFiller(w.trim('\'')) }
            .joinToString(" ")
    }

    /** Cuánto se puede confiar en la detección de una línea: 0 (nada) a 1 (línea larga). */
    private fun reliability(det: String): Float {
        val letters = det.count { it.isLetter() }
        return if (letters < 4) 0f else minOf(1f, letters / 18f)
    }

    /** Idiomas posibles de un resultado del detector (suma las variantes, p. ej. pt y pt-BR). */
    private fun cands(t: Task<List<IdentifiedLanguage>>): List<Cand> {
        if (!t.isSuccessful) return emptyList()
        val res = t.result ?: return emptyList()
        val sum = LinkedHashMap<String, Float>()
        for (il in res) {
            val c = code(il.languageTag) ?: continue
            sum[c] = (sum[c] ?: 0f) + il.confidence
        }
        return sum.map { Cand(it.key, minOf(1f, it.value)) }.sortedByDescending { it.conf }
    }

    fun run(json: String, done: (String) -> Unit) {
        var finished = false
        val reply: (String) -> Unit = { out ->
            if (!finished) {
                finished = true
                done(out)
            }
        }
        try {
            val arg = JSONObject(json)
            val arr = arg.optJSONArray("lines") ?: JSONArray()
            // línea → ¿empieza una estrofa nueva? (las repetidas se mandan una sola vez)
            val uniq = LinkedHashMap<String, Boolean>()
            var brk = false
            for (i in 0 until arr.length()) {
                val t = arr.optString(i).trim()
                if (t.isEmpty() || uniq.containsKey(t)) {
                    brk = true
                    continue
                }
                uniq[t] = brk
                brk = false
            }
            val lines = uniq.keys.toList()
            val newStanza = uniq.values.toList()
            if (lines.isEmpty()) {
                reply(fail("vacia"))
                return
            }
            val to = TranslateLanguage.fromLanguageTag(arg.optString("to", "es")) ?: TranslateLanguage.SPANISH
            val srcArg = arg.optString("src", "").trim()
            val manual = srcArg.split(',').mapNotNull { code(it.trim()) }.distinct()
            if (srcArg.isNotEmpty() && manual.isEmpty()) {
                reply(fail("noSoportado", JSONObject().put("src", srcArg)))
                return
            }
            val dl = arg.optBoolean("dl", false)

            val det = lines.map { forDetection(it) }
            val rel = det.map { reliability(it) }
            val client = LanguageIdentification.getClient(
                LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.05f).build()
            )
            val empty: Task<List<IdentifiedLanguage>> = Tasks.forResult(emptyList())
            val allText = det.filter { it.isNotEmpty() }.joinToString("\n").take(3000)
            val wholeTask: Task<List<IdentifiedLanguage>> =
                if (manual.isNotEmpty() || allText.isEmpty()) empty
                else client.identifyPossibleLanguages(allText)
            val lineTasks: List<Task<List<IdentifiedLanguage>>> = lines.indices.map { i ->
                if (manual.size != 1 && rel[i] > 0f) client.identifyPossibleLanguages(det[i]) else empty
            }
            Tasks.whenAllComplete(listOf<Task<*>>(wholeTask) + lineTasks).addOnCompleteListener {
                try {
                    client.close()
                } catch (e: Throwable) {
                }
                try {
                    val rawTop = if (wholeTask.isSuccessful) wholeTask.result?.firstOrNull()?.languageTag else null
                    val per = lineTasks.map { cands(it) }
                    plan(manual, cands(wholeTask), rawTop, per, rel, newStanza, to, lines, dl, reply)
                } catch (e: Throwable) {
                    reply(fail("traducir", JSONObject().put("msg", e.message ?: "")))
                }
            }
        } catch (e: Throwable) {
            reply(fail("datos"))
        }
    }

    /** ¿Las líneas i y j están en la misma estrofa? */
    private fun sameStanza(newStanza: List<Boolean>, i: Int, j: Int): Boolean {
        for (k in minOf(i, j) + 1..maxOf(i, j)) if (newStanza[k]) return false
        return true
    }

    private fun plan(
        manual: List<String>, whole: List<Cand>, rawTop: String?, per: List<List<Cand>>, rel: List<Float>,
        newStanza: List<Boolean>, to: String, lines: List<String>, dl: Boolean, reply: (String) -> Unit
    ) {
        val n = lines.size
        // ----- 1) idiomas de la canción -----
        val langs = LinkedHashSet<String>()
        // en cuántas líneas gana cada idioma (bien seguro / muy seguro y en línea larga)
        val wins = LinkedHashMap<String, Int>()
        val strong = LinkedHashMap<String, Int>()
        for (i in 0 until n) {
            val top = per[i].firstOrNull() ?: continue
            if (rel[i] >= 0.5f && top.conf >= 0.6f) wins[top.lang] = (wins[top.lang] ?: 0) + 1
            if (rel[i] >= 1f && top.conf >= 0.85f) strong[top.lang] = (strong[top.lang] ?: 0) + 1
        }
        val minLines = if (n < 8) 1 else 2
        val mainOrNull: String?
        if (manual.isNotEmpty()) {
            langs.addAll(manual)
            mainOrNull = manual[0]
        } else {
            mainOrNull = whole.firstOrNull()?.lang
                ?: strong.maxByOrNull { it.value }?.key
                ?: per.mapNotNull { it.firstOrNull()?.lang }.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        }
        if (mainOrNull == null) {
            if (rawTop.isNullOrEmpty() || rawTop == "und") reply(fail("idioma"))
            else reply(fail("noSoportado", JSONObject().put("src", rawTop)))
            return
        }
        val main: String = mainOrNull
        langs.add(main)
        if (manual.isEmpty()) {
            // un segundo idioma de la letra completa solo cuenta si de verdad gana en algunas líneas
            // (así el español no se confunde con portugués o italiano en líneas sueltas)
            whole.filter { it.conf >= 0.15f && (wins[it.lang] ?: 0) >= minLines }.forEach { langs.add(it.lang) }
            // idiomas que ganan claro en líneas largas, aunque toda la letra junta no los vea (un coro en inglés)
            strong.filter { it.value >= minLines }.keys.forEach { langs.add(it) }
        }

        // ----- 2) idioma de cada línea: la suya + las vecinas de la misma estrofa -----
        val offsets = intArrayOf(-2, -1, 1, 2)
        val weights = floatArrayOf(0.2f, 0.45f, 0.45f, 0.2f)
        val langOf = List(n) { i ->
            if (langs.size == 1) main
            else {
                val score = LinkedHashMap<String, Float>()
                for (l in langs) score[l] = if (l == main) 0.08f else 0f
                fun add(j: Int, w: Float) {
                    if (j < 0 || j >= n || rel[j] <= 0f) return
                    val ww = if (j == i || sameStanza(newStanza, i, j)) w else w * 0.35f
                    for (c in per[j]) {
                        val s = score[c.lang] ?: continue
                        score[c.lang] = s + c.conf * ww * rel[j]
                    }
                }
                add(i, 1.6f)
                for (k in offsets.indices) add(i + offsets[k], weights[k])
                score.maxByOrNull { it.value }?.key ?: main
            }
        }

        // ----- 3) grupos por idioma; lo que ya está en el idioma de destino queda igual -----
        val groups = LinkedHashMap<String, MutableList<Int>>()
        for (i in 0 until n) groups.getOrPut(langOf[i]) { mutableListOf() }.add(i)
        val need = groups.keys.filter { it != to }.sortedBy { if (it == main) 0 else 1 }
        if (need.isEmpty()) {
            reply(JSONObject().put("ok", true).put("same", true).put("src", main).toString())
            return
        }
        val mixed = groups.keys.size > 1
        RemoteModelManager.getInstance().getDownloadedModels(TranslateRemoteModel::class.java)
            .addOnSuccessListener { models ->
                val have = models.map { it.language }.toSet()
                val missing = (need + to).distinct().filter { it !in have }
                if (missing.isNotEmpty() && !dl) {
                    reply(
                        JSONObject().put("ok", false).put("err", "descargar")
                            .put("src", need.first()).put("missing", JSONArray(missing)).toString()
                    )
                } else {
                    translateGroups(main, need, groups, mixed, newStanza, to, lines, reply)
                }
            }
            .addOnFailureListener {
                if (dl) translateGroups(main, need, groups, mixed, newStanza, to, lines, reply)
                else reply(
                    JSONObject().put("ok", false).put("err", "descargar")
                        .put("src", need.first()).put("missing", JSONArray((need + to).distinct())).toString()
                )
            }
    }

    /** ¿La línea termina una frase? (entonces no se junta con la siguiente) */
    private fun endsSentence(s: String): Boolean {
        val c = s.trimEnd().lastOrNull() ?: return true
        return c == '.' || c == '!' || c == '?' || c == '…' || c == ';' || c == ':'
    }

    /** Traduce cada grupo de líneas (uno por idioma), uno detrás de otro. */
    private fun translateGroups(
        main: String, need: List<String>, groups: Map<String, List<Int>>, mixed: Boolean,
        newStanza: List<Boolean>, to: String, lines: List<String>, reply: (String) -> Unit
    ) {
        val map = JSONObject()
        groups[to]?.forEach { map.put(lines[it], lines[it]) }
        val done = mutableListOf<String>()
        fun step(g: Int) {
            if (g >= need.size) {
                for (l in lines) if (!map.has(l)) map.put(l, l)
                reply(
                    JSONObject().put("ok", true).put("src", main).put("srcs", JSONArray(done))
                        .put("mixed", mixed).put("to", to).put("map", map).toString()
                )
                return
            }
            val from = need[g]
            val idx = groups[from].orEmpty()
            val clean = idx.associateWith { forTranslation(lines[it]) }
            val singles = idx.filter { clean[it].orEmpty().isNotEmpty() }
            // pares: dos líneas seguidas, misma estrofa, mismo idioma, y la primera no cierra la frase
            val inGroup = idx.toHashSet()
            val pairs = mutableListOf<Pair<Int, Int>>()
            var k = 0
            while (k < singles.size) {
                val a = singles[k]
                val b = a + 1
                val ca = clean[a].orEmpty()
                val cb = clean[b].orEmpty()
                if (b in inGroup && cb.isNotEmpty() && !newStanza[b] && !endsSentence(ca) && ca.length + cb.length <= 140) {
                    pairs.add(a to b)
                    k += 2
                } else k += 1
            }
            val texts = singles.map { clean[it].orEmpty() } + pairs.map { (a, b) -> clean[a].orEmpty() + "\n" + clean[b].orEmpty() }
            translateList(from, to, texts) { res, err ->
                if (res != null) {
                    singles.forEachIndexed { s, i -> map.put(lines[i], res.getOrNull(s) ?: lines[i]) }
                    // si la frase traducida junta se puede volver a partir en dos, esa es mejor
                    pairs.forEachIndexed { p, (a, b) ->
                        val parts = res.getOrNull(singles.size + p).orEmpty()
                            .split('\n').map { it.trim() }.filter { it.isNotEmpty() }
                        if (parts.size == 2) {
                            map.put(lines[a], parts[0])
                            map.put(lines[b], parts[1])
                        }
                    }
                    done.add(from)
                    step(g + 1)
                } else if (from == main) {
                    // si falla el idioma principal, no tiene sentido seguir
                    reply(fail("traducir", JSONObject().put("msg", err ?: "")))
                } else {
                    // un idioma secundario que falla: esas líneas quedan sin traducir
                    step(g + 1)
                }
            }
        }
        step(0)
    }

    private fun translateList(from: String, to: String, texts: List<String>, cb: (List<String>?, String?) -> Unit) {
        if (texts.isEmpty()) {
            cb(emptyList(), null)
            return
        }
        val tr = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(from).setTargetLanguage(to).build()
        )
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .continueWithTask { t ->
                if (!t.isSuccessful) throw (t.exception ?: Exception("descarga"))
                Tasks.whenAllSuccess<String>(texts.map { tr.translate(it) })
            }
            .addOnSuccessListener { res ->
                try {
                    tr.close()
                } catch (e: Throwable) {
                }
                cb(res, null)
            }
            .addOnFailureListener { e ->
                try {
                    tr.close()
                } catch (x: Throwable) {
                }
                cb(null, e.message ?: "traducir")
            }
    }
}
