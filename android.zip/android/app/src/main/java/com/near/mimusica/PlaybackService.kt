package com.near.mimusica

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.media.AudioManager
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import org.json.JSONArray
import org.json.JSONObject
import androidx.media3.exoplayer.DecoderReuseEvaluation
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.DefaultAudioTrackBufferSizeProvider
import androidx.media3.exoplayer.source.ShuffleOrder
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

/**
 * Reproduce la música en segundo plano y muestra la notificación con aleatorio y bucle.
 * También aplica velocidad/tono, el ecualizador, el temporizador para dormir,
 * la transición suave entre canciones, actualiza el widget y cuenta las reproducciones.
 */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        const val CMD_SHUFFLE = "mm.SHUFFLE"
        const val CMD_REPEAT = "mm.REPEAT"
        const val CMD_SLEEP = "mm.SLEEP"
        const val CMD_AB = "mm.AB"
        const val CMD_CLOSE = "mm.CLOSE"

        /** Tramo A-B que se repite (milisegundos); -1 = sin tramo. */
        @Volatile
        var abA = -1L

        @Volatile
        var abB = -1L

        /** El servicio en marcha (para el widget); null si no está corriendo. */
        @Volatile
        var instance: PlaybackService? = null

        /** Hora (en milisegundos) a la que se apagará la música; 0 = sin temporizador. */
        @Volatile
        var sleepAt = 0L

        /** true = se apagará al terminar la canción que suena. */
        @Volatile
        var sleepEnd = false

        /** Duración de la transición suave en milisegundos; 0 = desactivada. */
        @Volatile
        var fadeMs = 0L
    }

    // ---------- volumen: temporizador y transición suave ----------
    private var sleepVol = 1f
    private var fadeIn = false

    /**
     * Curva del volumen al subir/bajar: el oído no escucha "en línea recta", así que una bajada
     * lineal se queda mucho rato alta y al final se corta de golpe (y a volumen bajito se notan
     * los escalones como un sonido rasposo). Con la curva al cuadrado la bajada se oye pareja.
     */
    private fun curve(x: Float): Float {
        val c = x.coerceIn(0f, 1f)
        return c * c
    }

    private fun applyVolume() {
        var v = sleepVol
        val f = fadeMs
        if (f > 0L) {
            val d = player.duration
            val pos = player.currentPosition
            if (d != C.TIME_UNSET && d > f * 2) {
                val rem = d - pos
                if (rem < f && (player.hasNextMediaItem() || player.repeatMode == Player.REPEAT_MODE_ONE)) {
                    v *= curve(rem.toFloat() / f)
                }
                if (fadeIn) {
                    if (pos < f) v *= curve(pos.toFloat() / f) else fadeIn = false
                }
            }
        } else {
            fadeIn = false
        }
        player.volume = v
    }

    private val volRun = object : Runnable {
        override fun run() {
            applyVolume()
            if (player.isPlaying && fadeMs > 0L) handler.postDelayed(this, 40)
        }
    }

    fun setFade(ms: Long) {
        fadeMs = ms.coerceIn(0L, 12_000L)
        getSharedPreferences("mm", Context.MODE_PRIVATE).edit().putLong("fadeMs", fadeMs).apply()
        handler.removeCallbacks(volRun)
        if (player.isPlaying && fadeMs > 0L) handler.post(volRun) else applyVolume()
    }

    // ---------- temporizador para dormir (baja el volumen poco a poco y pausa) ----------
    private var fadeStep = 0
    private val sleepFadeRun = object : Runnable {
        override fun run() {
            fadeStep++
            val steps = 60 // 60 pasos de 0,1 s = 6 s, en pasitos pequeños para que no suene a escalones
            if (fadeStep >= steps) {
                fadeStep = 0
                sleepAt = 0L
                player.pause()
                sleepVol = 1f
                applyVolume()
            } else {
                sleepVol = curve(1f - fadeStep.toFloat() / steps)
                applyVolume()
                handler.postDelayed(this, 100)
            }
        }
    }
    private val sleepRun = Runnable {
        fadeStep = 0
        handler.post(sleepFadeRun)
    }

    private fun setSleep(minutes: Int) {
        handler.removeCallbacks(sleepRun)
        handler.removeCallbacks(sleepFadeRun)
        fadeStep = 0
        sleepVol = 1f
        applyVolume()
        player.setPauseAtEndOfMediaItems(false)
        sleepAt = 0L
        sleepEnd = false
        if (minutes > 0) {
            val ms = minutes * 60_000L
            sleepAt = System.currentTimeMillis() + ms
            handler.postDelayed(sleepRun, ms)
        } else if (minutes == -1) {
            sleepEnd = true
            player.setPauseAtEndOfMediaItems(true)
        }
    }

    // ---------- contador de reproducciones ----------
    private var counted = false
    private val countRun = object : Runnable {
        override fun run() {
            val item = player.currentMediaItem
            val d = player.duration
            if (item != null && !counted && d != C.TIME_UNSET && d > 0 &&
                player.currentPosition >= minOf(30_000L, d / 2)
            ) {
                counted = true
                Stats.add(this@PlaybackService, item.mediaId)
            }
            if (player.isPlaying) handler.postDelayed(this, 3000)
        }
    }

    // ---------- widget ----------
    fun refreshWidget() {
        val item = player.currentMediaItem
        if (item == null) {
            NearWidget.update(this, null)
            return
        }
        val m = item.mediaMetadata
        val artist = m.extras?.getString("a") ?: m.artist?.toString() ?: ""
        NearWidget.update(
            this,
            WidgetNow(item.mediaId, m.title?.toString() ?: "", artist, player.isPlaying, lyricLine)
        )
    }

    fun widgetAction(action: String) {
        when (action) {
            NearWidget.A_TOGGLE -> {
                if (player.isPlaying) {
                    player.pause()
                } else {
                    if (player.playbackState == Player.STATE_IDLE) player.prepare()
                    if (player.playbackState == Player.STATE_ENDED) player.seekToDefaultPosition()
                    player.play()
                }
            }
            NearWidget.A_NEXT -> player.seekToNext()
            NearWidget.A_PREV -> player.seekToPrevious()
        }
    }

    // ---------- tramo A-B (se repite solo) ----------
    private val abRun = object : Runnable {
        override fun run() {
            val a = abA
            val b = abB
            if (a >= 0 && b > a && player.currentPosition >= b) player.seekTo(a)
            if (player.isPlaying && a >= 0) handler.postDelayed(this, 40)
        }
    }

    private fun setAB(a: Long, b: Long) {
        abA = a
        abB = b
        handler.removeCallbacks(abRun)
        if (a >= 0 && player.isPlaying) handler.post(abRun)
    }

    // ---------- letra: línea actual en la notificación y en el widget ----------
    @Volatile
    var lyricLine = ""
    private var lyrLines: List<Pair<Long, String>> = emptyList()
    private var lyrFor = ""
    private var lyrIdx = -2
    private var lyrNotif = true
    private var replacingMeta = false

    private fun replaceMeta(idx: Int, item: MediaItem) {
        replacingMeta = true
        try {
            player.replaceMediaItem(idx, item)
        } finally {
            replacingMeta = false
        }
    }

    private val lyrRun = object : Runnable {
        override fun run() {
            tickLyrics()
            if (player.isPlaying && lyrLines.isNotEmpty()) handler.postDelayed(this, 200)
        }
    }

    /** Vuelve a leer la letra de la canción que suena (la interfaz avisa cuando cambia). */
    fun reloadLyrics(id: String? = null) {
        val cur = player.currentMediaItem?.mediaId ?: ""
        if (id != null && id != cur) return
        lyrFor = cur
        lyrIdx = -2
        lyrLines = if (cur.isEmpty()) emptyList() else try {
            Lyrics.nowLines(this, cur)
        } catch (e: Exception) {
            emptyList()
        }
        handler.removeCallbacks(lyrRun)
        tickLyrics()
        if (player.isPlaying && lyrLines.isNotEmpty()) handler.postDelayed(lyrRun, 200)
    }

    fun setLyricsInNotification(on: Boolean) {
        lyrNotif = on
        getSharedPreferences("mm", Context.MODE_PRIVATE).edit().putBoolean("lyrNotif", on).apply()
        applyLyricMeta()
    }

    // la notificación solo cabe ~35 letras: las líneas largas se parten y se van mostrando por partes
    private var lyrChunk = -1
    private var lyrPieces: List<String> = emptyList()
    private var notifLine = ""

    private fun splitLine(line: String, max: Int = 34): List<String> {
        if (line.length <= max) return listOf(line)
        val words = line.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val parts = (line.length + max - 1) / max
        // el trozo más corto posible que deje la línea en "parts" partes parecidas
        var target = (line.length + parts - 1) / parts
        var out = greedy(words, target)
        while (out.size > parts && target < max) {
            target++
            out = greedy(words, target)
        }
        return out
    }

    private fun greedy(words: List<String>, limit: Int): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (w in words) {
            if (sb.isNotEmpty() && sb.length + 1 + w.length > limit) {
                out.add(sb.toString())
                sb.setLength(0)
            }
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(w)
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    private fun tickLyrics() {
        val pos = player.currentPosition
        var i = -1
        for (k in lyrLines.indices) {
            if (lyrLines[k].first <= pos + 100) i = k else break
        }
        if (i != lyrIdx) {
            lyrIdx = i
            val line = if (i >= 0) lyrLines[i].second.trim() else ""
            lyrPieces = if (line.isEmpty()) emptyList() else splitLine(line)
            lyrChunk = -1
            if (line != lyricLine) {
                lyricLine = line
                refreshWidget()
            }
        }
        // qué parte de la línea toca ahora (repartidas en el tiempo que dura la línea)
        var c = 0
        if (lyrPieces.size > 1 && i >= 0) {
            val start = lyrLines[i].first
            val end = if (i + 1 < lyrLines.size) lyrLines[i + 1].first else start + 6000L
            val dur = (end - start).coerceIn(1200L, 12_000L)
            val slot = dur / lyrPieces.size
            c = ((pos + 100 - start).coerceAtLeast(0L) / maxOf(1L, slot)).toInt().coerceIn(0, lyrPieces.size - 1)
        }
        if (c == lyrChunk) return
        lyrChunk = c
        val piece = lyrPieces.getOrNull(c) ?: ""
        notifLine = if (lyrPieces.size > 1) {
            (if (c > 0) "…" else "") + piece + (if (c < lyrPieces.size - 1) "…" else "")
        } else piece
        applyLyricMeta()
    }

    /** Pone la línea de la letra donde va el artista (o devuelve el artista si no hay letra). */
    private fun applyLyricMeta() {
        try {
            val idx = player.currentMediaItemIndex
            val item = player.currentMediaItem ?: return
            val m = item.mediaMetadata
            val artist = m.extras?.getString("a") ?: return // solo canciones de NEAR Music
            val want = if (lyrNotif && notifLine.isNotEmpty()) "♪ $notifLine" else artist
            if (m.artist?.toString() == want) return
            val meta = m.buildUpon().setArtist(want).build()
            replaceMeta(idx, item.buildUpon().setMediaMetadata(meta).build())
        } catch (e: Exception) {
            // si algo falla, la notificación sigue mostrando el artista
        }
    }

    /** Si cambiaste el nombre de la canción que suena, actualizar la notificación. */
    fun refreshNowMeta() {
        try {
            val idx = player.currentMediaItemIndex
            val item = player.currentMediaItem ?: return
            val s = item.mediaId.toLongOrNull()?.let { Library.songs[it] } ?: return
            val fresh = Library.mediaItem(s).mediaMetadata
            val artist = fresh.extras?.getString("a") ?: ""
            val want = if (lyrNotif && notifLine.isNotEmpty()) "♪ $notifLine" else artist
            replaceMeta(idx, item.buildUpon().setMediaMetadata(fresh.buildUpon().setArtist(want).build()).build())
            refreshWidget()
        } catch (e: Exception) {
        }
    }

    /** Cambiaste la carátula de una canción: que la notificación y la cola usen la nueva. */
    fun refreshArt(id: String) {
        try {
            val s = id.toLongOrNull()?.let { Library.songs[it] } ?: return
            val cur = player.currentMediaItemIndex
            for (i in 0 until player.mediaItemCount) {
                val item = player.getMediaItemAt(i)
                if (item.mediaId != id) continue
                if (i == cur) continue
                val fresh = Library.mediaItem(s).mediaMetadata
                replaceMeta(i, item.buildUpon().setMediaMetadata(fresh).build())
            }
            if (player.currentMediaItem?.mediaId == id) refreshNowMeta()
            saveItems()
            refreshWidget()
        } catch (e: Exception) {
        }
    }

    // ---------- aleatorio propio ----------
    // En vez del aleatorio de Android (que se notaba repetido y no dejaba ordenar la cola),
    // la cola se mezcla de verdad: así lo que ves en "Cola" es lo que va a sonar y lo puedes mover.
    private var origIds: List<String> = emptyList() // orden de antes de mezclar (para quitar el aleatorio)
    private var mixing = false
    private val rnd = java.security.SecureRandom()

    private fun artistOf(item: MediaItem): String =
        (item.mediaMetadata.extras?.getString("a") ?: item.mediaMetadata.artist?.toString() ?: "").lowercase().trim()

    /** Últimas canciones que sonaron (para que no vuelvan a salir al principio de la mezcla). */
    private fun recentIds(): Set<String> =
        (qprefs().getString("recent", "") ?: "").split(',').filter { it.isNotEmpty() }.toSet()

    private fun pushRecent(id: String) {
        if (id.isEmpty()) return
        val list = (qprefs().getString("recent", "") ?: "").split(',').filter { it.isNotEmpty() && it != id }.toMutableList()
        list.add(0, id)
        qprefs().edit().putString("recent", list.take(40).joinToString(",")).apply()
    }

    /** Mezcla bien: al azar de verdad, lo que sonó hace poco va al final y no salen dos del mismo artista seguidas. */
    private fun smartShuffle(src: List<MediaItem>, first: MediaItem? = null): List<MediaItem> {
        val recent = recentIds()
        val fresh = ArrayList<MediaItem>()
        val old = ArrayList<MediaItem>()
        for (m in src) {
            if (recent.contains(m.mediaId)) old.add(m) else fresh.add(m)
        }
        fresh.shuffle(rnd)
        old.shuffle(rnd)
        val out = ArrayList<MediaItem>(src.size)
        out.addAll(fresh)
        out.addAll(old)
        // separar canciones del mismo artista que quedaron juntas (también de la que ya suena)
        val start = if (first != null) 0 else 1
        for (i in start until out.size) {
            val prev = if (i == 0) artistOf(first!!) else artistOf(out[i - 1])
            if (prev.isEmpty() || artistOf(out[i]) != prev) continue
            val end = minOf(out.size, i + 60)
            for (j in i + 1 until end) {
                if (artistOf(out[j]) != prev) {
                    val t = out[i]; out[i] = out[j]; out[j] = t
                    break
                }
            }
        }
        return out
    }

    private fun allItems(): List<MediaItem> = (0 until player.mediaItemCount).map { player.getMediaItemAt(it) }

    /** Cambia el orden de la cola sin cortar la canción que suena. */
    private fun rebuildAround(before: List<MediaItem>, after: List<MediaItem>) {
        mixing = true
        try {
            val cur = player.currentMediaItemIndex
            val n = player.mediaItemCount
            if (cur + 1 < n) player.removeMediaItems(cur + 1, n)
            if (cur > 0) player.removeMediaItems(0, cur)
            if (after.isNotEmpty()) player.addMediaItems(1, after)
            if (before.isNotEmpty()) player.addMediaItems(0, before)
        } finally {
            mixing = false
        }
        saveItems()
    }

    private fun saveOrig() {
        qprefs().edit().putString("orig", origIds.joinToString(",")).apply()
    }

    /** Aleatorio activado: la canción que suena queda primera y el resto se mezcla. */
    private fun mixNow() {
        val items = allItems()
        val cur = player.currentMediaItemIndex
        if (items.size < 2 || cur < 0) return
        origIds = items.map { it.mediaId }
        saveOrig()
        val rest = items.filterIndexed { i, _ -> i != cur }
        rebuildAround(emptyList(), smartShuffle(rest, items[cur]))
    }

    /** Aleatorio desactivado: vuelve el orden de la lista, siguiendo desde la canción que suena. */
    private fun unmixNow() {
        val items = allItems()
        val cur = player.currentMediaItemIndex
        if (origIds.isEmpty() || items.size < 2 || cur < 0) {
            origIds = emptyList(); saveOrig(); return
        }
        val pool = HashMap<String, ArrayDeque<MediaItem>>()
        items.forEachIndexed { i, m ->
            if (i != cur) pool.getOrPut(m.mediaId) { ArrayDeque() }.addLast(m)
        }
        val curId = items[cur].mediaId
        val p = origIds.indexOf(curId)
        val before = ArrayList<MediaItem>()
        val after = ArrayList<MediaItem>()
        origIds.forEachIndexed { k, id ->
            if (k == p) return@forEachIndexed
            val m = pool[id]?.removeFirstOrNull() ?: return@forEachIndexed
            if (p >= 0 && k < p) before.add(m) else after.add(m)
        }
        // las que añadiste después de mezclar: justo después de la que suena
        val extra = items.filterIndexed { i, m -> i != cur && pool[m.mediaId]?.remove(m) == true }
        origIds = emptyList()
        saveOrig()
        rebuildAround(before, extra + after)
    }

    /** Pone una lista a sonar. Con aleatorio: la elegida (o una al azar) primero y el resto bien mezclado. */
    fun playList(items: List<MediaItem>, startId: String, shuffle: Boolean) {
        if (items.isEmpty()) return
        var start = items.indexOfFirst { it.mediaId == startId }
        mixing = true
        try {
            player.shuffleModeEnabled = shuffle
            if (shuffle) {
                if (start < 0) start = rnd.nextInt(items.size)
                origIds = items.map { it.mediaId }
                val rest = items.filterIndexed { i, _ -> i != start }
                player.setMediaItems(listOf(items[start]) + smartShuffle(rest, items[start]), 0, 0L)
            } else {
                if (start < 0) start = 0
                origIds = emptyList()
                player.setMediaItems(items, start, 0L)
            }
        } finally {
            mixing = false
        }
        saveOrig()
        saveItems()
        player.prepare()
        player.play()
    }

    // ---------- recordar la cola: si Android cierra el reproductor en pausa, no se pierde nada ----------
    private fun qprefs() = getSharedPreferences("mm_queue", Context.MODE_PRIVATE)

    private val saveRun = object : Runnable {
        override fun run() {
            savePosition()
            if (player.isPlaying) handler.postDelayed(this, 10_000)
        }
    }

    /** Guarda la lista de canciones de la cola (cuando cambia). */
    private fun saveItems() {
        try {
            val n = player.mediaItemCount
            if (n == 0) return // una cola vacía no borra la última guardada
            val arr = JSONArray()
            for (i in 0 until minOf(n, 2000)) {
                val item = player.getMediaItemAt(i)
                val m = item.mediaMetadata
                arr.put(
                    JSONObject()
                        .put("id", item.mediaId)
                        .put("t", m.title?.toString() ?: "")
                        .put("a", m.extras?.getString("a") ?: m.artist?.toString() ?: "")
                        .put("al", m.albumTitle?.toString() ?: "")
                        .put("art", m.artworkUri?.toString() ?: "")
                )
            }
            qprefs().edit().putString("items", arr.toString()).apply()
            savePosition()
        } catch (e: Exception) {
        }
    }

    /** Guarda en qué canción y en qué segundo vas, y el aleatorio / repetir. */
    private fun savePosition() {
        try {
            if (player.mediaItemCount == 0) return
            qprefs().edit()
                .putInt("index", player.currentMediaItemIndex)
                .putString("id", player.currentMediaItem?.mediaId ?: "")
                .putLong("pos", maxOf(0L, player.currentPosition))
                .putBoolean("shuffle", player.shuffleModeEnabled)
                .putInt("repeat", player.repeatMode)
                .apply()
        } catch (e: Exception) {
        }
    }

    private class Saved(val items: List<MediaItem>, val index: Int, val pos: Long, val shuffle: Boolean, val repeat: Int)

    private fun loadSaved(): Saved? {
        return try {
            val sp = qprefs()
            val arr = JSONArray(sp.getString("items", null) ?: return null)
            val list = ArrayList<MediaItem>(arr.length())
            val wantId = sp.getString("id", "") ?: ""
            var index = -1
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id").toLongOrNull() ?: continue
                val art = o.optString("art").ifEmpty { null }?.let { android.net.Uri.parse(it) }
                if (index < 0 && o.optString("id") == wantId) index = list.size
                list.add(Library.mediaItemFrom(id, o.optString("t"), o.optString("a"), o.optString("al"), art))
            }
            if (list.isEmpty()) return null
            if (index < 0) index = sp.getInt("index", 0).coerceIn(0, list.size - 1)
            Saved(list, index, sp.getLong("pos", 0L), sp.getBoolean("shuffle", false), sp.getInt("repeat", Player.REPEAT_MODE_OFF))
        } catch (e: Exception) {
            null
        }
    }

    /** Al abrir: si la cola está vacía, vuelve a poner la última, en pausa, donde la dejaste. */
    private fun restoreQueue() {
        if (player.mediaItemCount > 0) return
        val s = loadSaved() ?: return
        origIds = (qprefs().getString("orig", "") ?: "").split(',').filter { it.isNotEmpty() }
        try {
            mixing = true
            player.shuffleModeEnabled = s.shuffle
            mixing = false
            player.repeatMode = s.repeat
            player.setMediaItems(s.items, s.index, s.pos)
            player.playWhenReady = false
            player.prepare()
            // cola guardada por la versión anterior con aleatorio: se mezcla con el aleatorio nuevo
            if (s.shuffle && origIds.isEmpty()) mixNow()
        } catch (e: Exception) {
        }
    }

    // ---------- caja negra del sonido (para el reporte) ----------
    private fun fmtMs(ms: Long): String {
        val s = maxOf(0L, ms) / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun where(): String {
        val t = player.currentMediaItem?.mediaMetadata?.title?.toString() ?: "?"
        return "«$t» en ${fmtMs(player.currentPosition)}"
    }

    private val soundWatch = object : AnalyticsListener {
        override fun onAudioUnderrun(
            eventTime: AnalyticsListener.EventTime,
            bufferSize: Int,
            bufferSizeMs: Long,
            elapsedSinceLastFeedMs: Long
        ) {
            SoundLog.underrun("CORTE DE AUDIO ${where()} (búfer ${bufferSizeMs} ms, ${elapsedSinceLastFeedMs} ms sin datos)")
        }

        override fun onAudioSinkError(eventTime: AnalyticsListener.EventTime, audioSinkError: Exception) {
            SoundLog.add("Error de salida de audio ${where()}: ${audioSinkError.javaClass.simpleName} ${audioSinkError.message ?: ""}")
        }

        override fun onAudioCodecError(eventTime: AnalyticsListener.EventTime, audioCodecError: Exception) {
            SoundLog.add("Error del decodificador ${where()}: ${audioCodecError.javaClass.simpleName} ${audioCodecError.message ?: ""}")
        }

        override fun onAudioInputFormatChanged(
            eventTime: AnalyticsListener.EventTime,
            format: Format,
            decoderReuseEvaluation: DecoderReuseEvaluation?
        ) {
            val br = if (format.bitrate > 0) " · ${format.bitrate / 1000} kbps" else ""
            SoundLog.format = "${format.sampleMimeType ?: "?"} · ${format.sampleRate} Hz · ${format.channelCount} canal(es)$br"
        }

        override fun onAudioDecoderInitialized(
            eventTime: AnalyticsListener.EventTime,
            decoderName: String,
            initializedTimestampMs: Long,
            initializationDurationMs: Long
        ) {
            SoundLog.decoder = decoderName
        }

        override fun onAudioTrackInitialized(
            eventTime: AnalyticsListener.EventTime,
            audioTrackConfig: AudioSink.AudioTrackConfig
        ) {
            val ch = maxOf(1, Integer.bitCount(audioTrackConfig.channelConfig))
            val bps = if (audioTrackConfig.encoding == C.ENCODING_PCM_FLOAT) 4 else 2
            val rate = maxOf(1, audioTrackConfig.sampleRate)
            val ms = audioTrackConfig.bufferSize * 1000L / (rate.toLong() * ch * bps)
            SoundLog.track = "${audioTrackConfig.sampleRate} Hz · búfer de $ms ms" +
                (if (audioTrackConfig.offload) " · offload" else "")
        }

        override fun onPlaybackParametersChanged(
            eventTime: AnalyticsListener.EventTime,
            playbackParameters: PlaybackParameters
        ) {
            SoundLog.add("Cambiaste velocidad/tono: ${speedPitchText(playbackParameters)}")
        }
    }

    private fun speedPitchText(p: PlaybackParameters): String {
        val semis = 12.0 * Math.log(p.pitch.toDouble()) / Math.log(2.0)
        val tono = if (Math.abs(semis) < 0.05) "normal" else "%+.1f semitonos".format(semis)
        val linked = Math.abs(p.speed - p.pitch) < 0.001f && Math.abs(p.speed - 1f) > 0.001f
        return "velocidad %.2f× · tono %s".format(p.speed, tono) + (if (linked) " (unidos, tipo disco)" else "")
    }

    /** Cómo está sonando ahora mismo (para el reporte y para «¡Sonó raro!»). Llamar en el hilo principal. */
    fun soundState(): String {
        val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val sys = try {
            val cur = am?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: -1
            val max = am?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: -1
            if (cur >= 0 && max > 0) "$cur de $max" else "?"
        } catch (e: Exception) {
            "?"
        }
        val sb = StringBuilder()
        sb.append(if (player.isPlaying) "Sonando " else "En pausa ").append(where())
        sb.append("\n").append(speedPitchText(player.playbackParameters))
        sb.append("\nEcualizador: ").append(AudioFx.describe(this))
        sb.append("\nVolumen del teléfono: ").append(sys)
        sb.append(" · volumen interno: ").append(Math.round(player.volume * 100)).append('%')
        sb.append("\nTransición suave: ").append(if (fadeMs > 0) "${fadeMs / 1000.0} s" else "apagada")
        if (sleepAt > 0L || sleepEnd) sb.append(" · temporizador para dormir activo")
        if (abA >= 0) sb.append(" · repitiendo tramo A-B")
        sb.append("\nLetra en la notificación: ").append(if (lyrNotif) "sí" else "no")
        return sb.toString()
    }

    /** Tocaste «¡Sonó raro!»: se guarda el momento y cómo estaba todo. */
    fun markOdd() {
        SoundLog.add("⚑ TOCASTE «SONÓ RARO» · " + soundState().replace("\n", " · "))
    }

    override fun onCreate() {
        super.onCreate()
        Covers.init(this)
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        // Búfer de audio más grande (0,5–1 s en vez de 0,25–0,75 s): si el teléfono se pone lento
        // un instante (otra app, la letra, el widget…) el sonido no se queda sin datos y no se "pega".
        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink? = DefaultAudioSink.Builder(context)
                .setEnableFloatOutput(enableFloatOutput)
                .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                .setAudioTrackBufferSizeProvider(
                    DefaultAudioTrackBufferSizeProvider.Builder()
                        .setMinPcmBufferDurationUs(500_000)
                        .setMaxPcmBufferDurationUs(1_000_000)
                        .build()
                )
                .build()
        }
        player = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        // el orden de la cola ES el orden en que suena (el aleatorio mezcla la cola de verdad)
        player.setShuffleOrder(ShuffleOrder.UnshuffledShuffleOrder(0))

        // velocidad, tono y transición guardados
        val sp = getSharedPreferences("mm", Context.MODE_PRIVATE)
        val speed = sp.getFloat("speed", 1f).coerceIn(0.25f, 3f)
        val pitch = sp.getFloat("pitch", 1f).coerceIn(0.25f, 4f)
        player.setPlaybackParameters(PlaybackParameters(speed, pitch))
        fadeMs = sp.getLong("fadeMs", 0L).coerceIn(0L, 12_000L)
        lyrNotif = sp.getBoolean("lyrNotif", true)

        // ecualizador
        AudioFx.attach(this, player.audioSessionId)

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, player)
            .setSessionActivity(open)
            .setCallback(Callback())
            .setCustomLayout(buttons())
            .build()

        player.addListener(object : Player.Listener {
            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                updateButtons()
                if (!mixing) {
                    if (shuffleModeEnabled) mixNow() else unmixNow()
                }
                savePosition()
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                updateButtons()
                savePosition()
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                if (reason == Player.DISCONTINUITY_REASON_SEEK) savePosition()
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                AudioFx.attach(this@PlaybackService, audioSessionId)
            }

            override fun onTimelineChanged(timeline: Timeline, reason: Int) {
                if (!replacingMeta && !mixing && reason == Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED) saveItems()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                // cambiar solo la línea de la letra no es "otra canción"
                if (replacingMeta) return
                savePosition()
                pushRecent(mediaItem?.mediaId ?: "")
                setAB(-1L, -1L)
                lyricLine = ""
                notifLine = ""
                reloadLyrics()
                counted = false
                fadeIn = reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO ||
                    reason == Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT
                applyVolume()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) closedByUser = false
                handler.removeCallbacks(countRun)
                handler.removeCallbacks(volRun)
                handler.removeCallbacks(abRun)
                handler.removeCallbacks(lyrRun)
                handler.removeCallbacks(saveRun)
                savePosition()
                if (isPlaying) {
                    handler.postDelayed(saveRun, 10_000)
                    if (abA >= 0) handler.post(abRun)
                    if (lyrLines.isNotEmpty()) handler.post(lyrRun)
                    handler.postDelayed(countRun, 3000)
                    if (fadeMs > 0L) handler.post(volRun)
                }
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                // "al terminar esta canción": ya se pausó, así que se quita el temporizador
                if (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM && sleepEnd) {
                    sleepEnd = false
                    player.setPauseAtEndOfMediaItems(false)
                }
            }

            override fun onEvents(player: Player, events: Player.Events) {
                if (events.containsAny(
                        Player.EVENT_MEDIA_ITEM_TRANSITION,
                        Player.EVENT_IS_PLAYING_CHANGED,
                        Player.EVENT_MEDIA_METADATA_CHANGED
                    )
                ) refreshWidget()
            }
        })
        player.addAnalyticsListener(soundWatch)
        restoreQueue()
        updateButtons()
        instance = this
        refreshWidget()
    }

    private fun buttons(): ImmutableList<CommandButton> {
        val shuffle = CommandButton.Builder()
            .setDisplayName(if (player.shuffleModeEnabled) "Aleatorio: sí" else "Aleatorio: no")
            .setIconResId(if (player.shuffleModeEnabled) R.drawable.ic_shuffle_on else R.drawable.ic_shuffle_off)
            .setSessionCommand(SessionCommand(CMD_SHUFFLE, Bundle.EMPTY))
            .build()
        val repeatIcon = when (player.repeatMode) {
            Player.REPEAT_MODE_ALL -> R.drawable.ic_repeat_all
            Player.REPEAT_MODE_ONE -> R.drawable.ic_repeat_one
            else -> R.drawable.ic_repeat_off
        }
        val repeatName = when (player.repeatMode) {
            Player.REPEAT_MODE_ALL -> "Repetir todo"
            Player.REPEAT_MODE_ONE -> "Repetir una"
            else -> "Repetir: no"
        }
        val repeat = CommandButton.Builder()
            .setDisplayName(repeatName)
            .setIconResId(repeatIcon)
            .setSessionCommand(SessionCommand(CMD_REPEAT, Bundle.EMPTY))
            .build()
        val close = CommandButton.Builder()
            .setDisplayName("Cerrar")
            .setIconResId(R.drawable.ic_close)
            .setSessionCommand(SessionCommand(CMD_CLOSE, Bundle.EMPTY))
            .build()
        return ImmutableList.of(shuffle, repeat, close)
    }

    // ---------- que la notificación no desaparezca en pausa ----------
    // Mientras haya una canción cargada (aunque esté en pausa) el reproductor sigue "en uso":
    // así el teléfono no lo cierra para ahorrar batería y la notificación se queda.
    // Para quitarla está el botón ✕ (la cola queda guardada).
    private var closedByUser = false

    override fun onUpdateNotification(session: MediaSession, startInForegroundRequired: Boolean) {
        val p = session.player
        val keep = !closedByUser && p.mediaItemCount > 0 &&
            p.playbackState != Player.STATE_IDLE && p.playbackState != Player.STATE_ENDED
        try {
            super.onUpdateNotification(session, startInForegroundRequired || keep)
        } catch (e: Exception) {
            // Android no dejó mantenerla en primer plano: comportamiento normal
            super.onUpdateNotification(session, startInForegroundRequired)
        }
    }

    /** Botón ✕: pausa, guarda dónde ibas y quita la notificación. */
    private fun closeFromNotification() {
        closedByUser = true
        player.pause()
        savePosition()
        player.stop() // queda la cola; al darle play otra vez vuelve a cargar
    }

    private fun updateButtons() {
        session?.setCustomLayout(buttons())
    }

    private inner class Callback : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SessionCommand(CMD_SHUFFLE, Bundle.EMPTY))
                .add(SessionCommand(CMD_REPEAT, Bundle.EMPTY))
                .add(SessionCommand(CMD_SLEEP, Bundle.EMPTY))
                .add(SessionCommand(CMD_AB, Bundle.EMPTY))
                .add(SessionCommand(CMD_CLOSE, Bundle.EMPTY))
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(commands)
                .build()
        }

        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            val s = loadSaved()
                ?: return Futures.immediateFailedFuture(UnsupportedOperationException("sin cola guardada"))
            origIds = (qprefs().getString("orig", "") ?: "").split(',').filter { it.isNotEmpty() }
            mixing = true
            player.shuffleModeEnabled = s.shuffle
            mixing = false
            player.repeatMode = s.repeat
            return Futures.immediateFuture(MediaSession.MediaItemsWithStartPosition(s.items, s.index, s.pos))
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            when (customCommand.customAction) {
                CMD_SHUFFLE -> player.shuffleModeEnabled = !player.shuffleModeEnabled
                CMD_REPEAT -> player.repeatMode = when (player.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
                CMD_SLEEP -> setSleep(args.getInt("min", 0))
                CMD_AB -> setAB(args.getLong("a", -1L), args.getLong("b", -1L))
                CMD_CLOSE -> closeFromNotification()
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        savePosition()
        val p = session?.player
        // en pausa con canción cargada: la notificación se queda (se quita con ✕)
        if (p == null || p.mediaItemCount == 0 || closedByUser) stopSelf()
    }

    override fun onDestroy() {
        savePosition()
        handler.removeCallbacksAndMessages(null)
        instance = null
        abA = -1L
        abB = -1L
        sleepAt = 0L
        sleepEnd = false
        AudioFx.release()
        NearWidget.update(this, null)
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
