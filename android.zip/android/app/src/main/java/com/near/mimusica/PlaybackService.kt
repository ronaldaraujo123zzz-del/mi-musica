package com.near.mimusica

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

/**
 * Reproduce la música en segundo plano y muestra la notificación con aleatorio y bucle.
 * También aplica velocidad/tono, el ecualizador, el temporizador para dormir,
 * la transición suave entre canciones, actualiza el widget y cuenta las reproducciones.
 */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        const val CMD_SHUFFLE = "mm.SHUFFLE"
        const val CMD_REPEAT = "mm.REPEAT"
        const val CMD_SLEEP = "mm.SLEEP"

        /** El servicio en marcha (para el widget); null si no está corriendo. */
        @Volatile
        var instance: PlaybackService? = null

        /** Hora (en milisegundos) a la que se apagará la música; 0 = sin temporizador. */
        @Volatile
        var sleepAt = 0L

        /** true = se apagará al terminar la canción que suena. */
        @Volatile
        var sleepEnd = false

        /** Duración de la transición suave en milisegundos; 0 = desactivada. */
        @Volatile
        var fadeMs = 0L
    }

    // ---------- volumen: temporizador y transición suave ----------
    private var sleepVol = 1f
    private var fadeIn = false

    private fun applyVolume() {
        var v = sleepVol
        val f = fadeMs
        if (f > 0L) {
            val d = player.duration
            val pos = player.currentPosition
            if (d != C.TIME_UNSET && d > f * 2) {
                val rem = d - pos
                if (rem < f && (player.hasNextMediaItem() || player.repeatMode == Player.REPEAT_MODE_ONE)) {
                    v *= (rem.toFloat() / f).coerceIn(0f, 1f)
                }
                if (fadeIn) {
                    if (pos < f) v *= (pos.toFloat() / f).coerceIn(0f, 1f) else fadeIn = false
                }
            }
        } else {
            fadeIn = false
        }
        player.volume = v
    }

    private val volRun = object : Runnable {
        override fun run() {
            applyVolume()
            if (player.isPlaying && fadeMs > 0L) handler.postDelayed(this, 100)
        }
    }

    fun setFade(ms: Long) {
        fadeMs = ms.coerceIn(0L, 12_000L)
        getSharedPreferences("mm", Context.MODE_PRIVATE).edit().putLong("fadeMs", fadeMs).apply()
        handler.removeCallbacks(volRun)
        if (player.isPlaying && fadeMs > 0L) handler.post(volRun) else applyVolume()
    }

    // ---------- temporizador para dormir (baja el volumen poco a poco y pausa) ----------
    private var fadeStep = 0
    private val sleepFadeRun = object : Runnable {
        override fun run() {
            fadeStep++
            val steps = 20
            if (fadeStep >= steps) {
                fadeStep = 0
                sleepAt = 0L
                player.pause()
                sleepVol = 1f
                applyVolume()
            } else {
                sleepVol = 1f - fadeStep.toFloat() / steps
                applyVolume()
                handler.postDelayed(this, 300)
            }
        }
    }
    private val sleepRun = Runnable {
        fadeStep = 0
        handler.post(sleepFadeRun)
    }

    private fun setSleep(minutes: Int) {
        handler.removeCallbacks(sleepRun)
        handler.removeCallbacks(sleepFadeRun)
        fadeStep = 0
        sleepVol = 1f
        applyVolume()
        player.setPauseAtEndOfMediaItems(false)
        sleepAt = 0L
        sleepEnd = false
        if (minutes > 0) {
            val ms = minutes * 60_000L
            sleepAt = System.currentTimeMillis() + ms
            handler.postDelayed(sleepRun, ms)
        } else if (minutes == -1) {
            sleepEnd = true
            player.setPauseAtEndOfMediaItems(true)
        }
    }

    // ---------- contador de reproducciones ----------
    private var counted = false
    private val countRun = object : Runnable {
        override fun run() {
            val item = player.currentMediaItem
            val d = player.duration
            if (item != null && !counted && d != C.TIME_UNSET && d > 0 &&
                player.currentPosition >= minOf(30_000L, d / 2)
            ) {
                counted = true
                Stats.add(this@PlaybackService, item.mediaId)
            }
            if (player.isPlaying) handler.postDelayed(this, 3000)
        }
    }

    // ---------- widget ----------
    fun refreshWidget() {
        val item = player.currentMediaItem
        if (item == null) {
            NearWidget.update(this, null)
            return
        }
        val m = item.mediaMetadata
        NearWidget.update(
            this,
            WidgetNow(item.mediaId, m.title?.toString() ?: "", m.artist?.toString() ?: "", player.isPlaying)
        )
    }

    fun widgetAction(action: String) {
        when (action) {
            NearWidget.A_TOGGLE -> {
                if (player.isPlaying) {
                    player.pause()
                } else {
                    if (player.playbackState == Player.STATE_IDLE) player.prepare()
                    if (player.playbackState == Player.STATE_ENDED) player.seekToDefaultPosition()
                    player.play()
                }
            }
            NearWidget.A_NEXT -> player.seekToNext()
            NearWidget.A_PREV -> player.seekToPrevious()
        }
    }

    override fun onCreate() {
        super.onCreate()
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        // velocidad, tono y transición guardados
        val sp = getSharedPreferences("mm", Context.MODE_PRIVATE)
        val speed = sp.getFloat("speed", 1f).coerceIn(0.25f, 3f)
        val pitch = sp.getFloat("pitch", 1f).coerceIn(0.25f, 4f)
        player.setPlaybackParameters(PlaybackParameters(speed, pitch))
        fadeMs = sp.getLong("fadeMs", 0L).coerceIn(0L, 12_000L)

        // ecualizador
        AudioFx.attach(this, player.audioSessionId)

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, player)
            .setSessionActivity(open)
            .setCallback(Callback())
            .setCustomLayout(buttons())
            .build()

        player.addListener(object : Player.Listener {
            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                updateButtons()
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                updateButtons()
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                AudioFx.attach(this@PlaybackService, audioSessionId)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                counted = false
                fadeIn = reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO ||
                    reason == Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT
                applyVolume()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(countRun)
                handler.removeCallbacks(volRun)
                if (isPlaying) {
                    handler.postDelayed(countRun, 3000)
                    if (fadeMs > 0L) handler.post(volRun)
                }
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                // "al terminar esta canción": ya se pausó, así que se quita el temporizador
                if (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM && sleepEnd) {
                    sleepEnd = false
                    player.setPauseAtEndOfMediaItems(false)
                }
            }

            override fun onEvents(player: Player, events: Player.Events) {
                if (events.containsAny(
                        Player.EVENT_MEDIA_ITEM_TRANSITION,
                        Player.EVENT_IS_PLAYING_CHANGED,
                        Player.EVENT_MEDIA_METADATA_CHANGED
                    )
                ) refreshWidget()
            }
        })
        updateButtons()
        instance = this
        refreshWidget()
    }

    private fun buttons(): ImmutableList<CommandButton> {
        val shuffle = CommandButton.Builder()
            .setDisplayName(if (player.shuffleModeEnabled) "Aleatorio: sí" else "Aleatorio: no")
            .setIconResId(if (player.shuffleModeEnabled) R.drawable.ic_shuffle_on else R.drawable.ic_shuffle_off)
            .setSessionCommand(SessionCommand(CMD_SHUFFLE, Bundle.EMPTY))
            .build()
        val repeatIcon = when (player.repeatMode) {
            Player.REPEAT_MODE_ALL -> R.drawable.ic_repeat_all
            Player.REPEAT_MODE_ONE -> R.drawable.ic_repeat_one
            else -> R.drawable.ic_repeat_off
        }
        val repeatName = when (player.repeatMode) {
            Player.REPEAT_MODE_ALL -> "Repetir todo"
            Player.REPEAT_MODE_ONE -> "Repetir una"
            else -> "Repetir: no"
        }
        val repeat = CommandButton.Builder()
            .setDisplayName(repeatName)
            .setIconResId(repeatIcon)
            .setSessionCommand(SessionCommand(CMD_REPEAT, Bundle.EMPTY))
            .build()
        return ImmutableList.of(shuffle, repeat)
    }

    private fun updateButtons() {
        session?.setCustomLayout(buttons())
    }

    private inner class Callback : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SessionCommand(CMD_SHUFFLE, Bundle.EMPTY))
                .add(SessionCommand(CMD_REPEAT, Bundle.EMPTY))
                .add(SessionCommand(CMD_SLEEP, Bundle.EMPTY))
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(commands)
                .build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            when (customCommand.customAction) {
                CMD_SHUFFLE -> player.shuffleModeEnabled = !player.shuffleModeEnabled
                CMD_REPEAT -> player.repeatMode = when (player.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
                CMD_SLEEP -> setSleep(args.getInt("min", 0))
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        instance = null
        sleepAt = 0L
        sleepEnd = false
        AudioFx.release()
        NearWidget.update(this, null)
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
