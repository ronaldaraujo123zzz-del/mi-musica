package com.near.mimusica

import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

/**
 * Reproduce la música en segundo plano y muestra la notificación con aleatorio y bucle.
 * También aplica velocidad/tono, el ecualizador, el temporizador para dormir y cuenta las reproducciones.
 */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        const val CMD_SHUFFLE = "mm.SHUFFLE"
        const val CMD_REPEAT = "mm.REPEAT"
        const val CMD_SLEEP = "mm.SLEEP"

        /** Hora (en milisegundos) a la que se apagará la música; 0 = sin temporizador. */
        @Volatile
        var sleepAt = 0L

        /** true = se apagará al terminar la canción que suena. */
        @Volatile
        var sleepEnd = false
    }

    // ---------- temporizador para dormir (baja el volumen poco a poco y pausa) ----------
    private var fadeStep = 0
    private val fadeRun = object : Runnable {
        override fun run() {
            fadeStep++
            val steps = 20
            if (fadeStep >= steps) {
                fadeStep = 0
                sleepAt = 0L
                player.pause()
                player.volume = 1f
            } else {
                player.volume = 1f - fadeStep.toFloat() / steps
                handler.postDelayed(this, 300)
            }
        }
    }
    private val sleepRun = Runnable {
        fadeStep = 0
        handler.post(fadeRun)
    }

    private fun setSleep(minutes: Int) {
        handler.removeCallbacks(sleepRun)
        handler.removeCallbacks(fadeRun)
        fadeStep = 0
        player.volume = 1f
        player.setPauseAtEndOfMediaItems(false)
        sleepAt = 0L
        sleepEnd = false
        if (minutes > 0) {
            val ms = minutes * 60_000L
            sleepAt = System.currentTimeMillis() + ms
            handler.postDelayed(sleepRun, ms)
        } else if (minutes == -1) {
            sleepEnd = true
            player.setPauseAtEndOfMediaItems(true)
        }
    }

    // ---------- contador de reproducciones ----------
    private var counted = false
    private val countRun = object : Runnable {
        override fun run() {
            val item = player.currentMediaItem
            val d = player.duration
            if (item != null && !counted && d != C.TIME_UNSET && d > 0 &&
                player.currentPosition >= minOf(30_000L, d / 2)
            ) {
                counted = true
                Stats.add(this@PlaybackService, item.mediaId)
            }
            if (player.isPlaying) handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        // velocidad y tono guardados
        val sp = getSharedPreferences("mm", android.content.Context.MODE_PRIVATE)
        val speed = sp.getFloat("speed", 1f).coerceIn(0.25f, 3f)
        val pitch = sp.getFloat("pitch", 1f).coerceIn(0.25f, 4f)
        player.setPlaybackParameters(PlaybackParameters(speed, pitch))

        // ecualizador
        AudioFx.attach(this, player.audioSessionId)

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, player)
            .setSessionActivity(open)
            .setCallback(Callback())
            .setCustomLayout(buttons())
            .build()

        player.addListener(object : Player.Listener {
            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                updateButtons()
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                updateButtons()
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                AudioFx.attach(this@PlaybackService, audioSessionId)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                counted = false
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(countRun)
                if (isPlaying) handler.postDelayed(countRun, 3000)
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                // "al terminar esta canción": ya se pausó, así que se quita el temporizador
                if (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM && sleepEnd) {
                    sleepEnd = false
                    player.setPauseAtEndOfMediaItems(false)
                }
            }
        })
        updateButtons()
    }

    private fun buttons(): ImmutableList<CommandButton> {
        val shuffle = CommandButton.Builder()
            .setDisplayName(if (player.shuffleModeEnabled) "Aleatorio: sí" else "Aleatorio: no")
            .setIconResId(if (player.shuffleModeEnabled) R.drawable.ic_shuffle_on else R.drawable.ic_shuffle_off)
            .setSessionCommand(SessionCommand(CMD_SHUFFLE, Bundle.EMPTY))
            .build()
        val repeatIcon = when (player.repeatMode) {
            Player.REPEAT_MODE_ALL -> R.drawable.ic_repeat_all
            Player.REPEAT_MODE_ONE -> R.drawable.ic_repeat_one
            else -> R.drawable.ic_repeat_off
        }
        val repeatName = when (player.repeatMode) {
            Player.REPEAT_MODE_ALL -> "Repetir todo"
            Player.REPEAT_MODE_ONE -> "Repetir una"
            else -> "Repetir: no"
        }
        val repeat = CommandButton.Builder()
            .setDisplayName(repeatName)
            .setIconResId(repeatIcon)
            .setSessionCommand(SessionCommand(CMD_REPEAT, Bundle.EMPTY))
            .build()
        return ImmutableList.of(shuffle, repeat)
    }

    private fun updateButtons() {
        session?.setCustomLayout(buttons())
    }

    private inner class Callback : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SessionCommand(CMD_SHUFFLE, Bundle.EMPTY))
                .add(SessionCommand(CMD_REPEAT, Bundle.EMPTY))
                .add(SessionCommand(CMD_SLEEP, Bundle.EMPTY))
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(commands)
                .build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            when (customCommand.customAction) {
                CMD_SHUFFLE -> player.shuffleModeEnabled = !player.shuffleModeEnabled
                CMD_REPEAT -> player.repeatMode = when (player.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
                CMD_SLEEP -> setSleep(args.getInt("min", 0))
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        sleepAt = 0L
        sleepEnd = false
        AudioFx.release()
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
