package com.near.mimusica

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream

/**
 * Prepara la imagen del mensaje para todos: pequeña, para que viaje rápido por internet.
 * Los GIF pequeños se quedan tal cual (así se siguen moviendo).
 */
object MsgImg {
    private const val GIF_MAX = 350_000
    private const val JPG_MAX = 90_000

    fun encode(ctx: Context, uri: Uri): String? {
        val mime = ctx.contentResolver.getType(uri) ?: ""
        if (mime == "image/gif") {
            val raw = ctx.contentResolver.openInputStream(uri)?.use { inp ->
                val b = inp.readBytes()
                if (b.size <= GIF_MAX) b else null
            }
            if (raw != null) return "data:image/gif;base64," + Base64.encodeToString(raw, Base64.NO_WRAP)
        }
        var bmp: Bitmap = Bg.decode(ctx, uri, 720) ?: return null
        var q = 80
        var bytes = jpg(bmp, q)
        while (bytes.size > JPG_MAX && q > 45) {
            q -= 10
            bytes = jpg(bmp, q)
        }
        while (bytes.size > JPG_MAX && bmp.width > 200) {
            bmp = Bitmap.createScaledBitmap(bmp, bmp.width * 3 / 4, bmp.height * 3 / 4, true)
            bytes = jpg(bmp, q)
        }
        return "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun jpg(b: Bitmap, q: Int): ByteArray {
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, q, out)
        return out.toByteArray()
    }
}
