package com.near.mimusica

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLUtils
import android.view.Surface
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Video pixel art de un pedazo de la canción: la carátula convertida en una escena de
 * videojuego, el avatar de NEAR caminando al ritmo y la letra como diálogo de juego.
 * Se dibuja en 180x320 "píxeles de juego" y se agranda x4 (720x1280) sin suavizar,
 * así los píxeles quedan nítidos y el archivo pesa poco.
 */
object PixelVideo {
    @Volatile
    var busy = false

    private const val GW = 180
    private const val GH = 320
    private const val SCALE = 4
    private const val FPS = 30
    private const val VIDEO_BITRATE = 2_500_000

    fun outFile(ctx: Context): File {
        val dir = File(ctx.cacheDir, "video")
        dir.mkdirs()
        return File(dir, "near-pixel-art.mp4")
    }

    private class Job(
        val id: Long,
        val title: String,
        val artist: String,
        val startMs: Long,
        val durMs: Long,
        val songMs: Long,
        val bpm: Double,
        val lines: List<Pair<Long, String>>
    )

    private class Enc(val data: ByteArray, val pts: Long, val flags: Int)

    /** Crea el video y devuelve el archivo. progress va de 0 a 1. */
    fun make(ctx: Context, json: String, progress: (Float) -> Unit): File {
        busy = true
        try {
            val o = JSONObject(json)
            val arr = o.optJSONArray("lines")
            val lines = ArrayList<Pair<Long, String>>()
            if (arr != null) for (i in 0 until arr.length()) {
                val x = arr.optJSONArray(i) ?: continue
                lines.add(x.optLong(0) to x.optString(1))
            }
            lines.sortBy { it.first }
            val job = Job(
                o.getString("id").toLong(),
                o.optString("title"),
                o.optString("artist"),
                o.optLong("start").coerceAtLeast(0L),
                o.optLong("dur", 15_000L).coerceIn(3_000L, 60_000L),
                o.optLong("song", 0L),
                o.optDouble("bpm", 0.0).let { if (it in 50.0..220.0) it else 100.0 },
                lines
            )
            val out = outFile(ctx)
            out.delete()
            progress(0.02f)
            val audio = try {
                audio(ctx, job.id, job.startMs, job.durMs)
            } catch (e: Throwable) {
                null // sin sonido antes que sin video
            }
            progress(0.12f)
            val art = try { ArtLoader.bitmap(ctx, job.id, 256) } catch (e: Throwable) { null }
            val scene = Scene(job, art)
            video(out, job, scene, audio) { p -> progress(0.12f + p * 0.88f) }
            return out
        } finally {
            busy = false
        }
    }

    // =====================================================================
    // audio: el pedazo de la canción, a AAC
    // =====================================================================
    private fun audio(ctx: Context, id: Long, startMs: Long, durMs: Long): Pair<MediaFormat, List<Enc>>? {
        val ex = MediaExtractor()
        var dec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, Library.uri(id), null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                if ((ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; break }
            }
            if (track < 0) return null
            ex.selectTrack(track)
            val inFmt = ex.getTrackFormat(track)
            val d = MediaCodec.createDecoderByType(inFmt.getString(MediaFormat.KEY_MIME)!!)
            dec = d
            d.configure(inFmt, null, null, 0)
            d.start()
            val startUs = startMs * 1000
            val endUs = (startMs + durMs) * 1000
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            var sr = inFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = inFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var isFloat = false
            val pcm = ShortArrayBuilder()
            var outCh = 0
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var done = false
            var guard = 0
            while (!done && guard < 200_000) {
                guard++
                if (!inDone) {
                    val ii = d.dequeueInputBuffer(5_000)
                    if (ii >= 0) {
                        val buf = d.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0 || ex.sampleTime > endUs + 500_000) {
                            d.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            d.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = d.dequeueOutputBuffer(info, 5_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = d.outputFormat
                    sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    isFloat = f.containsKey(MediaFormat.KEY_PCM_ENCODING) && f.getInteger(MediaFormat.KEY_PCM_ENCODING) == 4
                } else if (oi >= 0) {
                    if (outCh == 0) outCh = min(2, max(1, ch))
                    if (info.size > 0) {
                        val buf = d.getOutputBuffer(oi)!!
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        val bb = buf.slice().order(ByteOrder.nativeOrder())
                        val bps = if (isFloat) 4 else 2
                        val frames = info.size / (bps * ch)
                        val t0 = info.presentationTimeUs
                        for (fi in 0 until frames) {
                            val t = t0 + fi * 1_000_000L / sr
                            if (t < startUs) continue
                            if (t >= endUs) { done = true; break }
                            for (c in 0 until outCh) {
                                val idx = (fi * ch + c) * bps
                                val v = if (isFloat) (bb.getFloat(idx) * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                                else bb.getShort(idx)
                                pcm.add(v)
                            }
                        }
                    }
                    d.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) done = true
                }
            }
            if (outCh == 0 || pcm.size == 0) return null
            var samples = pcm.toArray()
            // AAC llega hasta 48 kHz: si es más, se toma uno de cada dos
            while (sr > 48_000) {
                val n = samples.size / outCh / 2
                val half = ShortArray(n * outCh)
                for (i in 0 until n) for (c in 0 until outCh) half[i * outCh + c] = samples[(i * 2) * outCh + c]
                samples = half
                sr /= 2
            }
            fade(samples, outCh, sr)
            return aac(samples, sr, outCh)
        } finally {
            try { dec?.stop() } catch (e: Exception) {}
            try { dec?.release() } catch (e: Exception) {}
            ex.release()
        }
    }

    /** Entrada suave y salida suave, para que no empiece ni termine de golpe. */
    private fun fade(s: ShortArray, ch: Int, sr: Int) {
        val frames = s.size / ch
        val fin = min(frames / 4, sr * 15 / 100)
        val fout = min(frames / 3, sr * 6 / 10)
        for (i in 0 until fin) {
            val k = i.toFloat() / fin
            for (c in 0 until ch) s[i * ch + c] = (s[i * ch + c] * k).toInt().toShort()
        }
        for (i in 0 until fout) {
            val f = frames - 1 - i
            val k = i.toFloat() / fout
            for (c in 0 until ch) s[f * ch + c] = (s[f * ch + c] * k).toInt().toShort()
        }
    }

    private fun aac(pcm: ShortArray, sr: Int, ch: Int): Pair<MediaFormat, List<Enc>> {
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sr, ch)
        fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, if (ch == 1) 96_000 else 128_000)
        fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384)
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        val out = ArrayList<Enc>()
        var outFmt: MediaFormat? = null
        try {
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            val info = MediaCodec.BufferInfo()
            var pos = 0 // en muestras (short)
            var inDone = false
            var guard = 0
            while (guard < 500_000) {
                guard++
                if (!inDone) {
                    val ii = enc.dequeueInputBuffer(5_000)
                    if (ii >= 0) {
                        val buf = enc.getInputBuffer(ii)!!
                        buf.clear()
                        val room = buf.capacity() / 2
                        val n = min(room - room % ch, min(1024 * ch, pcm.size - pos))
                        val pts = (pos / ch).toLong() * 1_000_000L / sr
                        if (n <= 0) {
                            enc.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            val sb = buf.order(ByteOrder.nativeOrder()).asShortBuffer()
                            sb.put(pcm, pos, n)
                            enc.queueInputBuffer(ii, 0, n * 2, pts, 0)
                            pos += n
                        }
                    }
                }
                val oi = enc.dequeueOutputBuffer(info, 5_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    outFmt = enc.outputFormat
                } else if (oi >= 0) {
                    if (info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        val buf = enc.getOutputBuffer(oi)!!
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        val b = ByteArray(info.size)
                        buf.get(b)
                        out.add(Enc(b, info.presentationTimeUs, info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME))
                    }
                    enc.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                }
            }
        } finally {
            try { enc.stop() } catch (e: Exception) {}
            enc.release()
        }
        return (outFmt ?: throw IllegalStateException("sin formato de audio")) to out
    }

    private class ShortArrayBuilder {
        private var a = ShortArray(1 shl 16)
        var size = 0
        fun add(v: Short) {
            if (size == a.size) a = a.copyOf(a.size * 2)
            a[size++] = v
        }
        fun toArray(): ShortArray = a.copyOf(size)
    }

    // =====================================================================
    // video: H.264 por superficie (EGL), con tiempos exactos por cuadro
    // =====================================================================
    private fun video(out: File, job: Job, scene: Scene, audio: Pair<MediaFormat, List<Enc>>?, progress: (Float) -> Unit) {
        val W = GW * SCALE
        val H = GH * SCALE
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, W, H)
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, VIDEO_BITRATE)
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        var mux: MediaMuxer? = null
        var surface: Surface? = null
        var egl: Egl? = null
        var muxOn = false
        var vTrack = -1
        val info = MediaCodec.BufferInfo()
        try {
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = enc.createInputSurface()
            enc.start()
            val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux = m
            val e = Egl(surface, W, H)
            egl = e

            fun drain(end: Boolean) {
                var tries = 0
                while (true) {
                    val oi = enc.dequeueOutputBuffer(info, if (end) 10_000 else 0)
                    if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!end || ++tries > 500) return
                    } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (!muxOn) {
                            vTrack = m.addTrack(enc.outputFormat)
                            val aTrack = if (audio != null) m.addTrack(audio.first) else -1
                            m.start()
                            muxOn = true
                            if (audio != null) {
                                val ai = MediaCodec.BufferInfo()
                                for (s in audio.second) {
                                    ai.set(0, s.data.size, s.pts, s.flags)
                                    m.writeSampleData(aTrack, ByteBuffer.wrap(s.data), ai)
                                }
                            }
                        }
                    } else if (oi >= 0) {
                        val buf = enc.getOutputBuffer(oi)!!
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                        if (info.size > 0 && muxOn) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            m.writeSampleData(vTrack, buf, info)
                        }
                        enc.releaseOutputBuffer(oi, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                }
            }

            val frames = (job.durMs * FPS / 1000).toInt()
            var lastP = -1
            for (n in 0 until frames) {
                val t = n * 1000L / FPS
                scene.draw(t)
                e.frame(scene.bmp, n.toLong() * 1_000_000_000L / FPS)
                drain(false)
                val p = (n + 1) * 100 / frames
                if (p != lastP) { lastP = p; progress(p / 100f) }
            }
            enc.signalEndOfInputStream()
            drain(true)
            if (!muxOn) throw IllegalStateException("El teléfono no pudo crear el video")
            m.stop()
        } finally {
            try { egl?.release() } catch (e: Exception) {}
            try { surface?.release() } catch (e: Exception) {}
            try { enc.stop() } catch (e: Exception) {}
            try { enc.release() } catch (e: Exception) {}
            try { mux?.release() } catch (e: Exception) {}
        }
    }

    /** EGL + un cuadrado con la imagen chiquita agrandada sin suavizar. */
    private class Egl(surface: Surface, private val w: Int, private val h: Int) {
        private val dpy: EGLDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        private val ctx: EGLContext
        private val surf: EGLSurface
        private val prog: Int
        private val tex: Int
        private var texReady = false
        private val quad: FloatBuffer

        init {
            val v = IntArray(2)
            check(EGL14.eglInitialize(dpy, v, 0, v, 1)) { "EGL" }
            val attrs = intArrayOf(
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                0x3142, 1, // EGL_RECORDABLE_ANDROID
                EGL14.EGL_NONE
            )
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val num = IntArray(1)
            check(EGL14.eglChooseConfig(dpy, attrs, 0, cfgs, 0, 1, num, 0) && num[0] > 0) { "EGL config" }
            ctx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
            surf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], surface, intArrayOf(EGL14.EGL_NONE), 0)
            check(EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) { "EGL current" }

            prog = program(
                "attribute vec4 aPos; attribute vec2 aUV; varying vec2 vUV; void main(){ gl_Position = aPos; vUV = aUV; }",
                "precision mediump float; varying vec2 vUV; uniform sampler2D uTex; void main(){ gl_FragColor = texture2D(uTex, vUV); }"
            )
            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            tex = t[0]
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            // x, y, u, v
            val q = floatArrayOf(-1f, -1f, 0f, 1f, 1f, -1f, 1f, 1f, -1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f)
            quad = ByteBuffer.allocateDirect(q.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(q)
        }

        private fun shader(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            return s
        }

        private fun program(vs: String, fs: String): Int {
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, vs))
            GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, fs))
            GLES20.glLinkProgram(p)
            return p
        }

        fun frame(bmp: Bitmap, ptsNs: Long) {
            GLES20.glViewport(0, 0, w, h)
            GLES20.glUseProgram(prog)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
            if (!texReady) {
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
                texReady = true
            } else {
                GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bmp)
            }
            GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uTex"), 0)
            val aPos = GLES20.glGetAttribLocation(prog, "aPos")
            val aUV = GLES20.glGetAttribLocation(prog, "aUV")
            quad.position(0)
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad)
            GLES20.glEnableVertexAttribArray(aPos)
            quad.position(2)
            GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 16, quad)
            GLES20.glEnableVertexAttribArray(aUV)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            EGLExt.eglPresentationTimeANDROID(dpy, surf, ptsNs)
            EGL14.eglSwapBuffers(dpy, surf)
        }

        fun release() {
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(dpy, surf)
            EGL14.eglDestroyContext(dpy, ctx)
            EGL14.eglReleaseThread()
            EGL14.eglTerminate(dpy)
        }
    }

    // =====================================================================
    // la escena
    // =====================================================================
    private class Scene(private val job: Job, art: Bitmap?) {
        val bmp: Bitmap = Bitmap.createBitmap(GW, GH, Bitmap.Config.ARGB_8888)
        private val c = Canvas(bmp)
        private val p = Paint().apply { isAntiAlias = false; isFilterBitmap = false }
        private val font = PixFont()
        private val rnd = Random(job.id)

        private val hue: Float
        private val sat: Float
        private val cover: Bitmap
        private val stars: List<IntArray>
        private val far = IntArray(GW * 2)
        private val near = IntArray(GW * 2)

        private val skyTop: Int
        private val skyBot: Int
        private val farCol: Int
        private val nearCol: Int
        private val ground: Int
        private val groundDark: Int
        private val grass: Int
        private val boxCol: Int

        init {
            // carátula pixelada (48x48) con pocos colores
            val src = art ?: run {
                val b = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888)
                val h0 = (abs(job.title.hashCode()) % 360).toFloat()
                for (y in 0 until 48) for (x in 0 until 48) {
                    b.setPixel(x, y, Color.HSVToColor(floatArrayOf((h0 + (x + y) * 1.2f) % 360f, 0.6f, 0.35f + 0.5f * (1f - y / 48f))))
                }
                b
            }
            val small = Bitmap.createScaledBitmap(src, 48, 48, true).copy(Bitmap.Config.ARGB_8888, true)
            var r = 0L; var g = 0L; var bl = 0L
            for (y in 0 until 48) for (x in 0 until 48) {
                val px = small.getPixel(x, y)
                r += Color.red(px); g += Color.green(px); bl += Color.blue(px)
                val q = { v: Int -> ((v + 25) / 51 * 51).coerceIn(0, 255) }
                small.setPixel(x, y, Color.rgb(q(Color.red(px)), q(Color.green(px)), q(Color.blue(px))))
            }
            cover = small
            val hsv = FloatArray(3)
            Color.colorToHSV(Color.rgb((r / 2304).toInt(), (g / 2304).toInt(), (bl / 2304).toInt()), hsv)
            hue = hsv[0]
            sat = hsv[1].coerceIn(0.35f, 0.75f)

            skyTop = hsv(hue + 10f, sat, 0.16f)
            skyBot = hsv(hue - 15f, sat * 0.9f, 0.52f)
            farCol = hsv(hue + 25f, sat * 0.7f, 0.28f)
            nearCol = hsv(hue - 20f, sat * 0.8f, 0.2f)
            ground = hsv(hue + 150f, 0.45f, 0.42f)
            groundDark = hsv(hue + 150f, 0.5f, 0.3f)
            grass = hsv(hue + 140f, 0.55f, 0.62f)
            boxCol = hsv(hue, sat * 0.6f, 0.1f)

            stars = List(46) { intArrayOf(rnd.nextInt(GW), rnd.nextInt(150), rnd.nextInt(1000), rnd.nextInt(3)) }
            fun hills(a: IntArray, base: Int, amp: Int, freq: Double) {
                val ph = rnd.nextDouble() * 10
                for (i in a.indices) {
                    val x = i.toDouble() / a.size * 2 * PI
                    a[i] = base + (amp * (0.55 * sin(x * freq + ph) + 0.3 * sin(x * freq * 2.7 + ph * 2) + 0.15 * sin(x * freq * 6.1))).toInt()
                }
            }
            hills(far, 44, 22, 3.0)
            hills(near, 22, 12, 5.0)
        }

        private fun hsv(h: Float, s: Float, v: Float): Int =
            Color.HSVToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))

        private fun rect(x: Int, y: Int, w: Int, h: Int, col: Int) {
            p.color = col
            c.drawRect(x.toFloat(), y.toFloat(), (x + w).toFloat(), (y + h).toFloat(), p)
        }

        private fun beat(t: Long): Double = t / 60_000.0 * job.bpm

        /** Línea de la letra que suena en el momento t (ms del video). */
        private fun lineAt(songT: Long): Int {
            var i = -1
            for (k in job.lines.indices) if (job.lines[k].first <= songT + 60) i = k else break
            return i
        }

        fun draw(t: Long) {
            val songT = job.startMs + t
            val b = beat(t)
            val bf = b - floor(b)
            val bounce = if (bf < 0.18) 2 else if (bf < 0.32) 1 else 0

            // cielo en franjas (como en los juegos viejos)
            val bands = 14
            for (i in 0 until bands) {
                val k = i / (bands - 1f)
                rect(0, i * 20, GW, 20, blend(skyTop, skyBot, k))
            }
            // estrellas que titilan
            for (s in stars) {
                val on = ((t + s[2]) / 400) % 4 != 0L
                if (!on) continue
                val col = if (s[3] == 0) 0xFFFFE9A8.toInt() else 0xFFFFFFFF.toInt()
                rect(s[0], s[1], 1, 1, col)
                if (s[3] == 2 && ((t + s[2]) / 400) % 4 == 1L) {
                    rect(s[0] - 1, s[1], 3, 1, col); rect(s[0], s[1] - 1, 1, 3, col)
                }
            }
            // montañas lejos y cerros cerca (se mueven a distinta velocidad)
            val groundY = 268
            val o1 = (t * 6 / 1000).toInt()
            val o2 = (t * 16 / 1000).toInt()
            for (x in 0 until GW) {
                val h1 = far[(x + o1) % far.size]
                rect(x, groundY - h1, 1, h1, farCol)
                val h2 = near[(x + o2) % near.size]
                rect(x, groundY - h2, 1, h2, nearCol)
            }
            // suelo de bloques
            val o3 = (t * 34 / 1000).toInt()
            rect(0, groundY, GW, 14, ground)
            rect(0, groundY, GW, 2, grass)
            for (x in -16 until GW + 16 step 8) {
                val xx = x - o3 % 16
                rect(xx, groundY + 2, 1, 12, groundDark)
                rect(xx + 4, groundY + 8, 1, 6, groundDark)
            }
            rect(0, groundY + 8, GW, 1, groundDark)
            // tierra de abajo
            rect(0, groundY + 14, GW, GH - groundY - 14, blend(groundDark, 0xFF000000.toInt(), 0.45f))
            for (x in 0 until GW + 16 step 12) {
                val xx = x - o3 % 12
                rect(xx + 3, groundY + 20 + (x / 12 % 3) * 6, 2, 1, groundDark)
            }

            // monedas que llegan con el ritmo
            var score = (t / 100).toInt() * 10
            val coinSpeed = 46.0 // px por segundo
            val firstBeat = 1
            val lastBeat = b.toInt() + 6
            for (k in firstBeat..lastBeat) {
                val spawnT = k * 60_000.0 / job.bpm
                val x = (GW + 4 - (t - spawnT) / 1000.0 * coinSpeed).toInt()
                val catchX = 34
                if (x <= catchX) {
                    score += 100
                    val since = t - (spawnT + (GW + 4 - catchX) / coinSpeed * 1000)
                    if (since in 0.0..600.0) {
                        font.draw(c, "+100", 38, (groundY - 24 - since / 60).toInt(), 0xFFFFD21F.toInt(), 1, 0xFF000000.toInt())
                    }
                    continue
                }
                if (x > GW + 4) continue
                val y = groundY - 22 + (if (k % 3 == 0) -10 else 0)
                val spin = ((t / 120) + k) % 4
                when (spin) {
                    0L, 2L -> { rect(x + 1, y, 4, 6, 0xFF000000.toInt()); rect(x, y + 1, 6, 4, 0xFF000000.toInt()); rect(x + 1, y + 1, 4, 4, 0xFFFFD21F.toInt()); rect(x + 2, y + 2, 1, 2, 0xFFFFF4B0.toInt()) }
                    1L -> { rect(x + 2, y, 2, 6, 0xFF000000.toInt()); rect(x + 2, y + 1, 2, 4, 0xFFFFD21F.toInt()) }
                    else -> { rect(x + 1, y, 4, 6, 0xFF000000.toInt()); rect(x + 2, y + 1, 2, 4, 0xFFE0A800.toInt()) }
                }
            }

            // avatar de NEAR caminando
            val step = (b * 2).toInt() % 2
            drawAvatar(14, groundY - 32 - (if (step == 0) 0 else 1), step)

            // carátula flotando con marco de juego
            val cs = 96
            val cx = (GW - cs) / 2
            val cy = 60 - bounce + (sin(t / 900.0) * 2).toInt()
            rect(cx + 4, cy + 4, cs + 4, cs + 4, 0x66000000)
            rect(cx - 3, cy - 3, cs + 6, cs + 6, 0xFF000000.toInt())
            rect(cx - 2, cy - 2, cs + 4, cs + 4, 0xFFFFFFFF.toInt())
            rect(cx - 1, cy - 1, cs + 2, cs + 2, 0xFF000000.toInt())
            c.drawBitmap(cover, null, android.graphics.Rect(cx, cy, cx + cs, cy + cs), p)
            // brillitos alrededor
            for (k in 0 until 4) {
                val ph = ((t / 150) + k * 3) % 8
                if (ph > 3) continue
                val sx = intArrayOf(cx - 9, cx + cs + 5, cx + cs + 3, cx - 7)[k]
                val sy = intArrayOf(cy + 8, cy + 18, cy + cs - 14, cy + cs - 4)[k]
                val col = 0xFFFFFFFF.toInt()
                rect(sx, sy, 1, 1, col)
                if (ph in 1..2) { rect(sx - 2, sy, 5, 1, col); rect(sx, sy - 2, 1, 5, col) }
            }

            // HUD de arriba
            rect(0, 0, GW, 26, 0xB3000000.toInt())
            font.draw(c, "1UP", 5, 4, 0xFFFFD21F.toInt(), 1, 0)
            font.draw(c, "SCORE " + score.toString().padStart(6, '0'), 72, 4, 0xFFFFFFFF.toInt(), 1, 0)
            for (k in 0 until 3) heart(5 + k * 9, 15)
            font.draw(c, time(songT), GW - 5 - font.width(time(songT)), 15, 0xFFFFFFFF.toInt(), 1, 0)
            // nombre del nivel (se desliza si es largo)
            val lvl = "NIVEL: " + font.up(job.title)
            val lw = font.width(lvl)
            rect(0, 28, GW, 13, 0x8C000000.toInt())
            if (lw <= GW - 10) {
                font.draw(c, lvl, (GW - lw) / 2, 30, 0xFFFFFFFF.toInt(), 1, 0)
            } else {
                val span = lw + 40
                val off = ((t / 1000.0 * 28).toInt() % span)
                font.draw(c, lvl, GW - off, 30, 0xFFFFFFFF.toInt(), 1, 0)
                font.draw(c, lvl, GW - off + span, 30, 0xFFFFFFFF.toInt(), 1, 0)
            }

            // barra XP = avance de la canción
            val by = 46
            rect(0, by - 4, GW, 15, 0x8C000000.toInt())
            font.draw(c, "XP", 6, by - 1, 0xFFFFD21F.toInt(), 1, 0xFF000000.toInt())
            rect(20, by, GW - 26, 7, 0xFF000000.toInt())
            rect(21, by + 1, GW - 28, 5, 0xFF2A2A44.toInt())
            val prog = if (job.songMs > 0) (songT.toDouble() / job.songMs).coerceIn(0.0, 1.0) else t.toDouble() / job.durMs
            rect(21, by + 1, ((GW - 28) * prog).toInt(), 5, 0xFF46E07A.toInt())
            rect(21, by + 1, ((GW - 28) * prog).toInt(), 1, 0xFFA8FFC4.toInt())

            dialog(songT)

            // marca
            val mark = "NEAR MUSIC"
            font.draw(c, mark, (GW - font.width(mark)) / 2, 310, 0x99FFFFFF.toInt(), 1, 0)

            // READY? / GO!
            if (t < 1400) {
                val txt = if (t < 900) "READY?" else "GO!"
                if (t >= 900 || (t / 150) % 2 == 0L) {
                    val w = font.width(txt) * 2
                    font.draw(c, txt, (GW - w) / 2, cy + cs / 2 - 9, 0xFFFFD21F.toInt(), 2, 0xFF000000.toInt())
                }
            }
        }

        private fun time(ms: Long): String {
            val s = (ms / 1000).toInt()
            return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
        }

        private fun heart(x: Int, y: Int) {
            val rows = arrayOf(".##.##.", "#######", "#######", ".#####.", "..###..", "...#...")
            for ((j, r) in rows.withIndex()) for ((i, ch) in r.withIndex()) if (ch == '#') rect(x + i, y + j, 1, 1, 0xFFFF4D6D.toInt())
            rect(x + 1, y + 1, 1, 1, 0xFFFFC2CC.toInt())
        }

        private fun blend(a: Int, b: Int, k: Float): Int = Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        )

        /** Caja de diálogo con la letra escribiéndose letra por letra. */
        private fun dialog(songT: Long) {
            val x = 10
            val y = 174
            val w = GW - 20
            val h = 58
            // etiqueta con el nombre del artista
            val tag = font.up(job.artist).let { if (it.length > 22) it.take(21) + "…" else it }.ifEmpty { "NEAR" }
            val tw = font.width(tag) + 10
            rect(x + 6, y - 14, tw, 15, 0xFF000000.toInt())
            rect(x + 7, y - 13, tw - 2, 13, 0xFFFFD21F.toInt())
            font.draw(c, tag, x + 11, y - 9, 0xFF140E36.toInt(), 1, 0)
            // caja
            rect(x, y, w, h, 0xFF000000.toInt())
            rect(x + 1, y + 1, w - 2, h - 2, 0xFFFFFFFF.toInt())
            rect(x + 3, y + 3, w - 6, h - 6, 0xFF000000.toInt())
            rect(x + 4, y + 4, w - 8, h - 8, boxCol)

            val i = lineAt(songT)
            val text = if (i >= 0) job.lines[i].second.trim() else ""
            val tx = x + 9
            val ty = y + 8
            val maxW = w - 18
            if (text.isEmpty()) {
                val n = ((songT / 350) % 4).toInt()
                val notes = "♪ ".repeat(n + 1).trim()
                font.draw(c, notes, tx, ty + 18, 0xFFFFFFFF.toInt(), 1, 0)
                return
            }
            val start = job.lines[i].first
            val shown = (((songT - start).coerceAtLeast(0L)) * 34 / 1000).toInt() // letras por segundo
            val rows = font.wrap(font.up(text), maxW).take(4)
            var left = shown
            var done = true
            for ((r, row) in rows.withIndex()) {
                if (left <= 0) { done = false; break }
                val part = if (left >= row.length) row else row.take(left).also { done = false }
                font.draw(c, part, tx, ty + r * 11, 0xFFFFFFFF.toInt(), 1, 0)
                left -= row.length + 1
            }
            if (done && (songT / 300) % 2 == 0L) {
                val ax = x + w - 14
                val ay = y + h - 11
                rect(ax, ay, 5, 1, 0xFFFFD21F.toInt()); rect(ax + 1, ay + 1, 3, 1, 0xFFFFD21F.toInt()); rect(ax + 2, ay + 2, 1, 1, 0xFFFFD21F.toInt())
            }
        }

        /** Avatar de NEAR: gorra morada con la N amarilla. 12x16, dibujado al doble. */
        private fun drawAvatar(x: Int, y: Int, step: Int) {
            val body = arrayOf(
                "...KKKKKK...",
                "..KPPPPPPK..",
                ".KPYPPYPPPK.",
                ".KPYYPYPPPK.",
                ".KPYPYYPPPK.",
                ".KPYPPYPPPK.",
                "KYYYYYYYYYYK",
                ".KSSSSSSSK..",
                ".KSWKSSWKSK.",
                ".KSSSSSSSSK.",
                "..KSSKKSSK..",
                "..KKBBBBKK..",
                ".KBBBYYBBBK.",
                ".KSBBBBBBSK."
            )
            val legs = if (step == 0) arrayOf("..KDDKKDDK..", "..KKK..KKK..")
            else arrayOf(".KDDK..KDDK.", ".KKK....KKK.")
            val pal = mapOf(
                'K' to 0xFF140E36.toInt(), 'P' to 0xFF5B2BB5.toInt(), 'Y' to 0xFFFFD21F.toInt(),
                'S' to 0xFFE8B48A.toInt(), 'W' to 0xFFFFFFFF.toInt(), 'B' to 0xFF2A1F78.toInt(), 'D' to 0xFF3A3A5A.toInt()
            )
            val rows = body + legs
            // sombra
            rect(x + 4, y + 32, 16, 2, 0x55000000)
            for ((j, r) in rows.withIndex()) for ((i, ch) in r.withIndex()) {
                val col = pal[ch] ?: continue
                rect(x + i * 2, y + j * 2, 2, 2, col)
            }
        }
    }

    // =====================================================================
    // letra de juego 5x7 (mayúsculas, números, tildes y signos)
    // =====================================================================
    private class PixFont {
        private val g = HashMap<Char, Array<String>>()
        private val fallback = Paint().apply { isAntiAlias = false; textSize = 9f; color = Color.WHITE }
        private val measure = Paint().apply { isAntiAlias = false; textSize = 9f }

        init {
            fun d(ch: Char, s: String) { g[ch] = s.split(',').toTypedArray() }
            d('A', "01110,10001,10001,11111,10001,10001,10001"); d('B', "11110,10001,10001,11110,10001,10001,11110")
            d('C', "01110,10001,10000,10000,10000,10001,01110"); d('D', "11110,10001,10001,10001,10001,10001,11110")
            d('E', "11111,10000,10000,11110,10000,10000,11111"); d('F', "11111,10000,10000,11110,10000,10000,10000")
            d('G', "01110,10001,10000,10111,10001,10001,01111"); d('H', "10001,10001,10001,11111,10001,10001,10001")
            d('I', "01110,00100,00100,00100,00100,00100,01110"); d('J', "00111,00010,00010,00010,00010,10010,01100")
            d('K', "10001,10010,10100,11000,10100,10010,10001"); d('L', "10000,10000,10000,10000,10000,10000,11111")
            d('M', "10001,11011,10101,10101,10001,10001,10001"); d('N', "10001,11001,10101,10011,10001,10001,10001")
            d('O', "01110,10001,10001,10001,10001,10001,01110"); d('P', "11110,10001,10001,11110,10000,10000,10000")
            d('Q', "01110,10001,10001,10001,10101,10010,01101"); d('R', "11110,10001,10001,11110,10100,10010,10001")
            d('S', "01111,10000,10000,01110,00001,00001,11110"); d('T', "11111,00100,00100,00100,00100,00100,00100")
            d('U', "10001,10001,10001,10001,10001,10001,01110"); d('V', "10001,10001,10001,10001,10001,01010,00100")
            d('W', "10001,10001,10001,10101,10101,10101,01010"); d('X', "10001,10001,01010,00100,01010,10001,10001")
            d('Y', "10001,10001,01010,00100,00100,00100,00100"); d('Z', "11111,00001,00010,00100,01000,10000,11111")
            d('0', "01110,10001,10011,10101,11001,10001,01110"); d('1', "00100,01100,00100,00100,00100,00100,01110")
            d('2', "01110,10001,00001,00010,00100,01000,11111"); d('3', "11111,00010,00100,00010,00001,10001,01110")
            d('4', "00010,00110,01010,10010,11111,00010,00010"); d('5', "11111,10000,11110,00001,00001,10001,01110")
            d('6', "00110,01000,10000,11110,10001,10001,01110"); d('7', "11111,00001,00010,00100,01000,01000,01000")
            d('8', "01110,10001,10001,01110,10001,10001,01110"); d('9', "01110,10001,10001,01111,00001,00010,01100")
            d('.', "00000,00000,00000,00000,00000,01100,01100"); d(',', "00000,00000,00000,00000,01100,00100,01000")
            d('!', "00100,00100,00100,00100,00100,00000,00100"); d('¡', "00100,00000,00100,00100,00100,00100,00100")
            d('?', "01110,10001,00001,00010,00100,00000,00100"); d('¿', "00100,00000,00100,01000,10000,10001,01110")
            d('\'', "00100,00100,01000,00000,00000,00000,00000"); d('’', "00100,00100,01000,00000,00000,00000,00000")
            d('"', "01010,01010,00000,00000,00000,00000,00000"); d('-', "00000,00000,00000,11111,00000,00000,00000")
            d(':', "00000,01100,01100,00000,01100,01100,00000"); d(';', "00000,01100,01100,00000,01100,00100,01000")
            d('(', "00010,00100,01000,01000,01000,00100,00010"); d(')', "01000,00100,00010,00010,00010,00100,01000")
            d('/', "00001,00001,00010,00100,01000,10000,10000"); d('&', "01100,10010,10100,01000,10101,10010,01101")
            d('+', "00000,00100,00100,11111,00100,00100,00000"); d('#', "01010,01010,11111,01010,11111,01010,01010")
            d('*', "00000,00100,10101,01110,10101,00100,00000"); d('♪', "00110,00101,00100,00100,01100,11100,11000")
            d('♥', "00000,01010,11111,11111,01110,00100,00000"); d('…', "00000,00000,00000,00000,00000,00000,10101")
            d('_', "00000,00000,00000,00000,00000,00000,11111"); d('=', "00000,00000,11111,00000,11111,00000,00000")
        }

        // marcas encima: tildes, diéresis, eñe
        private val marks = mapOf(
            'Á' to ('A' to 0), 'É' to ('E' to 0), 'Í' to ('I' to 0), 'Ó' to ('O' to 0), 'Ú' to ('U' to 0),
            'À' to ('A' to 1), 'È' to ('E' to 1), 'Ì' to ('I' to 1), 'Ò' to ('O' to 1), 'Ù' to ('U' to 1),
            'Ä' to ('A' to 2), 'Ë' to ('E' to 2), 'Ï' to ('I' to 2), 'Ö' to ('O' to 2), 'Ü' to ('U' to 2),
            'Â' to ('A' to 3), 'Ê' to ('E' to 3), 'Î' to ('I' to 3), 'Ô' to ('O' to 3), 'Û' to ('U' to 3),
            'Ñ' to ('N' to 4), 'Ã' to ('A' to 4), 'Õ' to ('O' to 4)
        )
        private val markRows = arrayOf(
            arrayOf("00010", "00100"), arrayOf("01000", "00100"), arrayOf("00000", "01010"),
            arrayOf("00100", "01010"), arrayOf("01101", "10010")
        )

        fun up(s: String): String = s.uppercase(Locale("es")).replace('“', '"').replace('”', '"').replace('‘', '\'')

        private fun adv(ch: Char): Int = when {
            ch == ' ' -> 4
            g.containsKey(ch) || marks.containsKey(ch) -> 6
            else -> measure.measureText(ch.toString()).toInt().coerceAtLeast(3) + 1
        }

        fun width(s: String): Int = s.sumOf { adv(it) }.let { if (it > 0) it - 1 else 0 }

        fun wrap(s: String, maxW: Int): List<String> {
            val out = ArrayList<String>()
            var cur = ""
            for (word in s.split(' ').filter { it.isNotEmpty() }) {
                val t = if (cur.isEmpty()) word else "$cur $word"
                if (width(t) <= maxW) cur = t
                else {
                    if (cur.isNotEmpty()) out.add(cur)
                    cur = word
                    // palabra larguísima: se parte
                    while (width(cur) > maxW && cur.length > 1) {
                        var k = cur.length - 1
                        while (k > 1 && width(cur.take(k)) > maxW) k--
                        out.add(cur.take(k)); cur = cur.drop(k)
                    }
                }
            }
            if (cur.isNotEmpty()) out.add(cur)
            return out
        }

        /** y es la parte de arriba de la letra (las tildes van 2 píxeles más arriba). */
        fun draw(c: Canvas, s: String, x0: Int, y: Int, color: Int, scale: Int, shadow: Int) {
            if (shadow != 0) draw(c, s, x0 + scale, y + scale, shadow, scale, 0)
            val p = Paint().apply { isAntiAlias = false; this.color = color }
            var x = x0
            for (ch in s) {
                val m = marks[ch]
                val glyph = g[m?.first ?: ch]
                if (glyph != null) {
                    for ((j, r) in glyph.withIndex()) for ((i, b) in r.withIndex()) if (b == '1') {
                        c.drawRect((x + i * scale).toFloat(), (y + j * scale).toFloat(), (x + (i + 1) * scale).toFloat(), (y + (j + 1) * scale).toFloat(), p)
                    }
                    if (m != null) {
                        val mr = markRows[m.second]
                        for ((j, r) in mr.withIndex()) for ((i, b) in r.withIndex()) if (b == '1') {
                            c.drawRect((x + i * scale).toFloat(), (y + (j - 3) * scale).toFloat(), (x + (i + 1) * scale).toFloat(), (y + (j - 2) * scale).toFloat(), p)
                        }
                    }
                } else if (ch != ' ') {
                    fallback.color = color
                    fallback.textSize = 9f * scale
                    c.drawText(ch.toString(), x.toFloat(), (y + 7 * scale).toFloat(), fallback)
                }
                x += adv(ch) * scale
            }
        }
    }
}
