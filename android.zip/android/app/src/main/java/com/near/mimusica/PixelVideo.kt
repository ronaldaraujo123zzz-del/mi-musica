package com.near.mimusica

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLUtils
import android.view.Surface
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sqrt
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Video pixel art de un pedazo de la canción: la carátula convertida en una escena de
 * videojuego, el avatar de NEAR caminando al ritmo y la letra como diálogo de juego.
 * Se dibuja en 180x320 "píxeles de juego" y se agranda x4 (720x1280) sin suavizar,
 * así los píxeles quedan nítidos y el archivo pesa poco.
 */
object PixelVideo {
    @Volatile
    var busy = false

    private const val GW = 180
    private const val GH = 320
    private const val SCALE = 4
    private const val FPS = 30
    private const val VIDEO_BITRATE = 2_500_000
    private const val GROUND = 272

    /** Mundo y estilo del último video (para mostrarlos en la app). */
    @Volatile
    var lastWorld = 0

    @Volatile
    var lastStyle = 0

    fun outFile(ctx: Context): File {
        val dir = File(ctx.cacheDir, "video")
        dir.mkdirs()
        return File(dir, "near-pixel-art.mp4")
    }

    private class Job(
        val id: Long,
        val title: String,
        val artist: String,
        val startMs: Long,
        val durMs: Long,
        val songMs: Long,
        val bpm: Double,
        val lines: List<Pair<Long, String>>,
        val world: Int,
        val style: Int,
        val ana: Ana,
        val calm: Boolean,
        val world2: Int,          // mundo al que se transforma en el drop (-1 = no cambia)
        val outfit: Int,
        val outfit2: Int,
        val mood: Int,            // -1 triste, 0 normal, 1 alegre
        val rhymes: BooleanArray, // la línea i rima con la anterior
        val egg: Bitmap?,         // huevo de pascua (o null)
        val seed: Long
    ) {
        val energy get() = ana.energy
        val onsets get() = ana.onsets
    }

    /** Lo que se oye, cuadro por cuadro. */
    private class Ana(
        val energy: FloatArray,      // volumen general (0..1)
        val onsets: BooleanArray,    // golpes
        val bass: FloatArray,        // bajos (0..1)
        val bassHits: BooleanArray,  // golpes de bajo fuertes
        val hype: BooleanArray,      // partes con mucha energía sostenida (coros, subidones)
        val drop: Int,               // cuadro del drop (subida brusca después de una parte tranquila); -1 si no hay
        val bright: Float            // 0 = sonido oscuro/grave, 1 = brillante/agudo
    )

    /** Audio listo para el video + su análisis. */
    private class Snd(val fmt: MediaFormat, val enc: List<Enc>, val ana: Ana)

    private class Enc(val data: ByteArray, val pts: Long, val flags: Int)

    /** Crea el video y devuelve el archivo. progress va de 0 a 1. */
    fun make(ctx: Context, json: String, progress: (Float) -> Unit): File {
        busy = true
        try {
            val o = JSONObject(json)
            val arr = o.optJSONArray("lines")
            val lines = ArrayList<Pair<Long, String>>()
            if (arr != null) for (i in 0 until arr.length()) {
                val x = arr.optJSONArray(i) ?: continue
                lines.add(x.optLong(0) to x.optString(1))
            }
            lines.sortBy { it.first }
            val id = o.getString("id").toLong()
            val startMs = o.optLong("start").coerceAtLeast(0L)
            val durMs = o.optLong("dur", 15_000L).coerceIn(3_000L, 60_000L)
            val bpm = o.optDouble("bpm", 0.0).let { if (it in 50.0..220.0) it else 0.0 }
            val frames = (durMs * FPS / 1000).toInt()
            val out = outFile(ctx)
            out.delete()
            progress(0.02f)
            val snd = try {
                audio(ctx, id, startMs, durMs, frames)
            } catch (e: Throwable) {
                null // sin sonido antes que sin video
            }
            progress(0.12f)
            val ana = snd?.ana ?: fakeAna(frames, bpm) // sin audio: al ritmo del BPM guardado (o 100)
            val perSec = ana.onsets.count { it } / (durMs / 1000f)
            val art = try { ArtLoader.bitmap(ctx, id, 256) } catch (e: Throwable) { null }
            val hsv = avgHsv(art)
            val words = o.optString("words", "")
            val clipText = lines.joinToString(" ") { it.second }
            val seed = id * 7 + startMs / 1000
            val wantW = o.optInt("world", -1)
            val wantS = o.optInt("style", -1)
            val world = if (wantW in 0..11) wantW else pickWorld("$words $clipText", hsv, id)
            val style = if (wantS in 0..4) wantS else pickStyle(perSec, seed)
            // en el drop el escenario se transforma (solo si el mundo está en automático)
            var world2 = -1
            if (wantW !in 0..11 && ana.drop > 0) {
                val dropMs = startMs + ana.drop * 1000L / FPS
                val after = lines.filter { it.first >= dropMs - 2000 }.joinToString(" ") { it.second }
                world2 = pickWorld(after, floatArrayOf((hsv[0] + 120f) % 360f, hsv[1], hsv[2]), seed + 5)
                if (world2 == world) world2 = (world + 1 + Math.floorMod(seed, 7L).toInt()) % 12
            }
            val mood = moodOf("$clipText $clipText ${words.take(1500)}")
            // traje: por el ánimo de la letra y por la canción
            val outfit = when {
                mood < 0 -> if (seed % 2 == 0L) 6 else 3
                mood > 0 -> intArrayOf(1, 5, 4, 7)[Math.floorMod(seed, 4L).toInt()]
                else -> Math.floorMod(seed * 13 + (ana.bright * 10).toInt(), 8L).toInt()
            }
            val outfit2 = (outfit + 3 + Math.floorMod(seed, 4L).toInt()) % 8
            val eggOn = o.optBoolean("eggs", true) && Math.floorMod(seed * 31, 10L) < 7 // 7 de cada 10 videos
            lastWorld = world
            lastStyle = style
            val job = Job(
                id, o.optString("title"), o.optString("artist"), startMs, durMs, o.optLong("song", 0L),
                if (bpm > 0) bpm else 100.0, lines, world, style, ana, perSec < 1.0f,
                world2, outfit, outfit2, mood, rhymesOf(lines), if (eggOn) loadEgg(ctx, seed) else null, seed
            )
            val scene = Scene(job, art)
            video(out, job, scene, snd) { p -> progress(0.12f + p * 0.88f) }
            return out
        } finally {
            busy = false
        }
    }

    /** Color promedio de la carátula en HSV. */
    private fun avgHsv(art: Bitmap?): FloatArray {
        val out = floatArrayOf(250f, 0.6f, 0.5f)
        if (art == null) return out
        val s = Bitmap.createScaledBitmap(art, 16, 16, true)
        var r = 0L; var g = 0L; var b = 0L
        for (y in 0 until 16) for (x in 0 until 16) { val px = s.getPixel(x, y); r += Color.red(px); g += Color.green(px); b += Color.blue(px) }
        Color.colorToHSV(Color.rgb((r / 256).toInt(), (g / 256).toInt(), (b / 256).toInt()), out)
        return out
    }

    /** Lo que se oye en cada cuadro: volumen, golpes, bajos, brillo, subidones y el drop. */
    private fun analyze(pcm: ShortArray, ch: Int, sr: Int, frames: Int): Ana {
        val per = maxOf(1, sr / FPS)
        val n = pcm.size / ch
        val all = FloatArray(frames); val low = FloatArray(frames); val high = FloatArray(frames)
        val aLow = (2 * PI * 150.0 / sr).toFloat().coerceIn(0.001f, 1f)   // filtro de bajos (~150 Hz)
        val aMid = (2 * PI * 1800.0 / sr).toFloat().coerceIn(0.001f, 1f)  // lo de encima de ~1.8 kHz es "brillo"
        var yl = 0f; var ym = 0f
        var sumAll = 0.0; var sumHigh = 0.0
        for (f in 0 until frames) {
            var sa = 0.0; var sl = 0.0; var sh = 0.0; var cnt = 0
            val s0 = f * per
            var i = s0
            while (i < minOf(s0 + per, n)) {
                var v = 0
                for (c in 0 until ch) v += pcm[i * ch + c]
                val x = v.toFloat() / ch
                yl += aLow * (x - yl); ym += aMid * (x - ym)
                val hi = x - ym
                sa += (x * x).toDouble(); sl += (yl * yl).toDouble(); sh += (hi * hi).toDouble()
                cnt++; i++
            }
            if (cnt > 0) {
                all[f] = sqrt(sa / cnt).toFloat(); low[f] = sqrt(sl / cnt).toFloat(); high[f] = sqrt(sh / cnt).toFloat()
                sumAll += sa; sumHigh += sh
            }
        }
        fun norm(a: FloatArray) {
            val srt = a.sorted()
            val ref = maxOf(1f, if (srt.isEmpty()) 1f else srt[(srt.size * 0.95f).toInt().coerceIn(0, srt.size - 1)])
            for (k in a.indices) a[k] = (a[k] / ref).coerceIn(0f, 1f)
        }
        norm(all); norm(low)
        // brillo: cuánto pesan los agudos (voces claras, platillos) frente al total
        val bright = if (sumAll > 0) (sqrt(sumHigh / sumAll).toFloat() * 3.2f).coerceIn(0f, 1f) else 0.5f
        fun hits(a: FloatArray, jump: Float, min: Float, gap: Int): BooleanArray {
            val on = BooleanArray(frames)
            var last = -100
            for (f in 4 until frames) {
                var avg = 0f
                val from = maxOf(0, f - 8)
                for (k in from until f) avg += a[k]
                avg /= (f - from)
                if (a[f] - avg > jump && a[f] >= a[f - 1] && a[f] > min && f - last >= gap) { on[f] = true; last = f }
            }
            return on
        }
        val onsets = hits(all, 0.16f, 0.35f, 7)
        val bassHits = hits(low, 0.22f, 0.5f, 9)
        // subidones: energía alta sostenida durante ~1.5 s
        val hype = BooleanArray(frames)
        val win = 45
        var acc = 0f
        for (f in 0 until frames) {
            acc += all[f]; if (f >= win) acc -= all[f - win]
            val m = acc / minOf(f + 1, win)
            if (f >= win / 2 && m > 0.66f) for (k in maxOf(0, f - win / 2)..f) hype[k] = true
        }
        // drop: un segundo tranquilo seguido de un segundo fuerte
        var drop = -1
        var best = 0f
        for (f in 3 * FPS until frames - 2 * FPS) {
            var before = 0f; var after = 0f
            for (k in f - FPS until f) before += all[k]
            for (k in f until f + FPS) after += all[k]
            before /= FPS; after /= FPS
            val d = after - before
            if (before < 0.5f && after > 0.62f && d > best) { best = d; drop = f }
        }
        if (best < 0.22f) drop = -1
        val sm = FloatArray(frames); val sb = FloatArray(frames)
        for (f in 0 until frames) {
            sm[f] = if (f == 0) all[0] else sm[f - 1] * 0.55f + all[f] * 0.45f
            sb[f] = if (f == 0) low[0] else maxOf(low[f], sb[f - 1] * 0.82f)
        }
        return Ana(sm, onsets, sb, bassHits, hype, drop, bright)
    }

    /** Sin audio: algo parecido a partir del BPM. */
    private fun fakeAna(frames: Int, bpm: Double): Ana {
        val per = (60.0 / (if (bpm > 0) bpm else 100.0) * FPS).toInt().coerceAtLeast(6)
        val on = BooleanArray(frames) { f -> f > FPS && f % per == 0 }
        val bh = BooleanArray(frames) { f -> f > FPS && f % (per * 2) == 0 }
        val e = FloatArray(frames) { (0.5 + 0.2 * sin(it / 9.0)).toFloat() }
        return Ana(e, on, FloatArray(frames) { 0.4f }, bh, BooleanArray(frames), -1, 0.5f)
    }

    // ----- la letra: ánimo y rimas -----
    private val SAD = listOf("triste", "llor", "solo ", "sola ", "soledad", "dolor", "duele", "adiós", "adios", "extraño", "perdí", "roto", "rota", "olvid", "lágrima", "sad", "cry", "alone", "pain", "hurt", "goodbye", "miss you", "broken")
    private val HAPPY = listOf("feliz", "sonr", "alegr", "bailar", "baila", "fiesta", "vida ", "contento", "disfrut", "happy", "smile", "fun", "dance", "party", "celebr")

    private fun moodOf(text: String): Int {
        val t = " " + text.lowercase(Locale("es")) + " "
        var s = 0; var h = 0
        for (w in SAD) if (t.contains(w)) s++
        for (w in HAPPY) if (t.contains(w)) h++
        return when { s >= h + 2 -> -1; h >= s + 2 -> 1; else -> 0 }
    }

    private fun plain(c: Char): Char = when (c) { 'á' -> 'a'; 'é' -> 'e'; 'í' -> 'i'; 'ó' -> 'o'; 'ú', 'ü' -> 'u'; else -> c }

    /** Final de una línea para comparar rimas: consonante (últimas 3 letras) y asonante (últimas 2 vocales). */
    private fun rhymeKey(line: String): Pair<String, String>? {
        val w = line.lowercase(Locale("es")).map { plain(it) }.filter { it.isLetter() || it == ' ' }.joinToString("").trim().substringAfterLast(' ')
        if (w.length < 2) return null
        val vow = w.filter { it in "aeiou" }.takeLast(2)
        return w.takeLast(3) to vow
    }

    private fun rhymesOf(lines: List<Pair<Long, String>>): BooleanArray {
        val out = BooleanArray(lines.size)
        for (i in 1 until lines.size) {
            val a = rhymeKey(lines[i - 1].second) ?: continue
            val b = rhymeKey(lines[i].second) ?: continue
            if (lines[i - 1].second.trim().equals(lines[i].second.trim(), true)) continue
            out[i] = a.first == b.first || (a.second.length == 2 && a.second == b.second)
        }
        return out
    }

    /** Huevos de pascua: imágenes escondidas en el escenario. */
    private fun loadEgg(ctx: Context, seed: Long): Bitmap? = try {
        val names = ctx.assets.list("eggs")?.filter { it.endsWith(".png") }?.sorted() ?: emptyList()
        if (names.isEmpty()) null else {
            val raw = ctx.assets.open("eggs/" + names[Math.floorMod(seed, names.size.toLong()).toInt()]).use { android.graphics.BitmapFactory.decodeStream(it) }
            val sm = Bitmap.createScaledBitmap(raw, 24, 18, true).copy(Bitmap.Config.ARGB_8888, true)
            for (y in 0 until 18) for (x in 0 until 24) {
                val px = sm.getPixel(x, y)
                fun q(v: Int) = ((v + 21) / 43 * 43).coerceIn(0, 255)
                sm.setPixel(x, y, Color.rgb(q(Color.red(px)), q(Color.green(px)), q(Color.blue(px))))
            }
            sm
        }
    } catch (e: Throwable) { null }

    // =====================================================================
    // audio: el pedazo de la canción, a AAC
    // =====================================================================
    private fun audio(ctx: Context, id: Long, startMs: Long, durMs: Long, frames: Int): Snd? {
        val ex = MediaExtractor()
        var dec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, Library.uri(id), null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                if ((ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; break }
            }
            if (track < 0) return null
            ex.selectTrack(track)
            val inFmt = ex.getTrackFormat(track)
            val d = MediaCodec.createDecoderByType(inFmt.getString(MediaFormat.KEY_MIME)!!)
            dec = d
            d.configure(inFmt, null, null, 0)
            d.start()
            val startUs = startMs * 1000
            val endUs = (startMs + durMs) * 1000
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            var sr = inFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = inFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var isFloat = false
            val pcm = ShortArrayBuilder()
            var outCh = 0
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var done = false
            var guard = 0
            while (!done && guard < 200_000) {
                guard++
                if (!inDone) {
                    val ii = d.dequeueInputBuffer(5_000)
                    if (ii >= 0) {
                        val buf = d.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0 || ex.sampleTime > endUs + 500_000) {
                            d.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            d.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = d.dequeueOutputBuffer(info, 5_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = d.outputFormat
                    sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    isFloat = f.containsKey(MediaFormat.KEY_PCM_ENCODING) && f.getInteger(MediaFormat.KEY_PCM_ENCODING) == 4
                } else if (oi >= 0) {
                    if (outCh == 0) outCh = min(2, max(1, ch))
                    if (info.size > 0) {
                        val buf = d.getOutputBuffer(oi)!!
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        val bb = buf.slice().order(ByteOrder.nativeOrder())
                        val bps = if (isFloat) 4 else 2
                        val frames = info.size / (bps * ch)
                        val t0 = info.presentationTimeUs
                        for (fi in 0 until frames) {
                            val t = t0 + fi * 1_000_000L / sr
                            if (t < startUs) continue
                            if (t >= endUs) { done = true; break }
                            for (c in 0 until outCh) {
                                val idx = (fi * ch + c) * bps
                                val v = if (isFloat) (bb.getFloat(idx) * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                                else bb.getShort(idx)
                                pcm.add(v)
                            }
                        }
                    }
                    d.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) done = true
                }
            }
            if (outCh == 0 || pcm.size == 0) return null
            var samples = pcm.toArray()
            // AAC llega hasta 48 kHz: si es más, se toma uno de cada dos
            while (sr > 48_000) {
                val n = samples.size / outCh / 2
                val half = ShortArray(n * outCh)
                for (i in 0 until n) for (c in 0 until outCh) half[i * outCh + c] = samples[(i * 2) * outCh + c]
                samples = half
                sr /= 2
            }
            val ana = analyze(samples, outCh, sr, frames)
            fade(samples, outCh, sr)
            val enc = aac(samples, sr, outCh)
            return Snd(enc.first, enc.second, ana)
        } finally {
            try { dec?.stop() } catch (e: Exception) {}
            try { dec?.release() } catch (e: Exception) {}
            ex.release()
        }
    }

    /** Entrada suave y salida suave, para que no empiece ni termine de golpe. */
    private fun fade(s: ShortArray, ch: Int, sr: Int) {
        val frames = s.size / ch
        val fin = min(frames / 4, sr * 15 / 100)
        val fout = min(frames / 3, sr * 6 / 10)
        for (i in 0 until fin) {
            val k = i.toFloat() / fin
            for (c in 0 until ch) s[i * ch + c] = (s[i * ch + c] * k).toInt().toShort()
        }
        for (i in 0 until fout) {
            val f = frames - 1 - i
            val k = i.toFloat() / fout
            for (c in 0 until ch) s[f * ch + c] = (s[f * ch + c] * k).toInt().toShort()
        }
    }

    private fun aac(pcm: ShortArray, sr: Int, ch: Int): Pair<MediaFormat, List<Enc>> {
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sr, ch)
        fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, if (ch == 1) 96_000 else 128_000)
        fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384)
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        val out = ArrayList<Enc>()
        var outFmt: MediaFormat? = null
        try {
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            val info = MediaCodec.BufferInfo()
            var pos = 0 // en muestras (short)
            var inDone = false
            var guard = 0
            while (guard < 500_000) {
                guard++
                if (!inDone) {
                    val ii = enc.dequeueInputBuffer(5_000)
                    if (ii >= 0) {
                        val buf = enc.getInputBuffer(ii)!!
                        buf.clear()
                        val room = buf.capacity() / 2
                        val n = min(room - room % ch, min(1024 * ch, pcm.size - pos))
                        val pts = (pos / ch).toLong() * 1_000_000L / sr
                        if (n <= 0) {
                            enc.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            val sb = buf.order(ByteOrder.nativeOrder()).asShortBuffer()
                            sb.put(pcm, pos, n)
                            enc.queueInputBuffer(ii, 0, n * 2, pts, 0)
                            pos += n
                        }
                    }
                }
                val oi = enc.dequeueOutputBuffer(info, 5_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    outFmt = enc.outputFormat
                } else if (oi >= 0) {
                    if (info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        val buf = enc.getOutputBuffer(oi)!!
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        val b = ByteArray(info.size)
                        buf.get(b)
                        out.add(Enc(b, info.presentationTimeUs, info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME))
                    }
                    enc.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                }
            }
        } finally {
            try { enc.stop() } catch (e: Exception) {}
            enc.release()
        }
        return (outFmt ?: throw IllegalStateException("sin formato de audio")) to out
    }

    private class ShortArrayBuilder {
        private var a = ShortArray(1 shl 16)
        var size = 0
        fun add(v: Short) {
            if (size == a.size) a = a.copyOf(a.size * 2)
            a[size++] = v
        }
        fun toArray(): ShortArray = a.copyOf(size)
    }

    // =====================================================================
    // video: H.264 por superficie (EGL), con tiempos exactos por cuadro
    // =====================================================================
    private fun video(out: File, job: Job, scene: Scene, audio: Snd?, progress: (Float) -> Unit) {
        val W = GW * SCALE
        val H = GH * SCALE
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, W, H)
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, VIDEO_BITRATE)
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        var mux: MediaMuxer? = null
        var surface: Surface? = null
        var egl: Egl? = null
        var muxOn = false
        var vTrack = -1
        val info = MediaCodec.BufferInfo()
        try {
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = enc.createInputSurface()
            enc.start()
            val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux = m
            val e = Egl(surface, W, H)
            egl = e

            fun drain(end: Boolean) {
                var tries = 0
                while (true) {
                    val oi = enc.dequeueOutputBuffer(info, if (end) 10_000 else 0)
                    if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!end || ++tries > 500) return
                    } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (!muxOn) {
                            vTrack = m.addTrack(enc.outputFormat)
                            val aTrack = if (audio != null) m.addTrack(audio.fmt) else -1
                            m.start()
                            muxOn = true
                            if (audio != null) {
                                val ai = MediaCodec.BufferInfo()
                                for (s in audio.enc) {
                                    ai.set(0, s.data.size, s.pts, s.flags)
                                    m.writeSampleData(aTrack, ByteBuffer.wrap(s.data), ai)
                                }
                            }
                        }
                    } else if (oi >= 0) {
                        val buf = enc.getOutputBuffer(oi)!!
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                        if (info.size > 0 && muxOn) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            m.writeSampleData(vTrack, buf, info)
                        }
                        enc.releaseOutputBuffer(oi, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                }
            }

            val frames = (job.durMs * FPS / 1000).toInt()
            var lastP = -1
            for (n in 0 until frames) {
                scene.draw(n)
                e.frame(scene.bmp, n.toLong() * 1_000_000_000L / FPS)
                drain(false)
                val p = (n + 1) * 100 / frames
                if (p != lastP) { lastP = p; progress(p / 100f) }
            }
            enc.signalEndOfInputStream()
            drain(true)
            if (!muxOn) throw IllegalStateException("El teléfono no pudo crear el video")
            m.stop()
        } finally {
            try { egl?.release() } catch (e: Exception) {}
            try { surface?.release() } catch (e: Exception) {}
            try { enc.stop() } catch (e: Exception) {}
            try { enc.release() } catch (e: Exception) {}
            try { mux?.release() } catch (e: Exception) {}
        }
    }

    /** EGL + un cuadrado con la imagen chiquita agrandada sin suavizar. */
    private class Egl(surface: Surface, private val w: Int, private val h: Int) {
        private val dpy: EGLDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        private val ctx: EGLContext
        private val surf: EGLSurface
        private val prog: Int
        private val tex: Int
        private var texReady = false
        private val quad: FloatBuffer

        init {
            val v = IntArray(2)
            check(EGL14.eglInitialize(dpy, v, 0, v, 1)) { "EGL" }
            val attrs = intArrayOf(
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                0x3142, 1, // EGL_RECORDABLE_ANDROID
                EGL14.EGL_NONE
            )
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val num = IntArray(1)
            check(EGL14.eglChooseConfig(dpy, attrs, 0, cfgs, 0, 1, num, 0) && num[0] > 0) { "EGL config" }
            ctx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
            surf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], surface, intArrayOf(EGL14.EGL_NONE), 0)
            check(EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) { "EGL current" }

            prog = program(
                "attribute vec4 aPos; attribute vec2 aUV; varying vec2 vUV; void main(){ gl_Position = aPos; vUV = aUV; }",
                "precision mediump float; varying vec2 vUV; uniform sampler2D uTex; void main(){ gl_FragColor = texture2D(uTex, vUV); }"
            )
            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            tex = t[0]
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            // x, y, u, v
            val q = floatArrayOf(-1f, -1f, 0f, 1f, 1f, -1f, 1f, 1f, -1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f)
            quad = ByteBuffer.allocateDirect(q.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(q)
        }

        private fun shader(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            return s
        }

        private fun program(vs: String, fs: String): Int {
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, vs))
            GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, fs))
            GLES20.glLinkProgram(p)
            return p
        }

        fun frame(bmp: Bitmap, ptsNs: Long) {
            GLES20.glViewport(0, 0, w, h)
            GLES20.glUseProgram(prog)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
            if (!texReady) {
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
                texReady = true
            } else {
                GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bmp)
            }
            GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uTex"), 0)
            val aPos = GLES20.glGetAttribLocation(prog, "aPos")
            val aUV = GLES20.glGetAttribLocation(prog, "aUV")
            quad.position(0)
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad)
            GLES20.glEnableVertexAttribArray(aPos)
            quad.position(2)
            GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 16, quad)
            GLES20.glEnableVertexAttribArray(aUV)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            EGLExt.eglPresentationTimeANDROID(dpy, surf, ptsNs)
            EGL14.eglSwapBuffers(dpy, surf)
        }

        fun release() {
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(dpy, surf)
            EGL14.eglDestroyContext(dpy, ctx)
            EGL14.eglReleaseThread()
            EGL14.eglTerminate(dpy)
        }
    }

    // =====================================================================
    // la escena: 12 mundos, 5 estilos de juego, efectos según la letra y
    // todo moviéndose con la energía y los golpes reales de la canción
    // =====================================================================
    val WORLDS = arrayOf("Pradera", "Playa", "Ciudad neón", "Nieve", "Espacio", "Castillo", "Desierto", "Bajo el agua", "Sala del tiempo", "Mina rocosa", "Nether", "Mundo del revés")
    val STYLES = arrayOf("Plataformas", "Nave espacial", "Carrera", "Aventura RPG", "Pelea arcade")

    private val FX_WORDS = linkedMapOf(
        "rain" to listOf("lluvia", "llueve", "llover", "llorar", "lloro", "lágrima", "lagrima", "rain", "cry", "tears"),
        "fire" to listOf("fuego", "arde", "arder", "quema", "llama", "caliente", "fire", "burn", "flame", "hot"),
        "love" to listOf("amor", "corazón", "corazon", "te quiero", "te amo", "beso", "enamor", "love", "heart", "kiss", "baby", "bebé"),
        "night" to listOf("noche", "luna", "oscur", "night", "moon", "dark", "madrugada"),
        "stars" to listOf("estrella", "cielo", "brillar", "star", "sky", "shine", "universo", "galaxia"),
        "sun" to listOf("sol ", " sol", "día", "verano", " luz", "sun", "summer", "light", "mañana"),
        "snow" to listOf("nieve", "frío", "frio", "hielo", "invierno", "snow", "cold", "ice", "winter"),
        "money" to listOf("dinero", "plata", "oro ", "rico", "money", "cash", "gold", "rich"),
        "party" to listOf("bailar", "baila", "fiesta", "perreo", "dance", "party", "club", "disco")
    )
    private val WORLD_WORDS = arrayOf(
        listOf("campo", "flor", "árbol", "arbol", "verde", "libre", "field", "flower", "tree", "free", "green"),
        listOf(" mar ", "playa", " ola", "arena", "verano", " sea ", "beach", "wave", "summer"),
        listOf("ciudad", "calle", "noche", "club", "fiesta", "neón", "neon", "city", "street", "night", "party"),
        listOf("nieve", "frío", "frio", "hielo", "invierno", "snow", "cold", " ice", "winter"),
        listOf("estrella", "luna", "cielo", "universo", "galaxia", "planeta", "star", "moon", "space", " sky", "galaxy"),
        listOf(" rey", "reina", "princesa", "castillo", "corona", "dragón", "king", "queen", "princess", "castle", "crown"),
        listOf("desierto", " sed ", "calor", "arena", "desert", "heat", "thirst"),
        listOf("agua", "océano", "oceano", "profundo", "ahogo", " pez", "water", "ocean", "deep", "drown", "underwater"),
        listOf("tiempo", "reloj", "eterno", "infinito", "siempre", "recuerdo", "time", "forever", "clock", "memory"),
        listOf("mina", "cueva", "roca", "piedra", "cristal", "diamante", "cave", "rock", "stone", "diamond", "crystal"),
        listOf("infierno", "demonio", "diablo", "lava", "pecado", "hell", "devil", "demon"),
        listOf("revés", "reves", "extraño", "miedo", "sombra", "pesadilla", "monstruo", "fear", "strange", "shadow", "nightmare", "monster")
    )

    private fun fxOf(text: String): Set<String> {
        val t = " " + text.lowercase(Locale("es")) + " "
        val out = LinkedHashSet<String>()
        for ((k, ws) in FX_WORDS) if (ws.any { t.contains(it) }) { out.add(k); if (out.size == 2) break }
        return out
    }

    /** Elige el mundo: por las palabras de toda la letra y, si no dicen nada, por los colores de la carátula. */
    private fun pickWorld(words: String, hsv: FloatArray, seed: Long): Int {
        val t = " " + words.lowercase(Locale("es")) + " "
        var best = -1
        var bestN = 1
        for (w in WORLD_WORDS.indices) {
            var n = 0
            for (k in WORLD_WORDS[w]) {
                var i = t.indexOf(k)
                while (i >= 0 && n < 50) { n++; i = t.indexOf(k, i + k.length) }
            }
            if (n > bestN || (n == bestN && n > 1 && best >= 0 && (seed % 2L) == 0L)) { best = w; bestN = n }
        }
        if (best >= 0) return best
        val h = hsv[0]; val s = hsv[1]; val v = hsv[2]
        val odd = (seed % 2L) == 1L
        return when {
            v < 0.22f -> 4
            s < 0.18f && v > 0.68f -> 3
            s < 0.18f -> if (odd) 5 else 4
            h >= 185f && h < 255f -> if (v > 0.55f) 1 else 7
            h >= 255f && h < 335f -> if (s > 0.4f) 2 else 5
            h >= 18f && h < 65f -> 6
            h >= 65f && h < 185f -> if (h > 150f) 7 else 0
            else -> if (odd) 5 else 2
        }
    }

    /** Elige el estilo de juego según qué tan movida es la canción. */
    private fun pickStyle(onsetsPerSec: Float, seed: Long): Int {
        val odd = (seed / 3L) % 2L == 1L
        return when {
            onsetsPerSec > 2.1f -> if (odd) 4 else 1
            onsetsPerSec > 1.3f -> if (odd) 2 else 0
            else -> if (odd) 3 else 0
        }
    }

    private class Rng(seed: Long) {
        private var a = (seed and 0x7FFFFFFF).let { if (it == 0L) 1L else it }
        fun f(): Float { a = (a * 1103515245L + 12345L) and 0x7FFFFFFF; return a / 2147483648f }
        fun i(n: Int): Int = (f() * n).toInt().coerceIn(0, maxOf(0, n - 1))
    }

    private class Pal(val top: Int, val bot: Int, val far: Int, val near: Int, val ground: Int, val topG: Int, val dark: Int, val frame: Int, val box: Int)

    private class Scene(private val job: Job, art: Bitmap?) {
        val bmp: Bitmap = Bitmap.createBitmap(GW, GH, Bitmap.Config.ARGB_8888)
        private val c = Canvas(bmp)
        private val p = Paint().apply { isAntiAlias = false; isFilterBitmap = false }
        private val font = PixFont()
        private val rnd = Rng(job.id * 31 + job.startMs)
        private var W = job.world
        private val ST = job.style
        private var outfit = job.outfit
        private var transT = -1          // cuadro en que se transformó (drop)
        private var lastLine = -1
        private var rhymeStreak = 0
        private var rhymeT = -100
        private val rings = ArrayList<FloatArray>()   // ondas del bajo: x, radio
        private var golden = 0f           // modo dorado (subidones)
        private var dark = 0f             // noche de fondo según el tono de la canción
        private val nightBase: Float
        private val rainBase: Float

        private val hue: Float
        private val sat: Float
        private val cover: Bitmap
        val coverHsv = FloatArray(3)
        private val stars: List<IntArray>
        private val far = IntArray(GW * 2)
        private val near = IntArray(GW * 2)
        private var P: Pal

        // estado del juego (los cuadros se dibujan en orden)
        private class Part(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Int, val col: Int, val txt: String?)
        private val parts = ArrayList<Part>()
        private var flash = 0f
        private var jump = 0
        private var score = 0
        private var combo = 0
        private var ehp = 1f
        private var hits = 0
        private val totalOn = maxOf(1, job.onsets.count { it })
        private val coins = ArrayList<FloatArray>()      // x, y
        private val enemies = ArrayList<FloatArray>()    // x, y, tipo
        private val shots = ArrayList<FloatArray>()      // x, y
        private val cones = ArrayList<FloatArray>()      // x, carril
        private val chests = ArrayList<IntArray>()       // x, y, edad
        private var roadScroll = 0f
        private var lane = 1
        private var laneY = 1f
        private var punch = 0
        private var hurt = 0
        private var worldScroll = 0f
        private val fxa = HashMap<String, Float>()

        init {
            val src = art ?: run {
                val b = Bitmap.createBitmap(36, 36, Bitmap.Config.ARGB_8888)
                val h0 = (abs(job.title.hashCode()) % 360).toFloat()
                for (y in 0 until 36) for (x in 0 until 36) b.setPixel(x, y, Color.HSVToColor(floatArrayOf((h0 + (x + y) * 1.5f) % 360f, 0.6f, 0.35f + 0.5f * (1f - y / 36f))))
                b
            }
            val small = Bitmap.createScaledBitmap(src, 36, 36, true).copy(Bitmap.Config.ARGB_8888, true)
            var r = 0L; var g = 0L; var bl = 0L
            for (y in 0 until 36) for (x in 0 until 36) {
                val px = small.getPixel(x, y)
                r += Color.red(px); g += Color.green(px); bl += Color.blue(px)
                small.setPixel(x, y, Color.rgb(q(Color.red(px)), q(Color.green(px)), q(Color.blue(px))))
            }
            cover = small
            Color.colorToHSV(Color.rgb((r / 1296).toInt(), (g / 1296).toInt(), (bl / 1296).toInt()), coverHsv)
            hue = coverHsv[0]
            sat = coverHsv[1].coerceIn(0.35f, 0.8f)
            val rn = Rng(job.id + 3)
            stars = List(60) { intArrayOf(rn.i(GW), rn.i(200), rn.i(1000), rn.i(3)) }
            hills(rn, far, 46, 24, 3.0)
            hills(rn, near, 22, 12, 5.0)
            P = palette()
            // canciones de sonido oscuro/grave: más de noche; letra triste: más gris y con algo de lluvia
            nightBase = (((0.48f - job.ana.bright) * 1.7f).coerceIn(0f, 0.6f) + (if (job.mood < 0) 0.15f else 0f)).let { if (W == 2 || W == 4 || W == 5 || W >= 8) 0f else it }
            rainBase = if (job.mood < 0 && W != 4 && W != 7 && W < 8) 0.35f else 0f
        }

        private fun q(v: Int) = ((v + 25) / 51 * 51).coerceIn(0, 255)

        private fun hills(rn: Rng, a: IntArray, base: Int, amp: Int, freq: Double) {
            val ph = rn.f() * 10.0
            for (i in a.indices) {
                val x = i.toDouble() / a.size * 2 * PI
                a[i] = base + (amp * (0.55 * sin(x * freq + ph) + 0.3 * sin(x * freq * 2.7 + ph * 2) + 0.15 * sin(x * freq * 6.1))).toInt()
            }
        }

        // ---------- colores ----------
        private fun hsv(h: Float, s: Float, v: Float): Int =
            Color.HSVToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))

        private fun mix(a: Int, b: Int, k0: Float): Int {
            val k = k0.coerceIn(0f, 1f)
            return Color.rgb(
                (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
                (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
                (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
            )
        }

        private fun alpha(col: Int, a: Float): Int = ((a.coerceIn(0f, 1f) * 255).toInt() shl 24) or (col and 0xFFFFFF)

        private fun palette(): Pal {
            val base = hsv(hue, sat, 0.6f)
            fun tint(col: Int, k: Float = 0.18f) = mix(col, base, k)
            return when (W) {
                0 -> Pal(tint(0xFF3E8FE0.toInt()), tint(0xFFBFE6FF.toInt()), tint(0xFF6FAE7A.toInt()), tint(0xFF3F8F4F.toInt()), 0xFF6B4A2E.toInt(), 0xFF5CC24E.toInt(), 0xFF4E3420.toInt(), 0xFFFFFFFF.toInt(), tint(0xFF14301C.toInt(), 0.3f))
                1 -> Pal(tint(0xFFFF8A5C.toInt()), tint(0xFFFFE2A8.toInt()), 0xFF2A8FD6.toInt(), 0xFF1F6FB0.toInt(), 0xFFF2D38A.toInt(), 0xFFFFF0C0.toInt(), 0xFFD9B46A.toInt(), 0xFFFFF6D8.toInt(), tint(0xFF2A1A10.toInt(), 0.3f))
                2 -> Pal(0xFF07021A.toInt(), tint(0xFF3A0C5A.toInt(), 0.3f), 0xFF1A0E3A.toInt(), 0xFF120828.toInt(), 0xFF1A1A2A.toInt(), 0xFFFF4FD8.toInt(), 0xFF101020.toInt(), 0xFFFF4FD8.toInt(), 0xFF0A0418.toInt())
                3 -> Pal(tint(0xFF8FB6E0.toInt()), 0xFFEAF4FF.toInt(), 0xFFC8D8EE.toInt(), 0xFFA8BCD8.toInt(), 0xFFF4F8FF.toInt(), 0xFFFFFFFF.toInt(), 0xFFC6D6EA.toInt(), 0xFFBFE6FF.toInt(), 0xFF12223A.toInt())
                4 -> Pal(0xFF03020C.toInt(), tint(0xFF1C0D3E.toInt(), 0.35f), 0xFF2A1E4A.toInt(), 0xFF1A1236.toInt(), 0xFF8A8AA0.toInt(), 0xFFB8B8CC.toInt(), 0xFF6A6A82.toInt(), 0xFF9FD8FF.toInt(), 0xFF070414.toInt())
                5 -> Pal(0xFF1A0E36.toInt(), tint(0xFF7A3D8F.toInt(), 0.25f), 0xFF24163E.toInt(), 0xFF160C2A.toInt(), 0xFF5A5068.toInt(), 0xFF7A7090.toInt(), 0xFF3E3650.toInt(), 0xFFFFD23F.toInt(), 0xFF140A24.toInt())
                6 -> Pal(tint(0xFFFF7A3D.toInt(), 0.12f), 0xFFFFD98A.toInt(), 0xFFE8A85A.toInt(), 0xFFD48A3A.toInt(), 0xFFEBB86A.toInt(), 0xFFF6CF8A.toInt(), 0xFFCF9A50.toInt(), 0xFFFFE9A8.toInt(), 0xFF2A1406.toInt())
                8 -> Pal(0xFFFFFFFF.toInt(), 0xFFE0DCF8.toInt(), 0xFFD0CBEF.toInt(), 0xFFE6E2FA.toInt(), 0xFFF4F2FF.toInt(), 0xFFFFFFFF.toInt(), 0xFFC4BEE8.toInt(), 0xFFFFE9A8.toInt(), 0xFF3A3470.toInt())
                9 -> Pal(0xFF1E1018.toInt(), 0xFF4A2A28.toInt(), 0xFF3A2220.toInt(), 0xFF5E3A2E.toInt(), 0xFF6B4226.toInt(), 0xFFB07A48.toInt(), 0xFF3A2212.toInt(), 0xFFFFB02E.toInt(), 0xFF2A1810.toInt())
                10 -> Pal(0xFF2A0508.toInt(), 0xFF8A2410.toInt(), 0xFF5A1418.toInt(), 0xFF7A2020.toInt(), 0xFF7A2A2E.toInt(), 0xFFB04A48.toInt(), 0xFF4A1418.toInt(), 0xFFFF8A1E.toInt(), 0xFF3A0C10.toInt())
                11 -> Pal(0xFF0A0818.toInt(), 0xFF5A1430.toInt(), 0xFF1A0E22.toInt(), 0xFF2A1430.toInt(), 0xFF2A1A34.toInt(), 0xFF9A2A4A.toInt(), 0xFF140A1C.toInt(), 0xFFFF4D5E.toInt(), 0xFF1A0C24.toInt())
                else -> Pal(0xFF06264A.toInt(), tint(0xFF1F7FBF.toInt(), 0.2f), 0xFF0E4A6E.toInt(), 0xFF0A3656.toInt(), 0xFFC8B27A.toInt(), 0xFFDCC894.toInt(), 0xFFA8925A.toInt(), 0xFF8FE8FF.toInt(), 0xFF041828.toInt())
            }
        }

        // ---------- dibujo básico ----------
        private fun rect(x: Number, y: Number, w: Number, h: Number, col: Int) {
            val xi = x.toInt(); val yi = y.toInt(); val wi = w.toInt(); val hi = h.toInt()
            if (wi <= 0 || hi <= 0 || (col ushr 24) == 0) return
            p.color = col
            c.drawRect(xi.toFloat(), yi.toFloat(), (xi + wi).toFloat(), (yi + hi).toFloat(), p)
        }

        private fun px(x: Number, y: Number, col: Int) = rect(x, y, 1, 1, col)

        private fun sprite(rows: Array<String>, pal: Map<Char, Int>, x: Int, y: Int, sc: Int) {
            for ((j, r) in rows.withIndex()) for ((i, ch) in r.withIndex()) {
                val col = pal[ch] ?: continue
                rect(x + i * sc, y + j * sc, sc, sc, col)
            }
        }

        private fun heart(x: Int, y: Int, col: Int) {
            val rows = arrayOf(".##.##.", "#######", "#######", ".#####.", "..###..", "...#...")
            for ((j, r) in rows.withIndex()) for ((i, ch) in r.withIndex()) if (ch == '#') px(x + i, y + j, col)
        }

        // ---------- mundos ----------
        private fun drawWorld(t: Long, sp: Float) {
            val night = fxa["night"] ?: 0f
            for (i in 0 until 14) {
                var col = mix(P.top, P.bot, i / 13f)
                if (night > 0f) col = mix(col, 0xFF0A0620.toInt(), night * 0.65f)
                rect(0, i * 20, GW, 20, col)
            }
            val starAmt = if (W == 2 || W == 4 || W == 5) 1f else maxOf(night, fxa["stars"] ?: 0f)
            if (starAmt > 0.05f) for (s in stars) {
                val ph = ((t + s[2]) / 300) % 4
                if (ph == 0L) continue
                if ((s[0] * 7 + s[1]) % 100 > starAmt * 100) continue
                val col = if (s[3] == 0) 0xFFFFE9A8.toInt() else 0xFFFFFFFF.toInt()
                px(s[0], s[1], col)
                if (s[3] == 2 && ph == 1L) { rect(s[0] - 1, s[1], 3, 1, col); rect(s[0], s[1] - 1, 1, 3, col) }
            }
            val o1 = (sp * 0.18f).toInt(); val o2 = (sp * 0.45f).toInt(); val o3 = sp.toInt()
            when (W) {
                0 -> {
                    rect(140, 58, 14, 14, 0xFFFFF1A8.toInt()); rect(138, 60, 18, 10, 0xFFFFF1A8.toInt())
                    for (k in 0 until 3) {
                        val cx = Math.floorMod(k * 70 - o1 * 2, 220) - 30
                        rect(cx, 70 + k * 18, 22, 5, -1); rect(cx + 4, 67 + k * 18, 11, 3, -1)
                    }
                    hillsDraw(o1, o2)
                }
                1 -> {
                    rect(136, 200, 26, 10, 0xFFFFE17A.toInt()); rect(132, 204, 34, 6, 0xFFFFE17A.toInt()); rect(140, 196, 18, 4, 0xFFFFE17A.toInt())
                    rect(0, 210, GW, GROUND - 210, P.far)
                    var y = 214
                    while (y < GROUND) {
                        var x = -16
                        while (x < GW + 16) {
                            val xx = x + ((y / 8) % 2) * 8 - Math.floorMod((sp * 0.3f).toInt() + y, 16)
                            rect(xx, y, 6, 1, 0xFF7FC8FF.toInt()); x += 16
                        }
                        y += 8
                    }
                    rect(0, 210, GW, 2, 0xFFFFF0D0.toInt()); rect(132, 212, 34, 2, 0xFFFFE17A.toInt()); rect(140, 218, 18, 1, 0xFFFFE17A.toInt())
                    for (k in 0 until 2) {
                        val bx = Math.floorMod(k * 120 + 130 - o2, 260) - 40
                        for (j in 0 until 8) rect(bx + j / 3, GROUND - 6 - j * 6, 3, 6, 0xFF6B4423.toInt())
                        for (d in intArrayOf(-1, 1)) for (j in 0 until 5) rect(bx + d * j * 3, GROUND - 52 + j * 2, 4, 3, 0xFF2E8B3E.toInt())
                    }
                }
                2 -> {
                    for (i in 0 until 14) {
                        val bh = 40 + (i * 53) % 60; val bx = Math.floorMod(i * 15 - o1, 210) - 15
                        rect(bx, GROUND - bh, 13, bh, P.far)
                        var wy = GROUND - bh + 4
                        while (wy < GROUND - 6) {
                            for (wx in intArrayOf(2, 7)) if ((i + wy + wx) % 3 != 0) rect(bx + wx, wy, 3, 3, if ((i + wy) % 2 != 0) 0xFF2EE6FF.toInt() else 0xFFFF4FD8.toInt())
                            wy += 6
                        }
                    }
                    for (i in 0 until 10) {
                        val bh = 22 + (i * 37) % 30; val bx = Math.floorMod(i * 22 - o2, 220) - 20
                        rect(bx, GROUND - bh, 20, bh, P.near)
                        rect(bx + 3, GROUND - bh + 4, 14, 3, if (i % 2 != 0) 0xFFFF4FD8.toInt() else 0xFF2EE6FF.toInt())
                    }
                }
                3 -> {
                    for (x in 0 until GW) {
                        val h1 = far[(x + o1) % far.size] + 10
                        rect(x, GROUND - h1, 1, h1, P.far); rect(x, GROUND - h1, 1, 4, -1)
                    }
                    for (k in 0 until 7) {
                        val bx = Math.floorMod(k * 34 - o2, 240) - 30
                        for (j in 0 until 5) rect(bx + 6 - j * 2, GROUND - 40 + j * 7, 4 + j * 4, 7, 0xFF1F4D3A.toInt())
                        for (j in 0 until 5) rect(bx + 6 - j * 2, GROUND - 40 + j * 7, 4 + j * 4, 2, -1)
                        rect(bx + 7, GROUND - 6, 3, 6, 0xFF4A3020.toInt())
                    }
                }
                4 -> {
                    val cx = 156 + (sin(t / 3000.0) * 3).toInt(); val cy = 96; val R = 18
                    val pc = hsv(hue, sat, 0.7f)
                    for (y in -R..R) {
                        val w = sqrt((R * R - y * y).toDouble()).toInt()
                        rect(cx - w, cy + y, w * 2, 1, mix(pc, 0xFF000000.toInt(), if (y > R * 0.3) 0.5f else if ((Math.floorDiv(y, 4)) % 2 != 0) 0.25f else 0f))
                    }
                    rect(cx - 30, cy - 1, 60, 3, 0xFFE8D8A8.toInt()); rect(cx - 25, cy + 2, 50, 1, 0xFFB8A878.toInt())
                    rect(14, 214, 8, 8, 0xFFD8D8E8.toInt()); rect(12, 216, 12, 4, 0xFFD8D8E8.toInt()); px(16, 216, 0xFFA8A8C0.toInt())
                    for (x in 0 until GW) {
                        val h2 = near[(x + o2) % near.size] / 2 + 6
                        rect(x, GROUND - h2, 1, h2, P.dark)
                    }
                }
                5 -> {
                    rect(128, 54, 26, 26, 0xFFFFF6D0.toInt()); rect(124, 58, 34, 18, 0xFFFFF6D0.toInt()); rect(134, 60, 5, 5, 0xFFE8DCB0.toInt())
                    for (cx in intArrayOf(40 - o1 % 200, 240 - o1 % 200)) {
                        rect(cx, GROUND - 52, 64, 52, P.far)
                        for (k in 0 until 4) {
                            rect(cx - 6 + k * 22, GROUND - 66, 12, 66, P.far)
                            for (m in 0 until 3) rect(cx - 6 + k * 22 + m * 5, GROUND - 70, 3, 4, P.far)
                            if ((k + t / 400) % 3 != 0L) rect(cx - 2 + k * 22, GROUND - 56, 4, 6, 0xFFFFC14A.toInt())
                        }
                        rect(cx + 26, GROUND - 16, 12, 16, 0xFF0A0614.toInt())
                        rect(cx + 30, GROUND - 82, 1, 14, 0xFF888888.toInt())
                        rect(cx + 31, GROUND - 82, 8, 5, if ((t / 300) % 2 != 0L) 0xFFE0303A.toInt() else 0xFFC02030.toInt())
                    }
                    for (x in 0 until GW) {
                        val h2 = near[(x + o2) % near.size] / 2
                        rect(x, GROUND - h2, 1, h2, P.near)
                    }
                }
                6 -> {
                    rect(140, 64, 30, 30, 0xFFFFF0A8.toInt()); rect(136, 70, 38, 18, 0xFFFFF0A8.toInt())
                    for (k in 0 until 3) rect(0, 214 + k * 9 + (sin(t / 200.0 + k) * 1).toInt(), GW, 1, 0x22FFFFFF)
                    for (x in 0 until GW) {
                        val h1 = far[(x + o1) % far.size] / 2 + 14
                        rect(x, GROUND - h1, 1, h1, P.far)
                        val h2 = near[(x + o2) % near.size] / 2 + 4
                        rect(x, GROUND - h2, 1, h2, P.near)
                    }
                    for (k in 0 until 3) {
                        val bx = Math.floorMod(k * 80 + 40 - o2, 240) - 30
                        val cg = 0xFF2E8B3E.toInt()
                        rect(bx, GROUND - 30, 6, 30, cg); rect(bx - 6, GROUND - 22, 6, 4, cg); rect(bx - 6, GROUND - 28, 3, 8, cg)
                        rect(bx + 6, GROUND - 18, 6, 4, cg); rect(bx + 9, GROUND - 24, 3, 8, cg)
                    }
                }
                8 -> { // sala del tiempo: cuarto blanco infinito con un portal
                    for (k in 0 until 36) {
                        val sx = (k * 53) % GW; val sy = (k * 37) % 250
                        if ((t / 250 + k) % 5 != 0L) px(sx, sy, if (k % 2 == 0) -1 else 0xFFB8B2E8.toInt())
                    }
                    for (k in 0 until 6) {
                        val bx = Math.floorMod(k * 40 - o1, 240) - 20
                        rect(bx, GROUND - 96, 14, 96, P.far); rect(bx - 3, GROUND - 100, 20, 5, P.far); rect(bx - 3, GROUND - 6, 20, 6, P.far)
                    }
                    val cubesX = intArrayOf(12, 150, 24, 146); val cubesY = intArrayOf(76, 92, 118, 130)
                    for (k in 0 until 4) {
                        val fy = cubesY[k] + (sin(t / 500.0 + k * 1.7) * 4).toInt()
                        rect(cubesX[k], fy, 9, 9, 0xFFFFE9A8.toInt()); rect(cubesX[k] + 2, fy + 2, 5, 5, -1)
                    }
                    val gl = if ((t / 300) % 2 == 0L) 0xFFD8F2FF.toInt() else 0xFFBCE6FF.toInt()
                    rect(121, 172, 40, 5, 0xFFB8B2E8.toInt()); rect(124, 176, 34, GROUND - 176, 0xFFB8B2E8.toInt())
                    rect(127, 180, 28, GROUND - 180, 0xFF78C8FF.toInt()); rect(131, 184, 20, GROUND - 184, gl)
                    var py = 190
                    while (py < GROUND - 4) { rect(137, py, 8, 3, -1); py += 8 }
                }
                9 -> { // mina rocosa
                    for (x in 0 until GW) { val h = far[(x + o1) % far.size] / 2 + 10; rect(x, GROUND - h, 1, h, P.far) }
                    for (x in 0 until GW) { val h = near[(x * 2 + o2) % near.size] / 2 + 2; rect(x, GROUND - h, 1, h, P.near) }
                    var wy = 58
                    while (wy < GROUND) {
                        val w = 14 + (sin(wy / 13.0) * 5).toInt()
                        rect(0, wy, w, 6, 0xFF5E3A2E.toInt()); rect(0, wy, w - 4, 6, 0xFF7A4C38.toInt())
                        rect(GW - w, wy, w, 6, 0xFF5E3A2E.toInt()); rect(GW - w + 4, wy, w - 4, 6, 0xFF7A4C38.toInt())
                        wy += 6
                    }
                    val crx = intArrayOf(8, 160, 6, 162); val cry = intArrayOf(98, 128, 172, 82)
                    val crc = intArrayOf(0xFFBE5AFF.toInt(), 0xFF5AC8FF.toInt(), 0xFF5AC8FF.toInt(), 0xFFBE5AFF.toInt())
                    for (k in 0 until 4) {
                        val shine = if ((t / 400 + k) % 4 == 0L) 0.7f else 0.4f
                        rect(crx[k], cry[k], 5, 12, crc[k]); rect(crx[k] + 5, cry[k] + 4, 4, 8, mix(crc[k], -1, shine)); rect(crx[k] + 1, cry[k] + 2, 2, 4, -1)
                    }
                    for (k in 0 until 2) {
                        val bx = Math.floorMod(k * 130 + 50 - o2, 260) - 40
                        rect(bx - 26, 206, 64, 6, 0xFF7A4A22.toInt()); rect(bx - 26, 212, 64, 2, 0xFF462A12.toInt())
                        rect(bx - 24, 206, 6, GROUND - 206, 0xFF7A4A22.toInt()); rect(bx + 30, 206, 6, GROUND - 206, 0xFF7A4A22.toInt())
                    }
                    val lamp = if ((t / 160) % 3 != 0L) 0xFFFFF0A0.toInt() else 0xFFFFD060.toInt()
                    for (lx in intArrayOf(20, 150)) {
                        rect(lx + 4, 58, 2, 26, 0xFF1E1414.toInt()); rect(lx, 84, 10, 10, 0xFFFFB02E.toInt()); rect(lx + 2, 86, 6, 6, lamp)
                    }
                }
                10 -> { // nether
                    for (k in 0 until 44) {
                        val ex = (k * 47) % GW
                        val ey = Math.floorMod(k * 31 - (t / 18).toInt(), GROUND)
                        px(ex, ey, if (k % 3 != 0) 0xFFFF8C28.toInt() else 0xFFFFD060.toInt())
                    }
                    for (x in 0 until GW) { val h = far[(x + o1) % far.size] / 2 + 16; rect(x, GROUND - h, 1, h, P.far) }
                    rect(0, GROUND - 14, GW, 14, 0xFFFF6A10.toInt())
                    for (ly in intArrayOf(GROUND - 11, GROUND - 6)) {
                        var lx = (ly / 5 % 2) * 14 - o3 % 28
                        while (lx < GW) { rect(lx, ly, 14, 2, 0xFFFFC040.toInt()); lx += 28 }
                    }
                    val bxs = intArrayOf(2, 146, 4); val bys = intArrayOf(92, 104, 168); val bws = intArrayOf(30, 32, 34)
                    for (k in 0 until 3) {
                        val by = bys[k] + (sin(t / 600.0 + k) * 2).toInt()
                        var bx = bxs[k]
                        while (bx < bxs[k] + bws[k]) { rect(bx, by, 10, 10, 0xFF7A2830.toInt()); rect(bx, by, 10, 3, 0xFFA84A48.toInt()); bx += 10 }
                    }
                    val lf = if ((t / 120) % 2 == 0L) 0xFFFFE070.toInt() else 0xFFFFC050.toInt()
                    rect(160, 114, 6, GROUND - 114, 0xFFFF9A20.toInt()); rect(162, 114, 2, GROUND - 114, lf)
                    rect(38, 222, 10, 10, 0xFFFFD040.toInt()); rect(40, 224, 6, 6, 0xFFFFF4B0.toInt())
                    rect(96, 230, 10, 10, 0xFFFFD040.toInt()); rect(98, 232, 6, 6, 0xFFFFF4B0.toInt())
                }
                11 -> { // mundo del revés
                    if ((t / 400) % 4 == 0L) for (b in 0 until 2) {
                        var bx = if (b == 0) 12 else 166
                        var by = 58; var j = 0
                        while (by < 150) {
                            val nx = bx + (Math.floorMod(j * 5 + b * 2, 3) - 1) * 4
                            rect(minOf(bx, nx), by, Math.abs(nx - bx) + 2, 14, 0xFFFF4A5A.toInt())
                            bx = nx; by += 12; j++
                        }
                    }
                    for (k in 0 until 8) {
                        val tx = Math.floorMod(k * 28 - o2, 240) - 20
                        rect(tx, GROUND - 82, 6, 82, P.far); rect(tx - 12, GROUND - 60, 14, 4, P.far); rect(tx + 6, GROUND - 46, 14, 4, P.far); rect(tx - 6, GROUND - 74, 8, 4, P.far)
                    }
                    for (x in 0 until GW) { val h = near[(x + o2) % near.size] / 2 + 4; rect(x, GROUND - h, 1, h, P.near) }
                    for (x in 0 until GW step 12) {
                        val hh = 14 + (x * 7) % 34; val sw = (sin(t / 500.0 + x) * 1).toInt()
                        rect(x + sw, 58, 3, hh, 0xFF8A1E3A.toInt()); rect(x - 1 + sw, 58 + hh, 5, 5, 0xFFD0405A.toInt())
                    }
                    for (k in 0 until 38) {
                        val spx = Math.floorMod(k * 47 + (sin(t / 700.0 + k) * 6).toInt(), GW)
                        val spy = 60 + Math.floorMod(k * 53 - (t / 30).toInt(), GROUND - 60)
                        px(spx, spy, 0xFFFFEBD2.toInt())
                    }
                }
                else -> {
                    for (k in 0 until 5) {
                        val lx = (k * 44 + (t / 60).toInt()) % 220 - 20
                        var y = 0
                        while (y < 200) { rect(lx + y / 6, y, 6, 4, 0x18FFFFFF); y += 4 }
                    }
                    for (k in 0 until 9) {
                        val bx = Math.floorMod(k * 23 - o2, 220) - 20
                        for (j in 0 until 7) {
                            val sway = (sin(t / 400.0 + k + j * 0.6) * 2).toInt()
                            rect(bx + sway, GROUND - 6 - j * 6, 3, 6, if (k % 2 != 0) 0xFF2E9B5A.toInt() else 0xFF1F7A4A.toInt())
                        }
                    }
                    for (k in 0 until 3) {
                        val fx = ((k * 90 + (t * 0.03).toInt() * (1 + k % 2)) % 260) - 40; val fy = 214 + k * 14
                        rect(fx, fy, 8, 4, 0xFFFFA23A.toInt()); rect(fx - 3, fy - 1, 3, 6, 0xFFFFA23A.toInt()); px(fx + 6, fy + 1, 0xFF000000.toInt())
                    }
                }
            }
            // suelo
            rect(0, GROUND, GW, GH - GROUND, P.ground)
            rect(0, GROUND, GW, 2, P.topG)
            var x = -16
            while (x < GW + 16) {
                val xx = x - o3 % 16
                rect(xx, GROUND + 3, 1, 10, P.dark); rect(xx + 4, GROUND + 8, 1, 5, P.dark)
                x += 8
            }
            rect(0, GROUND + 13, GW, 1, P.dark)
            rect(0, GROUND + 14, GW, GH - GROUND - 14, mix(P.dark, 0xFF000000.toInt(), 0.4f))
            if (W == 9) { // rieles y vagoneta
                rect(0, GROUND + 2, GW, 2, 0xFFB8B8C8.toInt()); rect(0, GROUND + 8, GW, 2, 0xFF8888A0.toInt())
                var rx = -14
                while (rx < GW + 14) { rect(rx - o3 % 14, GROUND + 4, 5, 4, 0xFF8A5A2A.toInt()); rx += 14 }
                val cx0 = 112 + (sin(t / 700.0) * 2).toInt()
                rect(cx0, GROUND - 20, 36, 18, 0xFF8A8AA0.toInt()); rect(cx0, GROUND - 20, 36, 3, 0xFFC0C0D4.toInt())
                rect(cx0 + 6, GROUND - 25, 12, 6, 0xFFD07A3A.toInt()); rect(cx0 + 22, GROUND - 24, 9, 5, 0xFFFFD23F.toInt())
                rect(cx0 + 5, GROUND - 3, 9, 9, 0xFF2A2A34.toInt()); rect(cx0 + 22, GROUND - 3, 9, 9, 0xFF2A2A34.toInt())
            }
            if (W == 11) { // niebla por delante
                for (fy in intArrayOf(GROUND - 34, GROUND - 18)) {
                    var fx = -10 - o2 % 26
                    while (fx < GW) { rect(fx, fy, 22, 5, alpha(0xFFB070A8.toInt(), 0.27f)); fx += 26 }
                }
            }
        }

        private fun hillsDraw(o1: Int, o2: Int) {
            for (x in 0 until GW) {
                val h1 = far[(x + o1) % far.size]; rect(x, GROUND - h1, 1, h1, P.far)
                val h2 = near[(x + o2) % near.size]; rect(x, GROUND - h2, 1, h2, P.near)
            }
        }

        // ---------- efectos de la letra ----------
        private fun drawFxBack(t: Long) {
            val a = fxa["sun"] ?: 0f
            if (a > 0.05f) {
                for (k in 0 until 8) {
                    val ang = k * PI / 4 + t / 2000.0
                    var r = 30
                    while (r < 70) { rect(150 + cos(ang) * r, 40 + sin(ang) * r, 2, 2, alpha(0xFFFFF1A8.toInt(), 0.55f * a)); r += 3 }
                }
                rect(0, 0, GW, GH, alpha(0xFFFFE8A0.toInt(), 0.10f * a))
            }
        }

        private fun drawFxFront(t: Long) {
            (fxa["rain"] ?: 0f).let { a ->
                if (a > 0.05f) {
                    rect(0, 0, GW, GH, alpha(0xFF203048.toInt(), 0.28f * a))
                    for (k in 0 until (70 * a).toInt()) {
                        val x = ((k * 37 + (t * 0.03).toInt()) % (GW + 30)) - 15
                        val y = ((k * 53 + (t * 0.5 * (1 + (k % 3) * 0.3)).toInt()) % (GH + 10)) - 10
                        rect(x - y / 20, y, 1, 7, 0xDDC8E4FF.toInt())
                    }
                    for (k in 0 until (6 * a).toInt()) {
                        val sx = (k * 31 + (t / 80).toInt()) % GW
                        if ((t / 120 + k) % 3 == 0L) rect(sx - 1, GROUND - 1, 3, 1, 0xDDC8E4FF.toInt())
                    }
                }
            }
            (fxa["snow"] ?: 0f).let { a ->
                if (a > 0.05f) for (k in 0 until (40 * a).toInt()) {
                    val x = Math.floorMod(k * 41 + (sin(t / 500.0 + k) * 6).toInt(), GW)
                    val y = ((k * 29 + (t * 0.04 * (1 + k % 3)).toInt()) % GH)
                    val s = if (k % 3 == 0) 2 else 1
                    rect(x, y, s, s, 0xEEFFFFFF.toInt())
                }
            }
            (fxa["fire"] ?: 0f).let { a ->
                if (a > 0.05f) {
                    var x = 0
                    while (x < GW) {
                        val hh = ((10 + 10 * sin(x * 0.7 + t / 90.0) + 6 * sin(x * 0.23 - t / 130.0)) * a).toInt()
                        rect(x, GROUND - hh, 3, hh, 0xCCFF5A1F.toInt()); rect(x, GROUND - hh / 2, 3, hh / 2, 0xDDFFC23A.toInt())
                        x += 3
                    }
                    for (k in 0 until (14 * a).toInt()) {
                        val ex = Math.floorMod(k * 23 + (sin(t / 300.0 + k) * 8).toInt(), GW)
                        val ey = GROUND - ((k * 31 + (t * 0.06).toInt()) % 120)
                        px(ex, ey, 0xFFFFD23F.toInt())
                    }
                }
            }
            (fxa["love"] ?: 0f).let { a ->
                if (a > 0.05f) for (k in 0 until (9 * a).toInt()) {
                    val x = Math.floorMod(k * 47 + (sin(t / 600.0 + k) * 10).toInt(), GW - 10)
                    val y = GH - ((k * 61 + (t * 0.05).toInt()) % (GH + 20))
                    heart(x, y, 0xEEFF4D8D.toInt())
                }
            }
            (fxa["money"] ?: 0f).let { a ->
                if (a > 0.05f) for (k in 0 until (14 * a).toInt()) {
                    val x = (k * 29) % GW; val y = ((k * 43 + (t * 0.12).toInt()) % GH)
                    rect(x, y, 4, 4, 0xFFFFD23F.toInt()); px(x + 1, y + 1, 0xFFFFF4B0.toInt())
                }
            }
            (fxa["party"] ?: 0f).let { a ->
                if (a > 0.05f) {
                    val cols = intArrayOf(0xFFFF4FD8.toInt(), 0xFF2EE6FF.toInt(), 0xFFFFD23F.toInt(), 0xFF3DDC84.toInt())
                    val k = ((t / 230) % 4).toInt()
                    rect(0, 0, GW, GH, alpha(cols[k], 0.14f * a))
                    for (b in 0 until 4) {
                        val ang = sin(t / 380.0 + b * 1.6) * 0.9
                        var r = 0
                        while (r < 260) { rect(GW / 2 + b * 6 - 9 + sin(ang) * r, 26 + r, 3 + r / 40, 4, alpha(cols[(k + b) % 4], 0.30f * a)); r += 4 }
                    }
                    rect(GW / 2 - 6, 24, 12, 8, 0xFFB8B8C8.toInt())
                    rect(GW / 2 - 4, 26, 8, 4, if ((t / 120) % 2 != 0L) -1 else 0xFFDDDDEE.toInt())
                }
            }
            (fxa["stars"] ?: 0f).let { a ->
                if (a > 0.05f) {
                    val k = ((t / 900) % 6).toInt(); val pr = (t % 900) / 900f
                    if (pr < 0.5f) {
                        val x0 = 20 + k * 25; val y0 = 10 + k * 7
                        for (j in 0 until 8) px(x0 + pr * 140 - j * 2, y0 + pr * 60 - j, alpha(-1, 1f - j / 8f))
                    }
                }
            }
        }

        // ---------- avatar ----------
        private val AV_BODY = arrayOf(
            "...KKKKKK...", "..KPPPPPPK..", ".KPYPPYPPPK.", ".KPYYPYPPPK.", ".KPYPYYPPPK.", ".KPYPPYPPPK.", "KYYYYYYYYYYK",
            ".KSSSSSSSK..", ".KSWKSSWKSK.", ".KSSSSSSSSK.", "..KSSKKSSK..", "..KKBBBBKK..", ".KBBBYYBBBK.", ".KSBBBBBBSK."
        )
        private val AV_PAL = mapOf(
            'K' to 0xFF140E36.toInt(), 'P' to 0xFF5B2BB5.toInt(), 'Y' to 0xFFFFD21F.toInt(), 'S' to 0xFFE8B48A.toInt(),
            'W' to 0xFFFFFFFF.toInt(), 'B' to 0xFF2A1F78.toInt(), 'D' to 0xFF3A3A5A.toInt()
        )

        private val OUTFITS = arrayOf(
            intArrayOf(0xFF5B2BB5.toInt(), 0xFFFFD21F.toInt(), 0xFF2A1F78.toInt(), 0xFF3A3A5A.toInt()), // NEAR de siempre
            intArrayOf(0xFFE0303A.toInt(), 0xFFFFFFFF.toInt(), 0xFF1B1B2F.toInt(), 0xFF3A5A9A.toInt()),
            intArrayOf(0xFF1FA89A.toInt(), 0xFFFF7AB8.toInt(), 0xFF0E5D5A.toInt(), 0xFF2A2A3A.toInt()),
            intArrayOf(0xFF1B1B2F.toInt(), 0xFFFFC23A.toInt(), 0xFF2B2B30.toInt(), 0xFF1B1B2F.toInt()),
            intArrayOf(0xFF2E9B4A.toInt(), 0xFFFF8A3D.toInt(), 0xFF1F5A2E.toInt(), 0xFF5A4A3A.toInt()),
            intArrayOf(0xFFFF6FB0.toInt(), 0xFFFFFFFF.toInt(), 0xFF8B5CF6.toInt(), 0xFF3A2A5A.toInt()),
            intArrayOf(0xFF2F7CF6.toInt(), 0xFF7FFFFF.toInt(), 0xFF1A2F6A.toInt(), 0xFF2A3A5A.toInt()),
            intArrayOf(0xFFFF8A3D.toInt(), 0xFF1B1B2F.toInt(), 0xFF6B4423.toInt(), 0xFF3A2A1A.toInt())
        )
        private val GOLD = intArrayOf(0xFFFFC23A.toInt(), 0xFFFFF4B0.toInt(), 0xFFE0A800.toInt(), 0xFFB8860B.toInt())

        /** Colores del personaje ahora mismo (traje, o dorado en los subidones). */
        private fun avPal(): Map<Char, Int> {
            val o = OUTFITS[outfit]
            val k = golden
            fun g(i: Int) = if (k > 0.05f) mix(o[i], GOLD[i], k) else o[i]
            return mapOf('K' to 0xFF140E36.toInt(), 'P' to g(0), 'Y' to g(1), 'S' to 0xFFE8B48A.toInt(), 'W' to -1, 'B' to g(2), 'D' to g(3),
                'R' to 0xFFE0303A.toInt(), 'T' to 0xFF7FD4FF.toInt())
        }

        /** Cara: normal, feliz, triste, ojos de estrella (subidón) o seria (pelea). */
        private fun face(): Pair<String, String> = when {
            golden > 0.5f -> ".KSYKSSYKSK." to "..KSRRRRSK.."
            ST == 4 -> ".KSKKSSKKSK." to "..KSSKKSSK.."
            job.mood < 0 -> ".KSWKSSWKSK." to "..KSKSSKSK.."
            job.mood > 0 -> ".KSKSSSSKSK." to "..KSRRRRSK.."
            else -> ".KSWKSSWKSK." to "..KSSKKSSK.."
        }

        private var curT = 0L
        private var goldT = -1
        private var curFrame = 0
        private var shake = 0

        /** Huevo de pascua: la imagen escondida en algo del escenario, que pasa una sola vez. */
        private fun drawEgg(f: Int) {
            val img = job.egg ?: return
            val total = (job.durMs * FPS / 1000).toInt()
            val f0 = (total * 0.18f).toInt(); val f1 = (total * 0.9f).toInt()
            if (f < f0 || f > f1) return
            val pr = (f - f0).toFloat() / (f1 - f0)
            val x = (GW + 8 - pr * (GW + 70)).toInt()
            val K = 0xFF140E36.toInt()
            fun pic(px0: Int, py0: Int, tv: Boolean) {
                c.drawBitmap(img, null, android.graphics.Rect(px0, py0, px0 + 24, py0 + 18), p)
                if (tv) { var yy = py0; while (yy < py0 + 18) { rect(px0, yy, 24, 1, 0x33000000); yy += 2 } ; rect(px0, py0, 24, 1, 0x55FFFFFF) }
            }
            when (W) {
                1 -> { // avioneta con pancarta
                    val y = 214 + (sin(f / 12.0) * 2).toInt()
                    sprite(arrayOf("...KK.....", "..KRRK....", "KKRRRRKKK.", "KRRWWRRRRK", "KKRRRRKKK.", "..KRRK....", "...KK....."),
                        mapOf('K' to K, 'R' to 0xFFE0303A.toInt(), 'W' to 0xFFBFE6FF.toInt()), x, y, 1)
                    if ((f / 2) % 2 == 0) rect(x - 1, y + 1, 1, 5, 0xFFDDDDDD.toInt())
                    rect(x + 10, y + 3, 6, 1, 0xFF888888.toInt())
                    rect(x + 16, y - 6, 28, 22, K); rect(x + 17, y - 5, 26, 20, -1)
                    pic(x + 18, y - 4, false)
                }
                2 -> { // valla luminosa sobre un edificio
                    val y = GROUND - 62
                    rect(x + 4, y + 22, 2, 12, 0xFF444455.toInt()); rect(x + 22, y + 22, 2, 12, 0xFF444455.toInt())
                    val glow = if ((f / 6) % 2 == 0) 0xFFFF4FD8.toInt() else 0xFF2EE6FF.toInt()
                    rect(x - 1, y - 1, 30, 24, glow); rect(x, y, 28, 22, K)
                    pic(x + 2, y + 2, false)
                }
                4 -> { // tele flotando en el espacio
                    val y = 206 + (sin(f / 15.0) * 4).toInt()
                    rect(x + 8, y - 6, 1, 6, 0xFFAAAAAA.toInt()); rect(x + 20, y - 6, 1, 6, 0xFFAAAAAA.toInt())
                    rect(x - 2, y - 2, 34, 24, 0xFF6A6A82.toInt()); rect(x - 1, y - 1, 32, 22, 0xFF3A3A4A.toInt())
                    rect(x + 27, y + 4, 2, 2, 0xFFFF4D6D.toInt()); rect(x + 27, y + 9, 2, 2, 0xFFFFD23F.toInt())
                    pic(x + 1, y + 1, true)
                }
                5 -> { // cartel de "se busca" en el muro
                    val y = GROUND - 50
                    rect(x - 6, y - 9, 40, 34, 0xFFE8D2A0.toInt()); rect(x - 6, y - 9, 40, 1, 0xFFB8986A.toInt()); rect(x - 6, y + 24, 40, 1, 0xFFB8986A.toInt())
                    font.draw(c, "WANTED", x - 3, y - 7, 0xFF6B4423.toInt(), 1, 0)
                    rect(x + 1, y + 1, 26, 20, K)
                    pic(x + 2, y + 2, false)
                }
                7 -> { // tele vieja en el fondo del mar
                    val y = GROUND - 26
                    rect(x - 2, y - 2, 34, 26, 0xFF5A3A22.toInt()); rect(x - 1, y - 1, 32, 22, 0xFF2A1A10.toInt())
                    rect(x + 4, y + 24, 3, 2, 0xFF2A1A10.toInt()); rect(x + 23, y + 24, 3, 2, 0xFF2A1A10.toInt())
                    pic(x + 1, y + 1, true)
                    for (k in 0 until 3) px(x + 10 + k * 5, y - 4 - ((f / 3 + k * 7) % 30), 0xAAFFFFFF.toInt())
                }
                else -> { // valla en un poste
                    val y = GROUND - 46
                    rect(x + 13, y + 22, 3, 24, 0xFF5A3A22.toInt())
                    rect(x - 1, y - 1, 30, 24, K); rect(x, y, 28, 22, 0xFFF4F4F4.toInt())
                    pic(x + 2, y + 2, false)
                }
            }
        }

        private fun avatar(x: Int, y: Int, step: Int, pn: Int = 0) {
            val legs = if (step == 0) arrayOf("..KDDKKDDK..", "..KKK..KKK..") else arrayOf(".KDDK..KDDK.", ".KKK....KKK.")
            val t = curT
            // aura: dorada en los subidones, de fuego si la letra habla de fuego
            val fire = fxa["fire"] ?: 0f
            if (golden > 0.1f || fire > 0.3f) {
                val cols = if (golden >= fire) intArrayOf(0xFFFFE17A.toInt(), 0xFFFFC23A.toInt(), -1) else intArrayOf(0xFFFF7A3D.toInt(), 0xFFFFC23A.toInt(), 0xFFE0303A.toInt())
                for (k in 0 until 16) {
                    val ax = x - 3 + (k * 7 + (t / 45).toInt()) % 30
                    val ay = y + 32 - ((t / 22 + k * 9) % 38).toInt()
                    rect(ax, ay, 1, 2 + k % 2, alpha(cols[k % 3], 0.85f))
                }
            }
            rect(x + 4, y + 32, 16, 2, 0x55000000)
            val (eyes, mouth) = face()
            val body = AV_BODY.copyOf()
            body[8] = eyes
            body[10] = mouth
            sprite(body + legs, avPal(), x, y, 2)
            if (job.mood < 0 && golden < 0.3f) { // lagrimita
                if ((t / 700) % 3 != 0L) px(x + 16, y + 19 + ((t / 120) % 4).toInt(), 0xFF7FD4FF.toInt())
            }
            // corazón encima si la letra habla de amor; nubecita con lluvia si está triste
            if ((fxa["love"] ?: 0f) > 0.4f) heart(x + 8, y - 12 + (sin(t / 250.0) * 2).toInt(), 0xFFFF4D8D.toInt())
            else if (job.mood < 0 && golden < 0.3f && W != 7) {
                val cy = y - 14
                rect(x + 3, cy + 2, 18, 5, 0xFF8A93A8.toInt()); rect(x + 6, cy, 10, 3, 0xFF8A93A8.toInt()); rect(x + 4, cy + 6, 16, 1, 0xFF6A7388.toInt())
                for (k in 0 until 3) px(x + 6 + k * 5, cy + 8 + ((t / 90 + k * 3) % 8).toInt(), 0xFF7FD4FF.toInt())
            }
            when (W) {
                1 -> { rect(x + 4, y + 16, 16, 3, 0xFF111111.toInt()); rect(x + 12, y + 16, 1, 2, 0xFF111111.toInt()) }
                3 -> { rect(x + 4, y + 22, 18, 3, 0xFFE0303A.toInt()); rect(x + 16, y + 24, 3, 6, 0xFFE0303A.toInt()) }
                4 -> {
                    for (j in 0 until 16) rect(x - 1 + (if (j == 0 || j == 15) 1 else 0), y - 2 + (j * 1.4f).toInt(), 26 - (if (j == 0 || j == 15) 2 else 0), 1, 0x33BFE6FF)
                    rect(x + 2, y - 3, 20, 1, 0x88FFFFFF.toInt())
                }
                5 -> {
                    val gd = 0xFFFFD23F.toInt()
                    rect(x + 6, y - 6, 12, 4, gd); px(x + 6, y - 8, gd); px(x + 11, y - 9, gd); px(x + 17, y - 8, gd); px(x + 11, y - 5, 0xFFFF4D6D.toInt())
                }
                7 -> { rect(x + 2, y + 14, 20, 7, 0x6688E8FF); rect(x + 2, y + 14, 20, 1, 0xFF1B1B2F.toInt()) }
            }
            if (pn > 0) { rect(x + 22, y + 22, 8 + pn, 5, 0xFF2A1F78.toInt()); rect(x + 28 + pn, y + 21, 6, 7, 0xFFE8B48A.toInt()) }
        }

        private fun burst(x: Float, y: Float, col: Int, n: Int) {
            for (k in 0 until n) {
                val a = rnd.f() * 6.28f; val v = 1f + rnd.f() * 2.5f
                parts.add(Part(x, y, cos(a) * v, sin(a) * v - 1f, 14 + rnd.i(8), col, null))
            }
        }

        private fun popup(txt: String, x: Float, y: Float, col: Int = 0xFFFFD23F.toInt()) {
            parts.add(Part(x, y, 0f, -0.7f, 20, col, txt))
        }

        // ---------- estilos de juego ----------
        private fun action(t: Long, f: Int, e: Float, on: Boolean) {
            val baseY = GROUND - 32
            when (ST) {
                0 -> { // plataformas
                    if (on) { jump = 12; coins.add(floatArrayOf((GW + 4).toFloat(), (GROUND - 26 - rnd.i(14)).toFloat())) }
                    var jy = 0
                    if (jump > 0) { val pr = (12 - jump) / 12f; jy = (sin(pr * PI) * 16).toInt(); jump-- }
                    for (cn in coins) cn[0] -= 1.6f + e * 1.4f
                    val iter = coins.iterator()
                    while (iter.hasNext()) {
                        val cn = iter.next()
                        if (cn[0] < 38 && abs(cn[1] - (baseY + 10 - jy)) < 26) {
                            score += 100; burst(cn[0], cn[1], 0xFFFFD23F.toInt(), 6); popup("+100", cn[0], cn[1] - 6); iter.remove()
                        } else if (cn[0] <= -6) iter.remove()
                    }
                    for (cn in coins) {
                        val x = cn[0].toInt(); val y = cn[1].toInt(); val spin = ((t / 120 + x) % 4).toInt()
                        if (spin == 0 || spin == 2) {
                            rect(x + 1, y, 4, 6, 0xFF000000.toInt()); rect(x, y + 1, 6, 4, 0xFF000000.toInt()); rect(x + 1, y + 1, 4, 4, 0xFFFFD23F.toInt()); rect(x + 2, y + 2, 1, 2, 0xFFFFF4B0.toInt())
                        } else { rect(x + 2, y, 2, 6, 0xFF000000.toInt()); rect(x + 2, y + 1, 2, 4, 0xFFFFD23F.toInt()) }
                    }
                    avatar(14, baseY - jy, (f / maxOf(3, (9 - e * 6).toInt())) % 2)
                }
                1 -> { // nave
                    val sy = 246 + (sin(t / 380.0) * 6).toInt() - (e * 6).toInt()
                    if (on || (e > 0.6f && f % 10 == 0)) shots.add(floatArrayOf(40f, (sy + 5).toFloat()))
                    if (on && rnd.f() < 0.8f) enemies.add(floatArrayOf((GW + 6).toFloat(), (236 + rnd.i(30)).toFloat(), rnd.i(2).toFloat()))
                    if (f % 45 == 0) enemies.add(floatArrayOf((GW + 6).toFloat(), (236 + rnd.i(30)).toFloat(), rnd.i(2).toFloat()))
                    for (s in shots) s[0] += 6f
                    for (en in enemies) { en[0] -= 1.2f + e * 1.5f; en[1] += (sin((t + en[0] * 40) / 300.0) * 0.6).toFloat() }
                    val iter = enemies.iterator()
                    while (iter.hasNext()) {
                        val en = iter.next()
                        val hit = shots.firstOrNull { abs(it[0] - en[0]) < 8 && abs(it[1] - (en[1] + 4)) < 7 }
                        if (hit != null) {
                            shots.remove(hit); score += 250
                            burst(en[0] + 4, en[1] + 4, 0xFFFF7A3D.toInt(), 10); burst(en[0] + 4, en[1] + 4, 0xFFFFD23F.toInt(), 6); popup("+250", en[0], en[1] - 4)
                            iter.remove()
                        } else if (en[0] <= -12) iter.remove()
                    }
                    shots.removeAll { it[0] >= GW + 8 }
                    for (s in shots) { rect(s[0], s[1], 6, 2, 0xFF7FFFFF.toInt()); rect(s[0] + 4, s[1], 2, 2, -1) }
                    val inv = arrayOf(
                        arrayOf("..K....K..", "...K..K...", "..KKKKKK..", ".KK.KK.KK.", "KKKKKKKKKK", "K.KKKKKK.K", "K.K....K.K", "...KK.KK.."),
                        arrayOf("...KKKK...", ".KKKKKKKK.", "KKK.KK.KKK", "KKKKKKKKKK", "..KK..KK..", ".KK.KK.KK.", "KK......KK", "..........")
                    )
                    for (en in enemies) {
                        val k = en[2].toInt().coerceIn(0, 1)
                        val rows = if ((t / 250) % 2 == 0L) inv[k] else Array(inv[k].size) { inv[k][it].reversed() }
                        sprite(rows, mapOf('K' to hsv(hue + 150 + k * 60, 0.7f, 0.95f)), en[0].toInt(), en[1].toInt(), 1)
                    }
                    val ship = arrayOf("....KK......", "...KWWK.....", "KKKKWWKKK...", "KPPPPPPPPKK.", "KPYYYPPPPPWK", "KPPPPPPPPKK.", "KKKKWWKKK...", "...KWWK.....", "....KK......")
                    val flame = 2 + (f % 3) + (e * 3).toInt()
                    rect(14 - flame, sy + 3, flame, 3, 0xFFFF7A3D.toInt()); rect(14 - flame / 2, sy + 4, flame / 2, 1, 0xFFFFE17A.toInt())
                    val ap = avPal()
                    sprite(ship, mapOf('K' to 0xFF140E36.toInt(), 'P' to (ap['P'] ?: 0xFF5B2BB5.toInt()), 'Y' to (ap['Y'] ?: 0xFFFFD21F.toInt()), 'W' to 0xFFBFE6FF.toInt()), 14, sy, 2)
                    if (golden > 0.3f) for (k in 0 until 6) px(10 + (k * 5 + (curT / 30).toInt()) % 30, sy + (k * 3) % 18, 0xFFFFE17A.toInt())
                }
                2 -> { // carrera
                    rect(0, 244, GW, 28, 0xFF3A3A48.toInt()); rect(0, 244, GW, 2, 0xFFDDDDDD.toInt()); rect(0, 270, GW, 2, 0xFFDDDDDD.toInt())
                    val spd = 4f + e * 6f
                    roadScroll += spd
                    var x = -20
                    while (x < GW + 20) { rect(x - roadScroll.toInt() % 20, 257, 10, 2, 0xFFFFD23F.toInt()); x += 20 }
                    if (on) lane = 1 - lane
                    if (f % 40 == 0 || (on && rnd.f() < 0.4f)) cones.add(floatArrayOf((GW + 6).toFloat(), (1 - lane).toFloat()))
                    laneY += (lane - laneY) * 0.25f
                    val ky = 247 + (laneY * 12).toInt()
                    for (cn in cones) cn[0] -= spd
                    cones.removeAll { it[0] <= -10 }
                    for (cn in cones) {
                        val cy = 249 + cn[1].toInt() * 12; val cx = cn[0]
                        rect(cx + 2, cy, 2, 2, 0xFFFF7A1F.toInt()); rect(cx + 1, cy + 2, 4, 2, -1); rect(cx, cy + 4, 6, 3, 0xFFFF7A1F.toInt())
                    }
                    if (e > 0.55f) for (k in 0 until 6) rect(Math.floorMod(k * 37 - (roadScroll * 2).toInt(), GW), 238 + k * 6, 14, 1, 0x88FFFFFF.toInt())
                    val kart = arrayOf("....KKKK....", "...KPPPPK...", "KKKPPYYPPKK.", "KPPPPPPPPPPK", "KKKKKKKKKKKK", ".KDK....KDK.", ".KKK....KKK.")
                    val ap = avPal()
                    sprite(arrayOf("...KKKKKK...", "..KPPPPPPK..", ".KPYPPYPPPK.", "KYYYYYYYYYYK", ".KSWKSSWKSK.", ".KSSSSSSSSK."), ap, 18, ky - 10, 1)
                    sprite(kart, mapOf('K' to 0xFF140E36.toInt(), 'P' to (ap['B'] ?: 0xFFE0303A.toInt()), 'Y' to (ap['Y'] ?: 0xFFFFD21F.toInt()), 'D' to 0xFF888888.toInt()), 14, ky - 4, 2)
                    if (on && e > 0.6f) popup("NITRO!", 62f, 228f, 0xFF2EE6FF.toInt())
                }
                3 -> { // aventura RPG desde arriba
                    val g0 = if (W == 3 || W == 6 || W == 1 || W == 7) P.topG else mix(P.near, P.topG, 0.35f)
                    rect(0, GROUND - 34, GW, GH - GROUND + 34, g0)
                    for (k in 0 until 70) {
                        val gx = (k * 47 + k * k * 3) % GW; val gy = GROUND - 32 + (k * 29) % 76
                        rect(gx, gy, 2, 1, mix(g0, 0xFF000000.toInt(), 0.18f)); px(gx + 1, gy - 1, mix(g0, -1, 0.25f))
                    }
                    val path = mix(P.dark, g0, 0.3f)
                    for (x in 0 until GW) {
                        val py = GROUND - 2 + (sin(x / 22.0) * 5).toInt()
                        rect(x, py, 1, 10, path); px(x, py, mix(path, 0xFF000000.toInt(), 0.2f)); px(x, py + 9, mix(path, 0xFF000000.toInt(), 0.2f))
                    }
                    for (k in 0 until 4) {
                        val tx = (k * 53 + 12) % GW; val ty = GROUND - 30 + (k % 2) * 46
                        val tc = when (W) { 3 -> 0xFF2F6B55.toInt(); 4 -> 0xFF6A6A82.toInt(); 7 -> 0xFF1F7A4A.toInt(); else -> 0xFF2E8B3E.toInt() }
                        rect(tx + 3, ty + 10, 4, 4, 0xFF5A3A22.toInt()); rect(tx, ty, 10, 11, tc); rect(tx + 2, ty - 2, 6, 2, tc); px(tx + 2, ty + 2, mix(tc, -1, 0.3f))
                    }
                    if (on && chests.size < 4) chests.add(intArrayOf(30 + rnd.i(120), GROUND - 22 + rnd.i(30), 0))
                    for (ch in chests) {
                        ch[2]++
                        val x = ch[0]; val y = ch[1]
                        rect(x, y, 10, 8, 0xFF8A5A2A.toInt()); rect(x, y + 3, 10, 1, 0xFFFFD23F.toInt())
                        if (ch[2] < 8) rect(x, y - 2, 10, 3, 0xFF6B4423.toInt())
                        else if (ch[2] < 30) {
                            rect(x, y - 5, 10, 3, 0xFF6B4423.toInt())
                            if (ch[2] == 8) { burst(x + 5f, y.toFloat(), 0xFFFFD23F.toInt(), 8); score += 300; popup("+300", x.toFloat(), y - 10f) }
                        }
                    }
                    chests.removeAll { it[2] >= 40 }
                    val ax = 90 + (sin(t / 900.0) * 60).toInt(); val ay = GROUND - 10 + (sin(t / 450.0) * 12).toInt()
                    val step = (f / 6) % 2
                    val top = arrayOf("..KKKKKK..", ".KPPPPPPK.", "KPPYYYYPPK", "KYYYYYYYYK", ".KSSSSSSK.", ".KSKSSKSK.", "..KBBBBK..", ".KBBYYBBK.", ".KSBBBBSK.",
                        if (step == 1) "..KD..DK.." else ".KD....DK.", if (step == 1) "..KK..KK.." else ".KK....KK.")
                    rect(ax + 2, ay + 22, 16, 2, 0x55000000)
                    sprite(top, avPal(), ax, ay, 2)
                    val sl = 40 + ((t / 30) % 120).toInt()
                    val hop = abs((sin(t / 150.0) * 4).toInt())
                    sprite(arrayOf("..GGGG..", ".GGGGGG.", "GGWGGWGG", "GGKGGKGG", "GGGGGGGG"), mapOf('G' to 0xFF46E07A.toInt(), 'W' to -1, 'K' to 0xFF000000.toInt()), ((sl * 1.3f) % GW).toInt(), GROUND + 8 - hop, 2)
                }
                else -> { // pelea arcade
                    val ex = 112; val ey = baseY - 2
                    if (on) {
                        punch = 6; hits++; combo++; ehp = maxOf(0f, 1f - hits.toFloat() / totalOn * 1.05f)
                        burst(ex + 2f, ey + 14f, -1, 8); burst(ex + 2f, ey + 14f, 0xFFFFD23F.toInt(), 6); score += 120 * combo
                        popup(arrayOf("POW!", "BAM!", "ZAS!", "PUM!")[hits % 4], ex - 4f, ey - 6f)
                        hurt = 6
                    } else if (f % 50 == 0) combo = 0
                    var pn = 0
                    if (punch > 0) { pn = punch; punch-- }
                    val mon = arrayOf("...KKKKKKKK...", "..KMMMMMMMMK..", ".KMMWWMMWWMMK.", ".KMMWKMMWKMMK.", ".KMMMMMMMMMMK.", ".KMMKKKKKKMMK.", ".KMMKTTTTKMMK.",
                        "..KMMMMMMMMK..", ".KKMMMMMMMMKK.", "KMMKMMMMMMKMMK", "KMMKMMMMMMKMMK", ".KKKMMMMMMKKK.", "...KMMKKMMK...", "...KKK..KKK...")
                    val mc = hsv(hue + 180, 0.65f, 0.75f)
                    val shake = if (hurt % 2 == 1) 2 else 0
                    if (hurt > 0) hurt--
                    rect(ex + 2, baseY + 30, 24, 2, 0x55000000)
                    sprite(mon, mapOf('K' to 0xFF140E36.toInt(), 'M' to (if (hurt > 0) -1 else mc), 'W' to -1, 'T' to -1), ex + shake, ey + 4, 2)
                    avatar(56, baseY, (f / 8) % 2, pn)
                    font.draw(c, "NEAR", 6, 238, -1, 1, 0xFF000000.toInt()); font.draw(c, "JEFE", GW - 30, 238, -1, 1, 0xFF000000.toInt())
                    rect(32, 239, 50, 6, 0xFF000000.toInt()); rect(33, 240, 48, 4, 0xFF46E07A.toInt())
                    rect(GW - 84, 239, 50, 6, 0xFF000000.toInt()); rect(GW - 83 + (48 * (1 - ehp)).toInt(), 240, (48 * ehp).toInt(), 4, 0xFFFF4D6D.toInt())
                    if (combo >= 2) { val ct = "COMBO X$combo"; font.draw(c, ct, (GW - font.width(ct)) / 2, 222, 0xFF2EE6FF.toInt(), 1, 0xFF000000.toInt()) }
                    if (ehp <= 0.02f) font.draw(c, "K.O.!", 66, 196, 0xFFFFD23F.toInt(), 2, 0xFF000000.toInt())
                }
            }
        }

        /** Línea de la letra que suena en songT. */
        private fun lineAt(songT: Long): Int {
            var i = -1
            for (k in job.lines.indices) if (job.lines[k].first <= songT + 60) i = k else break
            return i
        }

        fun draw(f: Int) {
            val t = f * 1000L / FPS
            val songT = job.startMs + t
            val e = if (job.energy.isEmpty()) 0.5f else job.energy[f.coerceIn(0, job.energy.size - 1)]
            val on = f < job.onsets.size && job.onsets[f]
            val i = lineAt(songT)
            val txt = if (i >= 0) job.lines[i].second.trim() else ""
            curT = t
            curFrame = f
            val want = fxOf(txt)
            for (k in FX_WORDS.keys) {
                val cur = fxa[k] ?: 0f
                var goal = if (k in want) 1f else 0f
                if (k == "night") goal = maxOf(goal, nightBase)
                if (k == "rain") goal = maxOf(goal, rainBase)
                fxa[k] = cur + (goal - cur) * 0.08f
            }
            val speed = (if (job.calm) 14f else 26f) * (0.7f + e * 0.9f)
            worldScroll += speed / FPS
            if (on) flash = maxOf(flash, if (job.calm) 0.07f else 0.16f)
            val hype = f < job.ana.hype.size && job.ana.hype[f]
            val wasGold = golden
            golden += ((if (hype) 1f else 0f) - golden) * 0.12f
            if (wasGold < 0.5f && golden >= 0.5f && goldT < 0) goldT = f
            // drop: el escenario y el personaje se transforman
            if (job.world2 >= 0 && f == job.ana.drop) {
                W = job.world2; P = palette(); outfit = job.outfit2; transT = f; flash = 0.9f
                for (k in 0 until 3) burst(30f + k * 60, 240f, intArrayOf(0xFFFFD23F.toInt(), 0xFFFF4FD8.toInt(), 0xFF2EE6FF.toInt())[k], 14)
            }
            // rimas: cuando la línea nueva rima con la anterior
            if (i != lastLine) {
                lastLine = i
                if (i >= 0 && i < job.rhymes.size && job.rhymes[i]) {
                    rhymeStreak++; rhymeT = f
                    popup(if (rhymeStreak > 1) "RIMA X$rhymeStreak" else "¡RIMA!", 112f, 132f, 0xFF7FFFFF.toInt())
                    for (k in 0 until 2) burst(150f - k * 120, 160f, if (k == 0) 0xFF7FFFFF.toInt() else 0xFFFFD23F.toInt(), 8)
                } else rhymeStreak = 0
            }
            // bajo fuerte: onda en el suelo y la pantalla tiembla
            val bassHit = f < job.ana.bassHits.size && job.ana.bassHits[f]
            if (bassHit) { rings.add(floatArrayOf(if (ST == 3) 100f else 30f, 4f)); shake = 3 }
            // fuegos artificiales en los subidones
            if (hype && on) {
                val fx0 = if (rnd.f() < 0.5f) 8f + rnd.f() * 38f else 134f + rnd.f() * 38f
                val fy0 = 66f + rnd.f() * 66f
                val col = intArrayOf(0xFFFFD23F.toInt(), 0xFFFF4FD8.toInt(), 0xFF2EE6FF.toInt(), 0xFF46E07A.toInt(), 0xFFFF7A3D.toInt())[rnd.i(5)]
                burst(fx0, fy0, col, 16); burst(fx0, fy0, -1, 4)
            }

            c.save()
            if (shake > 0) { c.translate(if (shake % 2 == 1) 2f else -2f, if (shake > 1) 1f else 0f); shake-- }
            drawWorld(t, worldScroll)
            drawFxBack(t)
            drawEgg(f)
            // ondas del bajo
            val ri = rings.iterator()
            while (ri.hasNext()) {
                val r = ri.next()
                r[1] += 4f
                if (r[1] > 90f) { ri.remove(); continue }
                val a = 1f - r[1] / 90f
                var k = 0
                while (k < 40) {
                    val ang = k / 40.0 * 2 * PI
                    px(r[0] + cos(ang) * r[1], GROUND + 4 + sin(ang) * r[1] / 5, alpha(if (golden > 0.3f) 0xFFFFE17A.toInt() else -1, a))
                    k++
                }
            }
            // carátula con el marco del mundo
            val cs = 72; val cx = (GW - cs) / 2
            val bounce = if (on) 3 else if (flash > 0.08f) 1 else 0
            val cy = 62 - bounce + (sin(t / 900.0) * 2).toInt()
            rect(cx + 4, cy + 4, cs + 4, cs + 4, 0x66000000)
            rect(cx - 3, cy - 3, cs + 6, cs + 6, 0xFF000000.toInt()); rect(cx - 2, cy - 2, cs + 4, cs + 4, P.frame); rect(cx - 1, cy - 1, cs + 2, cs + 2, 0xFF000000.toInt())
            if (W == 2) {
                val gl = (80 + 120 * e) / 255f
                rect(cx - 5, cy - 5, cs + 10, 2, alpha(P.frame, gl)); rect(cx - 5, cy + cs + 3, cs + 10, 2, alpha(P.frame, gl))
            }
            c.drawBitmap(cover, null, android.graphics.Rect(cx, cy, cx + cs, cy + cs), p)

            action(t, f, e, on)

            // partículas
            val iter = parts.iterator()
            while (iter.hasNext()) {
                val q = iter.next()
                q.x += q.vx; q.y += q.vy; q.life--
                if (q.txt == null) q.vy += 0.15f
                if (q.life <= 0) iter.remove()
            }
            for (q in parts) {
                if (q.txt != null) font.draw(c, q.txt, q.x.toInt(), q.y.toInt(), q.col, 1, 0xFF000000.toInt())
                else rect(q.x, q.y, 2, 2, q.col)
            }
            drawFxFront(t)
            c.restore()

            // HUD
            rect(0, 0, GW, 26, 0xB3000000.toInt())
            font.draw(c, "1UP", 5, 4, 0xFFFFD21F.toInt(), 1, 0)
            font.draw(c, "SCORE " + (score + (t / 100).toInt() * 10).toString().padStart(6, '0'), 72, 4, -1, 1, 0)
            for (k in 0 until 3) heart(5 + k * 9, 15, 0xFFFF4D6D.toInt())
            val tm = time(songT)
            font.draw(c, tm, GW - 5 - font.width(tm), 15, -1, 1, 0)
            val lvl = font.up(WORLDS[W] + ": " + job.title)
            val lw = font.width(lvl)
            rect(0, 28, GW, 13, 0x8C000000.toInt())
            if (lw <= GW - 10) font.draw(c, lvl, (GW - lw) / 2, 30, -1, 1, 0)
            else {
                val span = lw + 40; val off = ((t / 1000.0 * 28).toInt() % span)
                font.draw(c, lvl, GW - off, 30, -1, 1, 0); font.draw(c, lvl, GW - off + span, 30, -1, 1, 0)
            }
            val by = 46
            rect(0, by - 4, GW, 15, 0x8C000000.toInt())
            font.draw(c, "XP", 6, by - 1, 0xFFFFD23F.toInt(), 1, 0xFF000000.toInt())
            rect(20, by, GW - 26, 7, 0xFF000000.toInt()); rect(21, by + 1, GW - 28, 5, 0xFF2A2A44.toInt())
            val prog = if (job.songMs > 0) (songT.toDouble() / job.songMs).coerceIn(0.0, 1.0) else t.toDouble() / job.durMs
            rect(21, by + 1, ((GW - 28) * prog).toInt(), 5, 0xFF46E07A.toInt()); rect(21, by + 1, ((GW - 28) * prog).toInt(), 1, 0xFFA8FFC4.toInt())

            dialog(songT, txt, i)

            // ecualizador al pie
            for (k in 0 until 6) {
                val hh = (2 + e * 9 * (0.5 + 0.5 * sin(t / 90.0 + k * 1.7))).toInt()
                rect(8 + k * 5, GH - 3 - hh, 3, hh, if (k % 2 != 0) 0xFFFFD23F.toInt() else 0xFFFF4FD8.toInt())
                rect(GW - 11 - k * 5, GH - 3 - hh, 3, hh, if (k % 2 != 0) 0xFFFFD23F.toInt() else 0xFF2EE6FF.toInt())
            }
            font.draw(c, "NEAR MUSIC", (GW - font.width("NEAR MUSIC")) / 2, 310, 0x99FFFFFF.toInt(), 1, 0)

            if (t < 1600) {
                val tx = if (t < 1000) "READY?" else "GO!"
                if (t >= 1000 || (t / 150) % 2 == 0L) {
                    val w2 = font.width(tx) * 2
                    font.draw(c, tx, (GW - w2) / 2, cy + cs / 2 - 7, 0xFFFFD23F.toInt(), 2, 0xFF000000.toInt())
                }
            }
            // carteles de transformación
            if (transT >= 0 && f - transT < 45) {
                val a1 = "¡TRANSFORMACIÓN!"; val a2 = font.up(WORLDS[W])
                font.draw(c, a1, (GW - font.width(a1)) / 2, cy + 22, 0xFFFFD23F.toInt(), 1, 0xFF000000.toInt())
                if ((f - transT) / 4 % 2 == 0) font.draw(c, a2, (GW - font.width(a2) * 2) / 2, cy + 34, -1, 2, 0xFF000000.toInt())
            } else if (goldT >= 0 && f - goldT < 36 && t >= 1600) {
                val g1 = "¡MODO DORADO!"
                if ((f - goldT) / 3 % 2 == 0) font.draw(c, g1, (GW - font.width(g1) * 2) / 2, cy + cs / 2 - 7, 0xFFFFD23F.toInt(), 2, 0xFF000000.toInt())
            }
            if (flash > 0.01f) { rect(0, 0, GW, GH, alpha(-1, flash)); flash *= 0.6f }
        }

        private fun time(ms: Long): String {
            val s = (ms / 1000).toInt()
            return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
        }

        /** Caja de diálogo con la letra escribiéndose letra por letra. */
        private fun dialog(songT: Long, text: String, i: Int) {
            val x = 10; val y = 154; val w = GW - 20; val h = 50
            val tag = font.up(job.artist).let { if (it.length > 22) it.take(21) + "…" else it }.ifEmpty { "NEAR" }
            val tw = font.width(tag) + 10
            rect(x + 6, y - 14, tw, 15, 0xFF000000.toInt())
            rect(x + 7, y - 13, tw - 2, 13, 0xFFFFD23F.toInt())
            font.draw(c, tag, x + 11, y - 9, 0xFF140E36.toInt(), 1, 0)
            rect(x, y, w, h, 0xFF000000.toInt())
            rect(x + 1, y + 1, w - 2, h - 2, if (curFrame - rhymeT < 12) 0xFF7FFFFF.toInt() else if (golden > 0.5f) 0xFFFFD23F.toInt() else -1)
            rect(x + 3, y + 3, w - 6, h - 6, 0xFF000000.toInt())
            rect(x + 4, y + 4, w - 8, h - 8, P.box)
            val tx = x + 9; val ty = y + 8
            if (text.isEmpty()) {
                val n = ((songT / 350) % 4).toInt()
                font.draw(c, "♪ ".repeat(n + 1).trim(), tx, ty + 13, -1, 1, 0)
                return
            }
            val start = job.lines[i].first
            val shown = (((songT - start).coerceAtLeast(0L)) * 34 / 1000).toInt()
            val rows = font.wrap(font.up(text), w - 18).take(3)
            var left = shown
            var done = true
            for ((r, row) in rows.withIndex()) {
                if (left <= 0) { done = false; break }
                val part = if (left >= row.length) row else row.take(left).also { done = false }
                font.draw(c, part, tx, ty + r * 11, -1, 1, 0)
                left -= row.length + 1
            }
            if (done && (songT / 300) % 2 == 0L) {
                val ax = x + w - 14; val ay = y + h - 11; val yc = 0xFFFFD23F.toInt()
                rect(ax, ay, 5, 1, yc); rect(ax + 1, ay + 1, 3, 1, yc); rect(ax + 2, ay + 2, 1, 1, yc)
            }
        }
    }

    // =====================================================================
    // letra de juego 5x7 (mayúsculas, números, tildes y signos)
    // =====================================================================
    private class PixFont {
        private val g = HashMap<Char, Array<String>>()
        private val fallback = Paint().apply { isAntiAlias = false; textSize = 9f; color = Color.WHITE }
        private val measure = Paint().apply { isAntiAlias = false; textSize = 9f }

        init {
            fun d(ch: Char, s: String) { g[ch] = s.split(',').toTypedArray() }
            d('A', "01110,10001,10001,11111,10001,10001,10001"); d('B', "11110,10001,10001,11110,10001,10001,11110")
            d('C', "01110,10001,10000,10000,10000,10001,01110"); d('D', "11110,10001,10001,10001,10001,10001,11110")
            d('E', "11111,10000,10000,11110,10000,10000,11111"); d('F', "11111,10000,10000,11110,10000,10000,10000")
            d('G', "01110,10001,10000,10111,10001,10001,01111"); d('H', "10001,10001,10001,11111,10001,10001,10001")
            d('I', "01110,00100,00100,00100,00100,00100,01110"); d('J', "00111,00010,00010,00010,00010,10010,01100")
            d('K', "10001,10010,10100,11000,10100,10010,10001"); d('L', "10000,10000,10000,10000,10000,10000,11111")
            d('M', "10001,11011,10101,10101,10001,10001,10001"); d('N', "10001,11001,10101,10011,10001,10001,10001")
            d('O', "01110,10001,10001,10001,10001,10001,01110"); d('P', "11110,10001,10001,11110,10000,10000,10000")
            d('Q', "01110,10001,10001,10001,10101,10010,01101"); d('R', "11110,10001,10001,11110,10100,10010,10001")
            d('S', "01111,10000,10000,01110,00001,00001,11110"); d('T', "11111,00100,00100,00100,00100,00100,00100")
            d('U', "10001,10001,10001,10001,10001,10001,01110"); d('V', "10001,10001,10001,10001,10001,01010,00100")
            d('W', "10001,10001,10001,10101,10101,10101,01010"); d('X', "10001,10001,01010,00100,01010,10001,10001")
            d('Y', "10001,10001,01010,00100,00100,00100,00100"); d('Z', "11111,00001,00010,00100,01000,10000,11111")
            d('0', "01110,10001,10011,10101,11001,10001,01110"); d('1', "00100,01100,00100,00100,00100,00100,01110")
            d('2', "01110,10001,00001,00010,00100,01000,11111"); d('3', "11111,00010,00100,00010,00001,10001,01110")
            d('4', "00010,00110,01010,10010,11111,00010,00010"); d('5', "11111,10000,11110,00001,00001,10001,01110")
            d('6', "00110,01000,10000,11110,10001,10001,01110"); d('7', "11111,00001,00010,00100,01000,01000,01000")
            d('8', "01110,10001,10001,01110,10001,10001,01110"); d('9', "01110,10001,10001,01111,00001,00010,01100")
            d('.', "00000,00000,00000,00000,00000,01100,01100"); d(',', "00000,00000,00000,00000,01100,00100,01000")
            d('!', "00100,00100,00100,00100,00100,00000,00100"); d('¡', "00100,00000,00100,00100,00100,00100,00100")
            d('?', "01110,10001,00001,00010,00100,00000,00100"); d('¿', "00100,00000,00100,01000,10000,10001,01110")
            d('\'', "00100,00100,01000,00000,00000,00000,00000"); d('’', "00100,00100,01000,00000,00000,00000,00000")
            d('"', "01010,01010,00000,00000,00000,00000,00000"); d('-', "00000,00000,00000,11111,00000,00000,00000")
            d(':', "00000,01100,01100,00000,01100,01100,00000"); d(';', "00000,01100,01100,00000,01100,00100,01000")
            d('(', "00010,00100,01000,01000,01000,00100,00010"); d(')', "01000,00100,00010,00010,00010,00100,01000")
            d('/', "00001,00001,00010,00100,01000,10000,10000"); d('&', "01100,10010,10100,01000,10101,10010,01101")
            d('+', "00000,00100,00100,11111,00100,00100,00000"); d('#', "01010,01010,11111,01010,11111,01010,01010")
            d('*', "00000,00100,10101,01110,10101,00100,00000"); d('♪', "00110,00101,00100,00100,01100,11100,11000")
            d('♥', "00000,01010,11111,11111,01110,00100,00000"); d('…', "00000,00000,00000,00000,00000,00000,10101")
            d('_', "00000,00000,00000,00000,00000,00000,11111"); d('=', "00000,00000,11111,00000,11111,00000,00000")
        }

        // marcas encima: tildes, diéresis, eñe
        private val marks = mapOf(
            'Á' to ('A' to 0), 'É' to ('E' to 0), 'Í' to ('I' to 0), 'Ó' to ('O' to 0), 'Ú' to ('U' to 0),
            'À' to ('A' to 1), 'È' to ('E' to 1), 'Ì' to ('I' to 1), 'Ò' to ('O' to 1), 'Ù' to ('U' to 1),
            'Ä' to ('A' to 2), 'Ë' to ('E' to 2), 'Ï' to ('I' to 2), 'Ö' to ('O' to 2), 'Ü' to ('U' to 2),
            'Â' to ('A' to 3), 'Ê' to ('E' to 3), 'Î' to ('I' to 3), 'Ô' to ('O' to 3), 'Û' to ('U' to 3),
            'Ñ' to ('N' to 4), 'Ã' to ('A' to 4), 'Õ' to ('O' to 4)
        )
        private val markRows = arrayOf(
            arrayOf("00010", "00100"), arrayOf("01000", "00100"), arrayOf("00000", "01010"),
            arrayOf("00100", "01010"), arrayOf("01101", "10010")
        )

        fun up(s: String): String = s.uppercase(Locale("es")).replace('“', '"').replace('”', '"').replace('‘', '\'')

        private fun adv(ch: Char): Int = when {
            ch == ' ' -> 4
            g.containsKey(ch) || marks.containsKey(ch) -> 6
            else -> measure.measureText(ch.toString()).toInt().coerceAtLeast(3) + 1
        }

        fun width(s: String): Int = s.sumOf { adv(it) }.let { if (it > 0) it - 1 else 0 }

        fun wrap(s: String, maxW: Int): List<String> {
            val out = ArrayList<String>()
            var cur = ""
            for (word in s.split(' ').filter { it.isNotEmpty() }) {
                val t = if (cur.isEmpty()) word else "$cur $word"
                if (width(t) <= maxW) cur = t
                else {
                    if (cur.isNotEmpty()) out.add(cur)
                    cur = word
                    // palabra larguísima: se parte
                    while (width(cur) > maxW && cur.length > 1) {
                        var k = cur.length - 1
                        while (k > 1 && width(cur.take(k)) > maxW) k--
                        out.add(cur.take(k)); cur = cur.drop(k)
                    }
                }
            }
            if (cur.isNotEmpty()) out.add(cur)
            return out
        }

        /** y es la parte de arriba de la letra (las tildes van 2 píxeles más arriba). */
        fun draw(c: Canvas, s: String, x0: Int, y: Int, color: Int, scale: Int, shadow: Int) {
            if (shadow != 0) draw(c, s, x0 + scale, y + scale, shadow, scale, 0)
            val p = Paint().apply { isAntiAlias = false; this.color = color }
            var x = x0
            for (ch in s) {
                val m = marks[ch]
                val glyph = g[m?.first ?: ch]
                if (glyph != null) {
                    for ((j, r) in glyph.withIndex()) for ((i, b) in r.withIndex()) if (b == '1') {
                        c.drawRect((x + i * scale).toFloat(), (y + j * scale).toFloat(), (x + (i + 1) * scale).toFloat(), (y + (j + 1) * scale).toFloat(), p)
                    }
                    if (m != null) {
                        val mr = markRows[m.second]
                        for ((j, r) in mr.withIndex()) for ((i, b) in r.withIndex()) if (b == '1') {
                            c.drawRect((x + i * scale).toFloat(), (y + (j - 3) * scale).toFloat(), (x + (i + 1) * scale).toFloat(), (y + (j - 2) * scale).toFloat(), p)
                        }
                    }
                } else if (ch != ' ') {
                    fallback.color = color
                    fallback.textSize = 9f * scale
                    c.drawText(ch.toString(), x.toFloat(), (y + 7 * scale).toFloat(), fallback)
                }
                x += adv(ch) * scale
            }
        }
    }
}
