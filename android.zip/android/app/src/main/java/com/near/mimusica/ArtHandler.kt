package com.near.mimusica

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

/** Sirve las portadas a la interfaz: https://appassets.androidplatform.net/art/<id> */
class ArtHandler(private val ctx: Context) : WebViewAssetLoader.PathHandler {
    private val cache = LruCache<Long, ByteArray>(150)
    private val missing = HashSet<Long>()

    override fun handle(path: String): WebResourceResponse? {
        val id = path.substringBefore('?').substringBefore('/').toLongOrNull() ?: return notFound()
        cache.get(id)?.let { return ok(it) }
        if (synchronized(missing) { missing.contains(id) }) return notFound()
        val bytes = load(id)
        if (bytes == null) {
            synchronized(missing) { missing.add(id) }
            return notFound()
        }
        cache.put(id, bytes)
        return ok(bytes)
    }

    private fun load(id: Long): ByteArray? {
        val uri = Library.uri(id)
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val bmp = ctx.contentResolver.loadThumbnail(uri, Size(512, 512), null)
                return compress(bmp)
            } catch (e: Exception) {
                // sin portada en la miniatura: probamos leyendo el archivo
            }
        }
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val pic = r.embeddedPicture ?: return null
            val bmp = BitmapFactory.decodeByteArray(pic, 0, pic.size) ?: return null
            val max = 512f
            val scale = minOf(1f, max / maxOf(bmp.width, bmp.height))
            val out = if (scale < 1f) {
                Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
            } else bmp
            return compress(out)
        } catch (e: Exception) {
            return null
        } finally {
            try { r.release() } catch (e: Exception) { }
        }
    }

    private fun compress(bmp: Bitmap): ByteArray {
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return out.toByteArray()
    }

    private fun ok(b: ByteArray): WebResourceResponse {
        val r = WebResourceResponse("image/jpeg", null, ByteArrayInputStream(b))
        r.responseHeaders = mapOf("Cache-Control" to "max-age=86400")
        return r
    }

    private fun notFound(): WebResourceResponse =
        WebResourceResponse("image/jpeg", null, 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
}
