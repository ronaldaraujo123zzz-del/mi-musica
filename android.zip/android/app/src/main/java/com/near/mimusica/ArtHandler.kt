package com.near.mimusica

import android.content.Context
import android.graphics.Bitmap
import android.util.LruCache
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

/** Sirve las portadas a la interfaz: https://appassets.androidplatform.net/art/<id> */
class ArtHandler(private val ctx: Context) : WebViewAssetLoader.PathHandler {
    private val cache = LruCache<Long, ByteArray>(150)
    private val missing = HashSet<Long>()
    private val mine = LruCache<String, ByteArray>(40)

    override fun handle(path: String): WebResourceResponse? {
        val id = path.substringBefore('?').substringBefore('/').toLongOrNull() ?: return notFound()
        // carátula que pusiste tú: va primero
        Covers.init(ctx)
        Covers.file(id)?.let { f ->
            mine.get(f.name)?.let { return ok(it) }
            val b = try { f.readBytes() } catch (e: Exception) { null }
            if (b != null) {
                mine.put(f.name, b)
                return ok(b)
            }
        }
        cache.get(id)?.let { return ok(it) }
        if (synchronized(missing) { missing.contains(id) }) return notFound()
        val bytes = load(id)
        if (bytes == null) {
            synchronized(missing) { missing.add(id) }
            return notFound()
        }
        cache.put(id, bytes)
        return ok(bytes)
    }

    private fun load(id: Long): ByteArray? {
        val bmp = ArtLoader.bitmap(ctx, id, 512) ?: return null
        return compress(bmp)
    }

    private fun compress(bmp: Bitmap): ByteArray {
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return out.toByteArray()
    }

    private fun ok(b: ByteArray): WebResourceResponse {
        val r = WebResourceResponse("image/jpeg", null, ByteArrayInputStream(b))
        r.responseHeaders = mapOf("Cache-Control" to "max-age=86400")
        return r
    }

    private fun notFound(): WebResourceResponse =
        WebResourceResponse("image/jpeg", null, 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
}
